package com.example.lgacremote;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Round temperature dial. Drag or tap on the ring to set 16..30 degrees. */
public class DialView extends View {

    public interface Listener {
        void onPreview(int temp);
        void onCommit(int temp);
        void onBlocked();
    }

    private static final float START = 150f;
    private static final float TOTAL = 240f;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float density;
    private final float sp;

    private Listener listener;
    private String top = "OFF";
    private String big = "--";
    private String unit = "";
    private float frac = 0f;
    private boolean on = false;
    private int modeIcon = 0;
    private final Paint ico = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.Path ipath = new android.graphics.Path();
    private boolean dragging = false;
    private int lastTemp = -1;
    private float cx, cy;

    public DialView(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        sp = getResources().getDisplayMetrics().scaledDensity;
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setStrokeWidth(16 * density);
        track.setColor(0x551E4AA8);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setStrokeWidth(24 * density);
        glow.setMaskFilter(new BlurMaskFilter(16 * density, BlurMaskFilter.Blur.NORMAL));

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(16 * density);

        knobFill.setStyle(Paint.Style.FILL);
        knobFill.setColor(0xFFFFFFFF);
        knobRing.setStyle(Paint.Style.STROKE);
        knobRing.setStrokeWidth(3 * density);
        knobRing.setColor(0xFF3FD0FF);

        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setModeIcon(int m) {
        if (m != modeIcon) {
            modeIcon = m;
            invalidate();
        }
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setState(String top, String big, String unit, float frac, boolean on) {
        this.top = top;
        this.big = big;
        this.unit = unit;
        this.frac = Math.max(0f, Math.min(1f, frac));
        this.on = on;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int s = Math.min(MeasureSpec.getSize(widthSpec), (int) (300 * density));
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        cx = w / 2f;
        cy = h / 2f;
        SweepGradient g = new SweepGradient(cx, cy,
                new int[]{0xFF2BF0FF, 0xFF2F8BFF, 0xFFC070FF, 0xFF2BF0FF},
                new float[]{0f, 0.33f, 0.66f, 1f});
        Matrix m = new Matrix();
        m.setRotate(START, cx, cy);
        g.setLocalMatrix(m);
        arc.setShader(g);
        glow.setShader(g);
    }

    private float radius() {
        return Math.min(cx, cy) - 30 * density;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float r = radius();
        oval.set(cx - r, cy - r, cx + r, cy + r);

        canvas.drawArc(oval, START, TOTAL, false, track);

        float sweep = TOTAL * frac;
        if (on) {
            if (sweep > 0.5f) {
                canvas.drawArc(oval, START, sweep, false, glow);
                canvas.drawArc(oval, START, sweep, false, arc);
            }
            double rad = Math.toRadians(START + sweep);
            float kx = cx + (float) (r * Math.cos(rad));
            float ky = cy + (float) (r * Math.sin(rad));
            canvas.drawCircle(kx, ky, (dragging ? 13 : 10) * density, knobFill);
            canvas.drawCircle(kx, ky, (dragging ? 13 : 10) * density, knobRing);
        }

        // Scale end labels
        text.setTypeface(Typeface.DEFAULT);
        text.setColor(0xFF8FB2D6);
        text.setTextSize(11 * sp);
        double a1 = Math.toRadians(START);
        double a2 = Math.toRadians(START + TOTAL);
        canvas.drawText("16", cx + (float) (r * Math.cos(a1)), cy + (float) (r * Math.sin(a1)) + 24 * density, text);
        canvas.drawText("30", cx + (float) (r * Math.cos(a2)), cy + (float) (r * Math.sin(a2)) + 24 * density, text);

        // Mode icon + label
        if (on) drawModeIcon(canvas, cx, cy - r * 0.78f, 15 * density);
        text.setColor(0xFF3FD0FF);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(20 * sp);
        text.setShadowLayer(10 * density, 0, 0, 0xFF3FD0FF);
        canvas.drawText(top, cx, cy - r * 0.42f, text);

        // Big number and unit
        text.setColor(0xFFFFFFFF);
        text.setTextSize(76 * sp);
        text.setShadowLayer(16 * density, 0, 0, 0xFF3FD0FF);
        float shift = unit.isEmpty() ? 0f : 12 * density;
        canvas.drawText(big, cx - shift, cy + r * 0.30f, text);
        if (!unit.isEmpty()) {
            float half = text.measureText(big) / 2f;
            text.setTextSize(24 * sp);
            text.setTypeface(Typeface.DEFAULT);
            text.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(unit, cx - shift + half + 3 * density, cy + r * 0.30f - 34 * density, text);
            text.setTextAlign(Paint.Align.CENTER);
        }
        text.clearShadowLayer();

        text.setColor(0xFFEAF6FF);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(14 * sp);
        canvas.drawText("TEMP", cx, cy + r * 0.62f, text);
    }

    private void drawModeIcon(Canvas c, float x, float y, float s) {
        ico.setStyle(Paint.Style.STROKE);
        ico.setStrokeCap(Paint.Cap.ROUND);
        ico.setStrokeWidth(2.6f * density);
        ico.setColor(0xFF3FD0FF);
        ico.setShadowLayer(8 * density, 0, 0, 0xFF3FD0FF);
        switch (modeIcon) {
            case 0: // snowflake
                for (int k = 0; k < 3; k++) {
                    double a = Math.PI * k / 3 + Math.PI / 2;
                    float dx = (float) Math.cos(a) * s;
                    float dy = (float) Math.sin(a) * s;
                    c.drawLine(x - dx, y - dy, x + dx, y + dy, ico);
                    for (int sgn = -1; sgn <= 1; sgn += 2) {
                        float bx = x + dx * 0.62f * sgn;
                        float by = y + dy * 0.62f * sgn;
                        double a1 = a + 0.9;
                        double a2 = a - 0.9;
                        c.drawLine(bx, by, bx + (float) Math.cos(a1) * s * 0.3f * sgn, by + (float) Math.sin(a1) * s * 0.3f * sgn, ico);
                        c.drawLine(bx, by, bx + (float) Math.cos(a2) * s * 0.3f * sgn, by + (float) Math.sin(a2) * s * 0.3f * sgn, ico);
                    }
                }
                break;
            case 1: // water drop
                ipath.reset();
                ipath.moveTo(x, y - s);
                ipath.cubicTo(x + s * 0.2f, y - s * 0.5f, x + s * 0.8f, y, x + s * 0.8f, y + s * 0.35f);
                ipath.cubicTo(x + s * 0.8f, y + s * 0.85f, x - s * 0.8f, y + s * 0.85f, x - s * 0.8f, y + s * 0.35f);
                ipath.cubicTo(x - s * 0.8f, y, x - s * 0.2f, y - s * 0.5f, x, y - s);
                c.drawPath(ipath, ico);
                break;
            case 2: // fan blades
                for (int k = 0; k < 3; k++) {
                    c.save();
                    c.rotate(120 * k, x, y);
                    ipath.reset();
                    ipath.moveTo(x, y);
                    ipath.cubicTo(x - s * 0.7f, y - s * 0.3f, x - s * 0.5f, y - s * 1.0f, x, y - s * 0.95f);
                    ipath.cubicTo(x + s * 0.3f, y - s * 0.9f, x + s * 0.3f, y - s * 0.4f, x, y);
                    c.drawPath(ipath, ico);
                    c.restore();
                }
                break;
            default: // auto: sparkle
                ipath.reset();
                ipath.moveTo(x, y - s);
                ipath.quadTo(x, y, x + s, y);
                ipath.quadTo(x, y, x, y + s);
                ipath.quadTo(x, y, x - s, y);
                ipath.quadTo(x, y, x, y - s);
                c.drawPath(ipath, ico);
                break;
        }
        ico.clearShadowLayer();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!on) return false;
                {
                    double rad = Math.toRadians(START + TOTAL * frac);
                    float kx = cx + (float) (radius() * Math.cos(rad));
                    float ky = cy + (float) (radius() * Math.sin(rad));
                    float dx = e.getX() - kx;
                    float dy = e.getY() - ky;
                    float hit = 38 * density;
                    if (dx * dx + dy * dy > hit * hit) return false;
                }
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                dragging = true;
                lastTemp = -1;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) update(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    dragging = false;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    if (listener != null && lastTemp > 0) listener.onCommit(lastTemp);
                    invalidate();
                }
                return true;
            default:
                return true;
        }
    }

    private void update(MotionEvent e) {
        float dx = e.getX() - cx;
        float dy = e.getY() - cy;
        double ang = Math.toDegrees(Math.atan2(dy, dx));
        if (ang < 0) ang += 360;
        double rel = ang - START;
        if (rel < 0) rel += 360;
        float f;
        if (rel <= TOTAL) f = (float) (rel / TOTAL);
        else f = rel < TOTAL + (360 - TOTAL) / 2 ? 1f : 0f;
        int t = 16 + Math.round(f * 14);
        if (t != lastTemp) {
            lastTemp = t;
            if (listener != null) listener.onPreview(t);
        }
    }
}
