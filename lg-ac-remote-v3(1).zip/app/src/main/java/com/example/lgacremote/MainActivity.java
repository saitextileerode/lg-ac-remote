package com.example.lgacremote;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import java.util.HashMap;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    static final int NEON = 0xFF3FD0FF;
    static final int GLASS = 0xCC0E2347;
    static final int GLASS_EDGE = 0x663FD0FF;
    static final int OFF_EDGE = 0x552A4A6E;
    static final int TEXT = 0xFFEAF6FF;
    static final int MUTED = 0xFF7FA6C9;
    static final int BG_TOP = 0xFF040B1C;
    static final int BG_BOT = 0xFF0A1A38;

    static final String[] MODE_NAMES = {"Cool", "Dry", "Fan", "Auto"};
    static final int[] MODE_CODE = {0, 1, 2, 3};
    static final String[] FAN_NAMES = {"Low", "Mid", "High", "Auto"};
    static final int[][] FAN_CODES = {{0, 2, 4, 5}, {9, 2, 10, 5}};
    static final int[] ENERGY_PCT = {0, 80, 60, 40};
    static final String[] SWING_NAMES = {"Off", "Auto swing", "Highest", "High", "Upper-middle", "Middle", "Low", "Lowest"};
    static final int[] DUR_MIN = {30, 60, 120, 180, 240, 360, 480, 600, 720};
    static final String[] DUR_LABEL = {"30 நிமிஷம்", "1 மணி", "2 மணி", "3 மணி", "4 மணி", "6 மணி", "8 மணி", "10 மணி", "12 மணி"};

    private SharedPreferences prefs;
    private ConsumerIrManager ir;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    // AC state
    private boolean on;
    private int temp = 24;
    private int mode = 0;
    private int fan = 3;
    private int swingPos = 0;
    private boolean hSwing, hcool, lightOn = true, clean, purify, oldSwing;
    private int energy = 0;
    private int sleepH = 0;
    private long sleepEnd = 0;
    private int activeTimer = 0;      // 0 none, 1 off, 2 on
    private long activeTimerEnd = 0;

    // Setup
    private boolean lg2 = false;
    private int fanTable = 1;         // user-verified: "New" fan codes
    private boolean bit15 = false;    // user-verified: remote-style bit OFF
    private int repeats = 1;

    private String overlayText = null;
    private long overlayUntil = 0;

    // Views
    private DialView dial;
    private TextView tvStatus, tvModeVal, tvFanVal, tvLightVal, tvTimerLine, tvPowerLbl;
    private ImageView powerIcon;
    private LinearLayout powerBtn;
    private final HashMap<View, ValueAnimator> glowAnims = new HashMap<>();
    private int lastPower = -1;
    private final int[] lastChip = {-1, -1, -1, -1};
    private FanBarsView fanBars;
    private TextView tvAirVal, tvHcoolVal;
    private final TextView[] chips = new TextView[4];
    private int vFixed = 2;           // fixed vane position 0..5 (Highest..Lowest)
    private AirflowView avV, avH;
    private Switch swV, swH;
    private TextView tvVLabel;
    private boolean syncing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("lgac4", MODE_PRIVATE);
        on = prefs.getBoolean("on", false);
        temp = prefs.getInt("temp", 24);
        mode = prefs.getInt("mode", 0);
        fan = prefs.getInt("fan", 3);
        swingPos = prefs.getInt("swing", 0);
        vFixed = prefs.getInt("vFixed", 2);
        if (swingPos >= 2) vFixed = swingPos - 2;
        oldSwing = prefs.getBoolean("oldSwing", false);
        lightOn = prefs.getBoolean("light", true);
        lg2 = prefs.getBoolean("lg2", false);
        fanTable = prefs.getInt("fanTable", 1);
        bit15 = prefs.getBoolean("bit15", false);
        repeats = prefs.getInt("repeats", 1);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        getWindow().setStatusBarColor(BG_TOP);
        getWindow().setNavigationBarColor(BG_BOT);
        setContentView(buildUi());
        refresh();
        if (ir == null || !ir.hasIrEmitter()) {
            toast("இந்த phone-ல IR blaster கண்டுபிடிக்க முடியல");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
        save();
    }

    // ---------- IR ----------

    private void send(int frame) {
        send(frame, repeats);
    }

    private void send(int frame, int reps) {
        if (ir == null || !ir.hasIrEmitter()) {
            toast("IR blaster இல்ல");
            return;
        }
        try {
            ir.transmit(38000, LgFrames.pattern(frame, lg2, reps));
        } catch (Exception e) {
            toast("IR அனுப்ப முடியல");
        }
    }

    private void sendState() {
        send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15));
    }

    // ---------- Actions ----------

    private boolean needOn() {
        if (!on) {
            toast("முதல்ல Power ON பண்ணுங்க");
            return false;
        }
        return true;
    }

    private void actPower() {
        if (!on) {
            on = true;
            send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15), 3);
        } else {
            on = false;
            send(LgFrames.OFF, 3);
            sleepH = 0;
            sleepEnd = 0;
            hcool = false;
            if (activeTimer == 1) activeTimer = 0;
        }
    }

    private void actMode() {
        if (!needOn()) return;
        hcool = false;
        mode = (mode + 1) % MODE_NAMES.length;
        sendState();
    }

    private void actFan() {
        if (!needOn()) return;
        hcool = false;
        fan = (fan + 1) % FAN_NAMES.length;
        sendState();
    }

    private void actTemp(int delta) {
        if (!needOn()) return;
        hcool = false;
        temp = Math.max(16, Math.min(30, temp + delta));
        overlayText = null;
        sendState();
    }

    private void actHcool() {
        if (!needOn()) return;
        if (!hcool) {
            hcool = true;
            send(LgFrames.JET_ON);
        } else {
            hcool = false;
            sendState();
        }
    }

    private void actEnergy(int level) {
        if (!needOn()) return;
        energy = level;
        send(LgFrames.ENERGY[energy]);
        if (energy > 0) {
            overlayText = ENERGY_PCT[energy] + " %";
            overlayUntil = System.currentTimeMillis() + 4000;
        } else {
            overlayText = null;
        }
    }

    private void actLight() {
        if (!needOn()) return;
        lightOn = !lightOn;
        send(LgFrames.LIGHT_TOGGLE);
    }

    private String swingLabel() {
        if (swingPos == 0) return "Off";
        if (swingPos == 1) return "Swing";
        return SWING_NAMES[swingPos];
    }

    private void vSwingSwitch(boolean checked) {
        if (!needOn()) {
            syncAirflow();
            return;
        }
        if (oldSwing) {
            swingPos = checked ? 1 : 0;
            send(LgFrames.SWING_V_TOGGLE);
        } else {
            swingPos = checked ? 1 : 0;
            send(LgFrames.SWING_V[swingPos]);
        }
        syncAirflow();
        refresh();
        save();
    }

    private void vMove(int dir) {
        if (!needOn()) return;
        if (oldSwing) {
            toast("Old toggle mode-ல position இல்ல. Setup-ல Swing மாத்துங்க");
            return;
        }
        vFixed = Math.max(0, Math.min(5, vFixed + dir));
        swingPos = 2 + vFixed;
        send(LgFrames.SWING_V[swingPos]);
        syncAirflow();
        refresh();
        save();
    }

    private void hSwingSwitch(boolean checked) {
        if (!needOn()) {
            syncAirflow();
            return;
        }
        hSwing = checked;
        send(hSwing ? LgFrames.SWING_H_ON : LgFrames.SWING_H_OFF);
        syncAirflow();
        refresh();
    }

    private void syncAirflow() {
        if (avV == null) return;
        syncing = true;
        boolean vs = on && swingPos == 1;
        avV.setState(vFixed, vs);
        avH.setState(3, on && hSwing);
        swV.setChecked(vs);
        swH.setChecked(on && hSwing);
        tvVLabel.setText(on ? swingLabel() : "Off");
        syncing = false;
    }

    private Switch neonSwitch() {
        Switch sw = new Switch(this);
        int[][] st = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(st, new int[]{NEON, 0xFFB0BCCF}));
        sw.setTrackTintList(new ColorStateList(st, new int[]{0x883FD0FF, 0x66506A8A}));
        return sw;
    }

    private LinearLayout glassCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(shape(true, GLASS, GLASS_EDGE, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout roundBtn(int iconRes, Runnable r) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x33162F55);
        g.setStroke(dp(1), GLASS_EDGE);
        setGlowBg(b, new RippleDrawable(ColorStateList.valueOf(Color.argb(90, 63, 208, 255)), g, null), 28);
        b.setClickable(true);
        b.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            r.run();
        });
        glowTouch(b);
        b.addView(icon(iconRes, 26));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(56));
        lp.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout switchRow(String label, TextView valueView, Switch sw) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, 0);
        TextView t = caption(label, 15, TEXT, true);
        t.setGravity(Gravity.START);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (valueView != null) {
            valueView.setPadding(0, 0, dp(12), 0);
            r.addView(valueView);
        }
        r.addView(sw);
        return r;
    }

    private void actSwingVPicker() {
        Dialog dlg = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_TOP, BG_BOT}));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(30), dp(18), dp(24));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = caption("Airflow", 24, TEXT, true);
        title.setGravity(Gravity.START);
        root.addView(title);

        // UP / DOWN
        LinearLayout c1 = glassCard();
        TextView h1 = caption("UP/DOWN", 13, NEON, true);
        h1.setGravity(Gravity.START);
        c1.addView(h1);
        LinearLayout body1 = new LinearLayout(this);
        body1.setGravity(Gravity.CENTER_VERTICAL);
        avV = new AirflowView(this, true);
        body1.addView(avV);
        LinearLayout arrows = new LinearLayout(this);
        arrows.setOrientation(LinearLayout.VERTICAL);
        arrows.setGravity(Gravity.CENTER);
        arrows.addView(roundBtn(R.drawable.ic_up, () -> vMove(-1)));
        arrows.addView(roundBtn(R.drawable.ic_down, () -> vMove(1)));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        body1.addView(arrows, alp);
        c1.addView(body1);
        swV = neonSwitch();
        tvVLabel = caption("", 13, MUTED, false);
        swV.setOnCheckedChangeListener((b, checked) -> {
            if (!syncing) vSwingSwitch(checked);
        });
        c1.addView(switchRow("Up/Down Swing", tvVLabel, swV));
        root.addView(c1);

        // LEFT / RIGHT
        LinearLayout c2 = glassCard();
        TextView h2 = caption("LEFT/RIGHT", 13, NEON, true);
        h2.setGravity(Gravity.START);
        c2.addView(h2);
        LinearLayout body2 = new LinearLayout(this);
        body2.setGravity(Gravity.CENTER);
        avH = new AirflowView(this, false);
        body2.addView(avH);
        c2.addView(body2);
        swH = neonSwitch();
        swH.setOnCheckedChangeListener((b, checked) -> {
            if (!syncing) hSwingSwitch(checked);
        });
        c2.addView(switchRow("Left/Right Swing", null, swH));
        TextView note = caption("Left/Right-ல On / Off மட்டும் (position code இல்ல)", 11, MUTED, false);
        note.setGravity(Gravity.START);
        note.setPadding(0, dp(8), 0, 0);
        c2.addView(note);
        root.addView(c2);

        TextView close = caption("Close", 16, NEON, true);
        close.setPadding(dp(16), dp(16), dp(16), dp(16));
        setGlowBg(close, ripple(shape(true, GLASS, GLASS_EDGE, 1)), 18);
        close.setClickable(true);
        close.setOnClickListener(v -> dlg.dismiss());
        glowTouch(close);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(20);
        root.addView(close, clp);

        dlg.setContentView(sv);
        dlg.setOnDismissListener(d -> {
            avV = null;
            avH = null;
            refresh();
            save();
        });
        syncAirflow();
        dlg.show();
    }

    private void actSleep() {
        if (!needOn()) return;
        sleepH = (sleepH + 1) % 8;
        send(LgFrames.sleep(sleepH * 60));
        sleepEnd = sleepH == 0 ? 0 : System.currentTimeMillis() + sleepH * 3600000L;
        toast(sleepH == 0 ? "Sleep timer off" : "Sleep: " + sleepH + " மணி நேரத்துல AC off ஆகும்");
    }

    private void showTimerDialog() {
        String[] kinds = {"OFF timer set பண்ணு", "ON timer set பண்ணு", "Timer cancel பண்ணு"};
        new AlertDialog.Builder(this)
                .setTitle("Timer")
                .setItems(kinds, (d, w) -> {
                    if (w == 2) {
                        send(LgFrames.TIMER_CLEAR_ALL);
                        if (sleepH != 0) send(LgFrames.SLEEP_CANCEL);
                        activeTimer = 0;
                        sleepH = 0;
                        sleepEnd = 0;
                        toast("Timer cancel ஆச்சு");
                    } else {
                        pickDuration(w == 1);
                    }
                })
                .show();
    }

    private void pickDuration(boolean turnOn) {
        new AlertDialog.Builder(this)
                .setTitle(turnOn ? "ON timer எவ்வளவு நேரம் கழிச்சு?" : "OFF timer எவ்வளவு நேரம் கழிச்சு?")
                .setItems(DUR_LABEL, (d, w) -> {
                    int min = DUR_MIN[w];
                    send(LgFrames.schedule(turnOn, min));
                    activeTimer = turnOn ? 2 : 1;
                    activeTimerEnd = System.currentTimeMillis() + min * 60000L;
                    toast((turnOn ? "ON" : "OFF") + " timer set ஆச்சு");
                })
                .show();
    }

    private void showMoreDialog() {
        String[] items = {
                "Auto clean: " + (clean ? "ON" : "OFF"),
                "Plasma: " + (purify ? "ON" : "OFF"),
                "Comfort Air (code இல்ல)",
                "Room temp (example)",
                "Setup"
        };
        new AlertDialog.Builder(this)
                .setTitle("More")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0:
                            if (!needOn()) break;
                            clean = !clean;
                            send(clean ? LgFrames.CLEAN_ON : LgFrames.CLEAN_OFF);
                            break;
                        case 1:
                            if (!needOn()) break;
                            purify = !purify;
                            send(purify ? LgFrames.PURIFY_ON : LgFrames.PURIFY_OFF);
                            break;
                        case 2: toast("Comfort Air-க்கு IR code இன்னும் கிடைக்கல"); break;
                        case 3: overlayText = "29 °C"; overlayUntil = System.currentTimeMillis() + 3000; break;
                        case 4: showSetup(); break;
                        default: break;
                    }
                    refresh();
                    save();
                })
                .show();
    }

    private void showSetup() {
        String[] items = {
                "1) Signal type: " + (lg2 ? "LG2" : "LG1"),
                "2) Fan codes: " + (fanTable == 0 ? "Classic" : "New"),
                "3) Remote-style bit: " + (bit15 ? "ON" : "OFF"),
                "4) அனுப்பும் முறை: " + repeats + "x",
                "5) Swing: " + (oldSwing ? "Old toggle" : "Positions"),
                "Test அனுப்பு (Cool 24°C)"
        };
        new AlertDialog.Builder(this)
                .setTitle("Setup")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0: lg2 = !lg2; break;
                        case 1: fanTable = 1 - fanTable; break;
                        case 2: bit15 = !bit15; break;
                        case 3: repeats = repeats == 1 ? 2 : 1; break;
                        case 4: oldSwing = !oldSwing; break;
                        case 5:
                            send(LgFrames.state(0, 24, FAN_CODES[fanTable][3], bit15), 3);
                            toast("Test அனுப்பினேன். AC beep பண்ணுதா பாருங்க");
                            return;
                        default: return;
                    }
                    save();
                    showSetup();
                })
                .show();
    }

    // ---------- Screen ----------

    private static String fmt(int min) {
        int m = min % 60;
        return (min / 60) + ":" + (m < 10 ? "0" : "") + m;
    }

    private void refresh() {
        long now = System.currentTimeMillis();
        if (activeTimer != 0 && now >= activeTimerEnd) {
            on = activeTimer == 2;
            activeTimer = 0;
            if (!on) {
                sleepH = 0;
                sleepEnd = 0;
            }
        }
        if (sleepH != 0 && now >= sleepEnd) {
            on = false;
            sleepH = 0;
            sleepEnd = 0;
        }
        if (overlayText != null && now > overlayUntil) overlayText = null;

        // Dial
        String big;
        String unit = "°C";
        if (!on) {
            big = "--";
            unit = "";
        } else if (overlayText != null) {
            big = overlayText;
            unit = "";
        } else if (mode == 2) {
            big = "--";
            unit = "";
        } else {
            big = String.valueOf(temp);
        }
        float frac = (temp - 16) / 14f;
        dial.setState(on ? (hcool ? "H'COOL" : MODE_NAMES[mode].toUpperCase()) : "OFF", big, unit, frac, on);

        // Cards
        tvModeVal.setText(on ? MODE_NAMES[mode] : "Off");
        tvFanVal.setText(on ? FAN_NAMES[fan] : "Off");
        fanBars.setLevel(on ? fan + 1 : 0);
        tvAirVal.setText("↕ " + (on ? swingLabel() : "Off") + "   ↔ " + (on && hSwing ? "On" : "Off"));
        tvHcoolVal.setText(hcool ? "On" : "Off");
        tvLightVal.setText(lightOn ? "On" : "Off");
        for (int i = 0; i < 4; i++) {
            boolean sel = on && energy == i;
            chips[i].setTextColor(sel ? BG_TOP : MUTED);
            int key = sel ? 1 : 0;
            if (lastChip[i] != key) {
                lastChip[i] = key;
                GradientDrawable cg = new GradientDrawable();
                cg.setCornerRadius(dp(12));
                cg.setColor(sel ? NEON : 0x22163A66);
                cg.setStroke(dp(1), sel ? NEON : OFF_EDGE);
                setGlowBg(chips[i], cg, 12);
            }
        }
        if (avV != null) syncAirflow();

        // Status line under the dial
        StringBuilder st = new StringBuilder();
        if (on) {
            if (energy > 0) st.append("ENERGY ").append(ENERGY_PCT[energy]).append("%   ");
            if (sleepH > 0) st.append("SLEEP   ");
            if (clean) st.append("CLEAN   ");
            if (purify) st.append("PLASMA   ");
        }
        tvStatus.setText(st.toString().trim());

        // Timer line
        String t = "";
        if (activeTimer != 0) {
            int left = (int) Math.max(0, (activeTimerEnd - now + 59999) / 60000);
            t = (activeTimer == 1 ? "OFF " : "ON ") + fmt(left);
        } else if (sleepH != 0) {
            int left = (int) Math.max(0, (sleepEnd - now + 59999) / 60000);
            t = "SLEEP " + fmt(left);
        }
        tvTimerLine.setText(t);

        // Power look
        int edge = on ? NEON : OFF_EDGE;
        if (lastPower != (on ? 1 : 0)) {
            lastPower = on ? 1 : 0;
            setGlowBg(powerBtn, ripple(shape(true, GLASS, edge, on ? 2 : 1)), 18);
        }
        powerIcon.setColorFilter(on ? NEON : MUTED);
        tvPowerLbl.setText(on ? "ON" : "OFF");
        tvPowerLbl.setTextColor(on ? NEON : MUTED);
    }

    private void save() {
        prefs.edit().putBoolean("on", on).putInt("temp", temp).putInt("mode", mode)
                .putInt("fan", fan).putInt("swing", swingPos).putBoolean("light", lightOn)
                .putBoolean("lg2", lg2).putInt("fanTable", fanTable).putBoolean("bit15", bit15)
                .putInt("vFixed", vFixed).putInt("repeats", repeats).putBoolean("oldSwing", oldSwing).apply();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ---------- UI building ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(boolean rounded, int fill, int edge, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        if (rounded) d.setCornerRadius(dp(18));
        d.setStroke(dp(strokeDp), edge);
        return d;
    }

    private RippleDrawable ripple(GradientDrawable content) {
        return new RippleDrawable(ColorStateList.valueOf(Color.argb(90, 63, 208, 255)), content, null);
    }

    /** Base background plus a bright glow layer (hidden until touched). */
    private void setGlowBg(View v, Drawable base, int cornerDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xAA3FD0FF, 0x333FD0FF});
        g.setCornerRadius(dp(cornerDp));
        g.setStroke(dp(2), 0xFFC4F4FF);
        g.setAlpha(0);
        v.setBackground(new LayerDrawable(new Drawable[]{base, g}));
        v.setTag(g);
    }

    private void animGlow(View v, GradientDrawable g, int target, long ms) {
        ValueAnimator old = glowAnims.get(v);
        if (old != null) old.cancel();
        ValueAnimator a = ValueAnimator.ofInt(g.getAlpha(), target);
        a.setDuration(ms);
        a.addUpdateListener(an -> g.setAlpha((Integer) an.getAnimatedValue()));
        glowAnims.put(v, a);
        a.start();
    }

    private void glowTouch(View v) {
        v.setOnTouchListener((view, e) -> {
            Object t = view.getTag();
            if (!(t instanceof GradientDrawable)) return false;
            GradientDrawable g = (GradientDrawable) t;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    animGlow(view, g, 255, 110);
                    view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    animGlow(view, g, 0, 700);
                    view.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    private View.OnClickListener act(Runnable r) {
        return v -> {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            r.run();
            refresh();
            save();
        };
    }

    private ImageView icon(int res, int sizeDp) {
        ImageView iv = new ImageView(this);
        Drawable d = getDrawable(res).mutate();
        iv.setImageDrawable(d);
        iv.setColorFilter(NEON);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        iv.setPadding(0, 0, 0, dp(2));
        return iv;
    }

    private TextView caption(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Glass card: icon + title, optional value line. */
    private LinearLayout card(int iconRes, String title, TextView value, Runnable onTap, int heightDp) {
        return card(iconRes, null, title, value, onTap, heightDp);
    }

    private LinearLayout card(int iconRes, View extraTop, String title, TextView value, Runnable onTap, int heightDp) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4), dp(6), dp(4), dp(6));
        setGlowBg(c, ripple(shape(true, GLASS, GLASS_EDGE, 1)), 18);
        c.setClickable(true);
        c.setOnClickListener(act(onTap));
        glowTouch(c);
        if (iconRes != 0) c.addView(icon(iconRes, 22));
        else if (extraTop != null) c.addView(extraTop);
        c.addView(caption(title, 10, MUTED, false));
        if (value != null) c.addView(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(heightDp), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout pill(String symbol, Runnable onTap) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER);
        c.setClickable(true);
        setGlowBg(c, ripple(shape(true, GLASS, GLASS_EDGE, 1)), 18);
        c.setOnClickListener(act(onTap));
        glowTouch(c);
        c.addView(caption(symbol, 26, TEXT, true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(56), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView valueText() {
        return caption("", 15, TEXT, true);
    }

    private LinearLayout row(View... views) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        for (View v : views) r.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        r.setLayoutParams(lp);
        return r;
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_TOP, BG_BOT});
        sv.setBackground(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // Top: power button in the middle, setup gear on the right
        FrameLayout top = new FrameLayout(this);
        powerBtn = new LinearLayout(this);
        powerBtn.setOrientation(LinearLayout.VERTICAL);
        powerBtn.setGravity(Gravity.CENTER);
        powerBtn.setClickable(true);
        powerBtn.setOnClickListener(act(this::actPower));
        glowTouch(powerBtn);
        powerIcon = new ImageView(this);
        powerIcon.setImageDrawable(getDrawable(R.drawable.ic_power).mutate());
        powerIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        tvPowerLbl = caption("OFF", 11, MUTED, true);
        powerBtn.addView(powerIcon);
        powerBtn.addView(tvPowerLbl);
        top.addView(powerBtn, new FrameLayout.LayoutParams(dp(88), dp(88), Gravity.CENTER_HORIZONTAL));
        TextView gear = caption("⚙", 26, MUTED, false);
        gear.setPadding(dp(10), dp(6), dp(10), dp(6));
        gear.setClickable(true);
        gear.setOnClickListener(v -> showSetup());
        top.addView(gear, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.TOP));
        root.addView(top);

        // Dial (drag or tap the ring)
        dial = new DialView(this);
        dial.setListener(new DialView.Listener() {
            @Override
            public void onPreview(int t) {
                temp = t;
                hcool = false;
                overlayText = null;
                refresh();
            }

            @Override
            public void onCommit(int t) {
                temp = t;
                sendState();
                save();
                refresh();
            }

            @Override
            public void onBlocked() {
                toast("முதல்ல Power ON பண்ணுங்க");
            }
        });
        LinearLayout dialWrap = new LinearLayout(this);
        dialWrap.setGravity(Gravity.CENTER);
        dialWrap.addView(dial);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(10);
        root.addView(dialWrap, dlp);

        tvStatus = caption("", 11, NEON, true);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(2);
        root.addView(tvStatus, slp);

        // Mode / Fan (fan card shows bars inside the box)
        tvModeVal = valueText();
        tvFanVal = valueText();
        fanBars = new FanBarsView(this);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(dp(40), dp(26));
        flp.bottomMargin = dp(3);
        fanBars.setLayoutParams(flp);
        root.addView(row(
                card(R.drawable.ic_mode, "MODE", tvModeVal, this::actMode, 92),
                card(0, fanBars, "FAN SPEED", tvFanVal, this::actFan, 92)));

        // Temp -/+ pills
        root.addView(row(
                pill("\u2212", () -> actTemp(-1)),
                pill("+", () -> actTemp(1))));

        // Airflow / H'Cool
        tvAirVal = caption("", 12, TEXT, true);
        tvHcoolVal = valueText();
        root.addView(row(
                card(R.drawable.ic_swing_v, "AIRFLOW", tvAirVal, this::actSwingVPicker, 84),
                card(R.drawable.ic_hcool, "H'COOL", tvHcoolVal, this::actHcool, 84)));

        // Energy saving: always visible with all options
        LinearLayout energyCard = new LinearLayout(this);
        energyCard.setOrientation(LinearLayout.VERTICAL);
        energyCard.setPadding(dp(12), dp(10), dp(12), dp(12));
        energyCard.setBackground(shape(true, GLASS, GLASS_EDGE, 1));
        LinearLayout eHead = new LinearLayout(this);
        eHead.setGravity(Gravity.CENTER_VERTICAL);
        ImageView eIcon = icon(R.drawable.ic_energy, 20);
        eHead.addView(eIcon);
        TextView eTitle = caption("ENERGY SAVING", 11, MUTED, false);
        eTitle.setPadding(dp(8), 0, 0, 0);
        eHead.addView(eTitle);
        energyCard.addView(eHead);
        LinearLayout eRow = new LinearLayout(this);
        String[] chipLabels = {"OFF", "80%", "60%", "40%"};
        for (int i = 0; i < 4; i++) {
            final int lvl = i;
            TextView c = caption(chipLabels[i], 14, MUTED, true);
            c.setClickable(true);
            c.setOnClickListener(act(() -> actEnergy(lvl)));
            glowTouch(c);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, dp(42), 1f);
            cl.setMargins(dp(3), dp(8), dp(3), 0);
            eRow.addView(c, cl);
            chips[i] = c;
        }
        energyCard.addView(eRow);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.topMargin = dp(10);
        elp.setMargins(dp(4), dp(10), dp(4), 0);
        root.addView(energyCard, elp);

        // Timer / Sleep / Light / More
        tvLightVal = valueText();
        root.addView(row(
                card(R.drawable.ic_timer, "TIMER", null, this::showTimerDialog, 72),
                card(R.drawable.ic_sleep, "SLEEP", null, this::actSleep, 72),
                card(R.drawable.ic_light, "LIGHT", tvLightVal, this::actLight, 72),
                card(0, "MORE", null, this::showMoreDialog, 72)));

        tvTimerLine = caption("", 13, NEON, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(10);
        root.addView(tvTimerLine, tlp);

        return sv;
    }
}
