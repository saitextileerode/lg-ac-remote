package com.example.lgacremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#D9D7D4");
    private static final int REMOTE = Color.parseColor("#F7F6F4");
    private static final int KEY = Color.parseColor("#EBE9E4");
    private static final int KEY_EDGE = Color.parseColor("#CBC7C0");
    private static final int LABEL = Color.parseColor("#6F6B64");
    private static final int POWER_ON = Color.parseColor("#2F7D4F");
    private static final int POWER_OFF = Color.parseColor("#E8743B");
    private static final int LCD = Color.parseColor("#B9C4B8");
    private static final int INK = Color.parseColor("#1C2420");

    private static final String[] MODE_NAMES = {"COOL", "DRY", "FAN", "AUTO"};
    private static final int[] MODE_CODE = {0, 1, 2, 3};
    private static final String[] FAN_LETTER = {"L", "M", "H", "A"};
    private static final String[] FAN_BARS = {"▂", "▂▄", "▂▄▆", "▂▄▆█"};
    // Fan codes: [classic, alternate]
    private static final int[][] FAN_CODES = {{0, 2, 4, 5}, {9, 2, 10, 5}};
    private static final int[] ENERGY_PCT = {0, 80, 60, 40};
    private static final String[] SWING_NAMES = {"Off", "Auto swing", "Highest", "High", "Upper-middle", "Middle", "Low", "Lowest"};
    private static final String[] FUNC_NAMES = {"CLEAN", "PLASMA"};

    private SharedPreferences prefs;
    private ConsumerIrManager ir;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    // AC state
    private boolean on;
    private int temp = 24;
    private int mode = 0;
    private int fan = 3;
    private int swingPos = 0;     // index into SWING_NAMES
    private boolean hSwing, hcool, lightOn = true, clean, purify;
    private int energy = 0;
    private int sleepH = 0;
    private long sleepEnd = 0;

    // Timer editing / active timer
    private int timerSel = 0;     // 0 none, 1 OFF timer, 2 ON timer
    private int timerMin = 60;
    private int activeTimer = 0;  // 0 none, 1 off, 2 on
    private long activeTimerEnd = 0;
    private int funcSel = -1;

    // Setup options
    private boolean lg2 = false;
    private int fanTable = 1;        // user-verified: "New" fan codes
    private boolean bit15 = false;   // user-verified: remote-style bit OFF
    private boolean oldSwing = false;
    private int repeats = 1;

    private String overlayText = null;
    private long overlayUntil = 0;

    // Views
    private TextView tvMode, tvTags, tvTemp, tvFan, tvTimer;
    private LinearLayout midRow, remotePanel, setupPanel;
    private Button btnPower, btnLight, btnSetup, sSig, sFan, sBit, sRep, sOld;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("lgac3", MODE_PRIVATE);
        on = prefs.getBoolean("on", false);
        temp = prefs.getInt("temp", 24);
        mode = prefs.getInt("mode", 0);
        fan = prefs.getInt("fan", 3);
        swingPos = prefs.getInt("swing", 0);
        lightOn = prefs.getBoolean("light", true);
        lg2 = prefs.getBoolean("lg2", false);
        fanTable = prefs.getInt("fanTable", 1);
        bit15 = prefs.getBoolean("bit15", false);
        oldSwing = prefs.getBoolean("oldSwing", false);
        repeats = prefs.getInt("repeats", 1);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        setContentView(buildUi());
        refresh();
        if (ir == null || !ir.hasIrEmitter()) {
            toast("இந்த phone-ல IR blaster கண்டுபிடிக்க முடியல");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
        save();
    }

    // ---------- IR ----------

    private void send(int frame) {
        send(frame, repeats);
    }

    private void send(int frame, int reps) {
        if (ir == null || !ir.hasIrEmitter()) {
            toast("IR blaster இல்ல");
            return;
        }
        try {
            ir.transmit(38000, LgFrames.pattern(frame, lg2, reps));
        } catch (Exception e) {
            toast("IR அனுப்ப முடியல");
        }
    }

    private void sendState() {
        send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15));
    }

    // ---------- Actions ----------

    private boolean needOn() {
        if (!on) {
            toast("முதல்ல Power ON பண்ணுங்க");
            return false;
        }
        return true;
    }

    /** One button for both on and off. */
    private void actPower() {
        if (!on) {
            on = true;
            // Send the full state three times so the AC wakes up reliably.
            send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15), 3);
            toast("AC ON");
        } else {
            on = false;
            send(LgFrames.OFF, 3);
            sleepH = 0;
            sleepEnd = 0;
            hcool = false;
            if (activeTimer == 1) activeTimer = 0;
            toast("AC OFF");
        }
    }

    private void actMode() {
        if (!needOn()) return;
        hcool = false;
        mode = (mode + 1) % MODE_NAMES.length;
        sendState();
    }

    private void actTemp(int delta) {
        if (!needOn()) return;
        hcool = false;
        temp = Math.max(16, Math.min(30, temp + delta));
        overlayText = null;
        sendState();
    }

    private void actFan() {
        if (!needOn()) return;
        hcool = false;
        fan = (fan + 1) % 4;
        sendState();
    }

    private void actHcool() {
        if (!needOn()) return;
        if (!hcool) {
            hcool = true;
            send(LgFrames.JET_ON);
        } else {
            hcool = false;
            sendState();
        }
    }

    private void actEnergy() {
        if (!needOn()) return;
        energy = (energy + 1) % ENERGY_PCT.length;
        send(LgFrames.ENERGY[energy]);
        if (energy > 0) {
            overlayText = ENERGY_PCT[energy] + " %";
            overlayUntil = System.currentTimeMillis() + 4000;
        } else {
            overlayText = null;
        }
    }

    private void actLight() {
        if (!needOn()) return;
        lightOn = !lightOn;
        send(LgFrames.LIGHT_TOGGLE);
    }

    /** Opens a picker with the vertical swing positions. */
    private void actSwingV() {
        if (!needOn()) return;
        if (oldSwing) {
            swingPos = swingPos == 0 ? 1 : 0;
            send(LgFrames.SWING_V_TOGGLE);
            refresh();
            save();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Vertical swing")
                .setSingleChoiceItems(SWING_NAMES, swingPos, null)
                .setPositiveButton("Set", (d, w) -> {
                    int sel = ((AlertDialog) d).getListView().getCheckedItemPosition();
                    if (sel < 0) sel = swingPos;
                    swingPos = sel;
                    send(LgFrames.SWING_V[swingPos]);
                    refresh();
                    save();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void actSwingH() {
        if (!needOn()) return;
        hSwing = !hSwing;
        send(hSwing ? LgFrames.SWING_H_ON : LgFrames.SWING_H_OFF);
    }

    private void actSleep() {
        if (!needOn()) return;
        sleepH = (sleepH + 1) % 8;
        send(LgFrames.sleep(sleepH * 60));
        sleepEnd = sleepH == 0 ? 0 : System.currentTimeMillis() + sleepH * 3600000L;
        toast(sleepH == 0 ? "Sleep timer off" : "Sleep: " + sleepH + " மணி நேரத்துல AC off ஆகும்");
    }

    private void actFunc() {
        if (!needOn()) return;
        funcSel = funcSel >= FUNC_NAMES.length - 1 ? -1 : funcSel + 1;
        toast(funcSel < 0 ? "Func வெளியேறியது" : FUNC_NAMES[funcSel] + " தேர்வு. Set/Cancel அழுத்தினா on/off ஆகும்");
    }

    private void actTimer() {
        timerSel = (timerSel + 1) % 3;
        funcSel = -1;
        if (timerSel != 0) {
            timerMin = 60;
            toast(timerSel == 1 ? "OFF timer: மேல/கீழ் அம்புகளால நேரம் வைங்க, அப்புறம் Set" : "ON timer: மேல/கீழ் அம்புகளால நேரம் வைங்க, அப்புறம் Set");
        }
    }

    private void actTimerStep(int deltaMin) {
        if (timerSel == 0) {
            toast("முதல்ல Timer அழுத்துங்க");
            return;
        }
        timerMin = Math.max(30, Math.min(1410, timerMin + deltaMin));
    }

    private void actSetCancel() {
        if (timerSel != 0) {
            boolean turnOn = timerSel == 2;
            send(LgFrames.schedule(turnOn, timerMin));
            activeTimer = turnOn ? 2 : 1;
            activeTimerEnd = System.currentTimeMillis() + timerMin * 60000L;
            toast((turnOn ? "ON" : "OFF") + " timer: " + fmt(timerMin) + " மணி நேரத்துல");
            timerSel = 0;
        } else if (funcSel >= 0) {
            if (!needOn()) return;
            if (funcSel == 0) {
                clean = !clean;
                send(clean ? LgFrames.CLEAN_ON : LgFrames.CLEAN_OFF);
            } else {
                purify = !purify;
                send(purify ? LgFrames.PURIFY_ON : LgFrames.PURIFY_OFF);
            }
            funcSel = -1;
        } else if (activeTimer != 0 || sleepH != 0) {
            send(LgFrames.TIMER_CLEAR_ALL);
            if (sleepH != 0) send(LgFrames.SLEEP_CANCEL);
            activeTimer = 0;
            sleepH = 0;
            sleepEnd = 0;
            toast("Timer cancel ஆச்சு");
        } else {
            toast("Timer எதுவும் set இல்ல");
        }
    }

    private void actUnsupported(String what) {
        toast(what);
    }

    // ---------- Setup ----------

    private void actSetupToggle() {
        boolean show = setupPanel.getVisibility() != View.VISIBLE;
        setupPanel.setVisibility(show ? View.VISIBLE : View.GONE);
        remotePanel.setVisibility(show ? View.GONE : View.VISIBLE);
        btnSetup.setText(show ? "← Remote-க்கு திரும்ப" : "⚙ Setup (AC response பண்ணலன்னா)");
    }

    private void actTest() {
        send(LgFrames.state(0, 24, FAN_CODES[fanTable][3], bit15), 3);
        toast("Test அனுப்பினேன்: Cool 24°C. AC beep பண்ணுதா பாருங்க");
    }

    // ---------- Screen ----------

    private static String fmt(int min) {
        int m = min % 60;
        return (min / 60) + ":" + (m < 10 ? "0" : "") + m;
    }

    private void refresh() {
        long now = System.currentTimeMillis();
        if (activeTimer != 0 && now >= activeTimerEnd) {
            on = activeTimer == 2;
            activeTimer = 0;
            if (!on) {
                sleepH = 0;
                sleepEnd = 0;
            }
        }
        if (sleepH != 0 && now >= sleepEnd) {
            on = false;
            sleepH = 0;
            sleepEnd = 0;
        }
        if (overlayText != null && now > overlayUntil) overlayText = null;

        tvMode.setText(on ? MODE_NAMES[mode] : "OFF");
        String t;
        if (!on) t = "--";
        else if (overlayText != null) t = overlayText;
        else if (mode == 2) t = "--";
        else t = temp + "°C";
        tvTemp.setText(t);
        tvFan.setText(on ? ("FAN " + FAN_LETTER[fan] + "\n" + FAN_BARS[fan]) : "");

        StringBuilder tags = new StringBuilder();
        if (on) {
            if (swingPos != 0) tags.append("↕ ").append(SWING_NAMES[swingPos]).append("\n");
            if (hSwing) tags.append("↔ SWING\n");
            if (hcool) tags.append("H'COOL\n");
            if (energy > 0) tags.append("ENERGY\n");
            if (sleepH > 0) tags.append("SLEEP\n");
            if (clean) tags.append("CLEAN\n");
            if (purify) tags.append("PLASMA\n");
            if (!lightOn) tags.append("LIGHT-OFF\n");
        }
        tvTags.setText(tags.toString().trim());

        String bot = "";
        if (timerSel != 0) {
            bot = (timerSel == 1 ? "OFF " : "ON ") + fmt(timerMin) + " SET?";
        } else if (funcSel >= 0) {
            bot = FUNC_NAMES[funcSel] + "? SET";
        } else if (activeTimer != 0) {
            int left = (int) Math.max(0, (activeTimerEnd - now + 59999) / 60000);
            bot = (activeTimer == 1 ? "OFF " : "ON ") + fmt(left);
        } else if (sleepH != 0) {
            int left = (int) Math.max(0, (sleepEnd - now + 59999) / 60000);
            bot = "SLEEP " + fmt(left);
        }
        tvTimer.setText(bot);

        midRow.setAlpha(on ? 1f : 0.3f);
        btnPower.setText("⏻\n" + (on ? "ON" : "OFF"));
        btnPower.setBackground(roundRect(on ? POWER_ON : POWER_OFF, 6, on ? POWER_ON : POWER_OFF));
        btnPower.setTextColor(Color.WHITE);
        btnLight.setText(lightOn ? "Light\nOff" : "Light\nOn");

        sSig.setText("1) Signal type: " + (lg2 ? "LG2" : "LG1"));
        sFan.setText("2) Fan codes: " + (fanTable == 0 ? "Classic" : "Alternate"));
        sBit.setText("3) Remote-style bit: " + (bit15 ? "ON" : "OFF"));
        sRep.setText("4) அனுப்பும் முறை: " + repeats + "x");
        sOld.setText("5) Swing: " + (oldSwing ? "Old toggle" : "Positions"));
    }

    private GradientDrawable roundRect(int fill, int radiusDp, int edge) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), edge);
        return d;
    }

    private void save() {
        prefs.edit().putBoolean("on", on).putInt("temp", temp).putInt("mode", mode)
                .putInt("fan", fan).putInt("swing", swingPos).putBoolean("light", lightOn)
                .putBoolean("lg2", lg2).putInt("fanTable", fanTable).putBoolean("bit15", bit15)
                .putInt("repeats", repeats).putBoolean("oldSwing", oldSwing).apply();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ---------- UI building ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private interface Act {
        void run();
    }

    private View.OnClickListener act(final Act a) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                a.run();
                refresh();
                save();
            }
        };
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        outer.setPadding(dp(12), dp(24), dp(12), dp(24));
        sv.addView(outer, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        remotePanel = new LinearLayout(this);
        remotePanel.setOrientation(LinearLayout.VERTICAL);
        remotePanel.setPadding(dp(16), dp(18), dp(16), dp(20));
        GradientDrawable rb = new GradientDrawable();
        rb.setColor(REMOTE);
        rb.setCornerRadii(new float[]{dp(14), dp(14), dp(14), dp(14), dp(26), dp(26), dp(26), dp(26)});
        remotePanel.setBackground(rb);
        outer.addView(remotePanel, new LinearLayout.LayoutParams(dp(304), ViewGroup.LayoutParams.WRAP_CONTENT));

        remotePanel.addView(buildLcd());

        // Row 1: Comfort (no code yet), single Power toggle, Light
        btnPower = key("⏻\nOFF", 84, 56, 8, POWER_OFF, Color.WHITE, act(new Act() { public void run() { actPower(); } }));
        btnLight = key("Light\nOff", 84, 52, 26, KEY, LABEL, act(new Act() { public void run() { actLight(); } }));
        remotePanel.addView(row(
                key("Comfort\nAir", 84, 52, 26, KEY, LABEL, act(new Act() { public void run() {
                    actUnsupported("Comfort Air-க்கு IR code இன்னும் கிடைக்கல"); } })),
                btnPower,
                btnLight));
        // Row 2
        remotePanel.addView(row(
                key("Mode", 76, 76, 38, KEY, LABEL, act(new Act() { public void run() { actMode(); } })),
                key("⌃", 76, 76, 38, KEY, LABEL, act(new Act() { public void run() { actTemp(1); } })),
                key("Fan\nSpeed", 76, 76, 38, KEY, LABEL, act(new Act() { public void run() { actFan(); } }))));
        remotePanel.addView(label("Temp.", 13, Gravity.CENTER_HORIZONTAL));
        // Row 3
        remotePanel.addView(row(
                key("Energy\nCtrl.", 76, 76, 38, KEY, LABEL, act(new Act() { public void run() { actEnergy(); } })),
                key("⌄", 76, 76, 38, KEY, LABEL, act(new Act() { public void run() { actTemp(-1); } })),
                key("H’Cool", 76, 76, 38, KEY, LABEL, act(new Act() { public void run() { actHcool(); } }))));
        // Row 4: vertical swing opens the position picker
        remotePanel.addView(row(
                key("Swing\n↕", 84, 50, 8, KEY, LABEL, act(new Act() { public void run() { actSwingV(); } })),
                key("Swing\n↔", 84, 50, 8, KEY, LABEL, act(new Act() { public void run() { actSwingH(); } })),
                key("Room\nTemp.", 84, 50, 8, KEY, LABEL, act(new Act() { public void run() {
                    actUnsupported("Room temp-ஐ AC-ல இருந்து remote-க்கு படிக்க முடியாது"); } }))));
        remotePanel.addView(label("Diagnosis(5s)", 12, Gravity.END));

        // SET UP box
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(10));
        GradientDrawable bd = new GradientDrawable();
        bd.setColor(Color.TRANSPARENT);
        bd.setStroke(dp(1), LABEL);
        box.setBackground(bd);
        box.addView(label("SET UP", 15, Gravity.START));
        box.addView(row(
                key("Sleep", 84, 52, 26, KEY, LABEL, act(new Act() { public void run() { actSleep(); } })),
                key("⌃", 84, 50, 8, KEY, LABEL, act(new Act() { public void run() { actTimerStep(30); } })),
                key("Func.", 84, 52, 26, KEY, LABEL, act(new Act() { public void run() { actFunc(); } }))));
        box.addView(row(
                key("Timer", 84, 52, 26, KEY, LABEL, act(new Act() { public void run() { actTimer(); } })),
                key("⌄", 84, 50, 8, KEY, LABEL, act(new Act() { public void run() { actTimerStep(-30); } })),
                key("Set\nCancel", 84, 52, 26, KEY, LABEL, act(new Act() { public void run() { actSetCancel(); } }))));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(10);
        remotePanel.addView(box, blp);

        TextView logo = new TextView(this);
        logo.setText("LG");
        logo.setTextSize(26);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setTextColor(Color.parseColor("#4B6578"));
        logo.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.topMargin = dp(14);
        remotePanel.addView(logo, llp);

        setupPanel = buildSetupPanel();
        setupPanel.setVisibility(View.GONE);
        outer.addView(setupPanel, new LinearLayout.LayoutParams(dp(304), ViewGroup.LayoutParams.WRAP_CONTENT));

        btnSetup = new Button(this);
        btnSetup.setAllCaps(false);
        btnSetup.setTextSize(12);
        btnSetup.setTextColor(LABEL);
        btnSetup.setBackgroundColor(Color.TRANSPARENT);
        btnSetup.setText("⚙ Setup (AC response பண்ணலன்னா)");
        btnSetup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actSetupToggle();
            }
        });
        outer.addView(btnSetup, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        return sv;
    }

    private LinearLayout buildSetupPanel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable pb = new GradientDrawable();
        pb.setColor(REMOTE);
        pb.setCornerRadius(dp(16));
        p.setBackground(pb);

        TextView help = new TextView(this);
        help.setTextColor(INK);
        help.setTextSize(13);
        help.setText("AC response பண்ணலன்னா:\n"
                + "1. AC sensor பக்கம் phone-ஓட IR blaster-ஐ காட்டுங்க.\n"
                + "2. \"Test அனுப்பு\" அழுத்துங்க. AC beep பண்ணுதான்னு பாருங்க.\n"
                + "3. பண்ணலன்னா option 1 அல்லது 3-ஐ மாத்தி மறுபடி Test பண்ணுங்க.\n"
                + "4. Beep வந்த option-ஐ அப்படியே வச்சுக்கோங்க.\n"
                + "Fan மாறலன்னா option 2-ஐ மாத்துங்க. Swing ↕ வேலை செய்யலன்னா option 5-ஐ மாத்துங்க.");
        p.addView(help);

        sSig = setupBtn(new Act() { public void run() { lg2 = !lg2; } });
        sFan = setupBtn(new Act() { public void run() { fanTable = 1 - fanTable; } });
        sBit = setupBtn(new Act() { public void run() { bit15 = !bit15; } });
        sRep = setupBtn(new Act() { public void run() { repeats = repeats == 1 ? 2 : 1; } });
        p.addView(sSig);
        p.addView(sFan);
        p.addView(sBit);
        sOld = setupBtn(new Act() { public void run() { oldSwing = !oldSwing; } });
        p.addView(sRep);
        p.addView(sOld);

        Button test = setupBtn(new Act() { public void run() { actTest(); } });
        test.setText("Test அனுப்பு (Cool 24°C)");
        test.setTextColor(Color.WHITE);
        test.setBackground(roundRect(POWER_OFF, 10, POWER_OFF));
        p.addView(test);
        return p;
    }

    private Button setupBtn(Act a) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(INK);
        b.setStateListAnimator(null);
        b.setBackground(roundRect(KEY, 10, KEY_EDGE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        b.setOnClickListener(act(a));
        return b;
    }

    private View buildLcd() {
        LinearLayout lcd = new LinearLayout(this);
        lcd.setOrientation(LinearLayout.VERTICAL);
        lcd.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable ld = new GradientDrawable();
        ld.setColor(LCD);
        ld.setCornerRadius(dp(4));
        lcd.setBackground(ld);
        lcd.setMinimumHeight(dp(170));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        tvMode = mono(16, Gravity.START);
        tvMode.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tvTags = mono(10, Gravity.END);
        tvTags.setMaxLines(3);
        top.addView(tvMode, new LinearLayout.LayoutParams(dp(70), ViewGroup.LayoutParams.WRAP_CONTENT));
        top.addView(tvTags, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        lcd.addView(top);

        lcd.addView(line());

        midRow = new LinearLayout(this);
        midRow.setOrientation(LinearLayout.HORIZONTAL);
        midRow.setGravity(Gravity.CENTER_VERTICAL);
        tvTemp = mono(52, Gravity.CENTER);
        tvFan = mono(12, Gravity.END);
        midRow.addView(tvTemp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        midRow.addView(tvFan, new LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT));
        lcd.addView(midRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(92)));

        lcd.addView(line());

        LinearLayout bot = new LinearLayout(this);
        bot.setOrientation(LinearLayout.HORIZONTAL);
        bot.setGravity(Gravity.CENTER_VERTICAL);
        tvTimer = mono(13, Gravity.START);
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("a h:mm");
        clock.setFormat24Hour("a h:mm");
        clock.setTextColor(INK);
        clock.setTextSize(15);
        clock.setTypeface(Typeface.MONOSPACE);
        bot.addView(tvTimer, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bot.addView(clock);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(4);
        lcd.addView(bot, blp);

        return lcd;
    }

    private View line() {
        View v = new View(this);
        v.setBackgroundColor(INK);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return v;
    }

    private TextView mono(int sp, int gravity) {
        TextView t = new TextView(this);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextColor(INK);
        t.setTextSize(sp);
        t.setGravity(gravity);
        return t;
    }

    private TextView label(String text, int sp, int gravity) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(LABEL);
        t.setGravity(gravity);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        t.setLayoutParams(lp);
        return t;
    }

    /** Icon for a key label. 0 = no icon. */
    private int iconFor(String t) {
        if (t.startsWith("\u23FB")) return R.drawable.ic_power;
        if (t.startsWith("Light")) return R.drawable.ic_light;
        if (t.startsWith("Comfort")) return R.drawable.ic_comfort;
        if (t.equals("Mode")) return R.drawable.ic_mode;
        if (t.equals("\u2303")) return R.drawable.ic_up;
        if (t.equals("\u2304")) return R.drawable.ic_down;
        if (t.startsWith("Fan")) return R.drawable.ic_fan;
        if (t.startsWith("Energy")) return R.drawable.ic_energy;
        if (t.startsWith("H\u2019Cool")) return R.drawable.ic_hcool;
        if (t.startsWith("Swing\n\u2195")) return R.drawable.ic_swing_v;
        if (t.startsWith("Swing\n\u2194")) return R.drawable.ic_swing_h;
        if (t.startsWith("Room")) return R.drawable.ic_room;
        if (t.equals("Sleep")) return R.drawable.ic_sleep;
        if (t.equals("Func.")) return R.drawable.ic_func;
        if (t.equals("Timer")) return R.drawable.ic_timer;
        if (t.startsWith("Set")) return R.drawable.ic_check;
        return 0;
    }

    private Button key(String text, int wDp, int hDp, int radiusDp, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setStateListAnimator(null);
        // Touch feedback: ripple on the key shape
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(80, 0, 0, 0)),
                roundRect(bg, radiusDp, KEY_EDGE), null));
        int icon = iconFor(text);
        if (icon != 0) {
            Drawable d = getDrawable(icon);
            d.setTint(fg);
            b.setCompoundDrawablesWithIntrinsicBounds(null, d, null, null);
            b.setCompoundDrawablePadding(dp(2));
        }
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(wDp), dp(hDp)));
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getActionMasked();
                if (a == MotionEvent.ACTION_DOWN) v.setAlpha(0.65f);
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) v.setAlpha(1f);
                return false;
            }
        });
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout row(View a, View b, View c) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        View[] vs = {a, b, c};
        for (View v : vs) {
            LinearLayout cell = new LinearLayout(this);
            cell.setGravity(Gravity.CENTER);
            cell.addView(v);
            r.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        r.setLayoutParams(lp);
        return r;
    }
}
