package com.example.lgacremote;

/**
 * LG split-AC 28-bit IR frames. No Android classes here so it can be unit tested.
 *
 * Frame: bits 27..20 = 0x88, 19..4 = payload, 3..0 = checksum
 * (sum of nibbles 1..4, mod 16).
 *
 * Codes come from IRremoteESP8266 ir_LG.h and the Nosdave/ha-lg-ac-infrared codec.
 * Only the state frame, power off, sleep, swing and fan codes are verified against
 * real captures. Jet (H'Cool), Light, Clean and Plasma are NOT verified on AKB75415302.
 */
final class LgFrames {
    private LgFrames() {}

    static final int OFF = 0x88C0051;
    static final int LIGHT_TOGGLE = 0x88C00A6;
    static final int JET_ON = 0x8810089;

    static final int PURIFY_ON = 0x88C000C;
    static final int PURIFY_OFF = 0x88C0084;
    static final int CLEAN_ON = 0x88C00B7;
    static final int CLEAN_OFF = 0x88C00C8;

    /** Energy control: off, 80%, 60%, 40%. */
    static final int[] ENERGY = {0x88C07F2, 0x88C07D0, 0x88C07E1, 0x88C0804};

    /** Vertical swing positions, in the order shown in the picker. */
    static final int[] SWING_V = {
        0x881315A, // Off
        0x8813149, // Auto swing
        0x881309D, // Highest
        0x881308C, // High
        0x881307B, // Upper-middle
        0x881306A, // Middle
        0x8813059, // Low
        0x8813048, // Lowest
    };

    static final int SWING_V_TOGGLE = 0x8810001; // older remotes: one button toggles swing
    static final int SWING_H_ON = 0x881316B;
    static final int SWING_H_OFF = 0x881317C;

    static final int TIMER_CLEAR_ALL = 0x88B000B;
    static final int SLEEP_CANCEL = 0x88A000A;

    static int checksum(int frame) {
        int s = 0;
        for (int i = 1; i <= 4; i++) {
            s += (frame >> (4 * i)) & 0xF;
        }
        return s & 0xF;
    }

    private static int withChecksum(int frameNoSum) {
        return (frameNoSum & 0x0FFFFFF0) | checksum(frameNoSum);
    }

    /** Normal "set everything" frame. temp is 16..30. */
    static int state(int mode, int temp, int fan, boolean bit15) {
        int t = Math.max(16, Math.min(30, temp)) - 15;
        int f = 0x88 << 20;
        if (bit15) f |= 0x8000;
        f |= (mode & 7) << 12;
        f |= (t & 0xF) << 8;
        f |= (fan & 0xF) << 4;
        return withChecksum(f);
    }

    /** Sleep timer, minutes 0..1439 (0 cancels). */
    static int sleep(int minutes) {
        int m = Math.max(0, Math.min(1439, minutes));
        return withChecksum(((0x88A000 | m) << 4));
    }

    /** Delayed on / off, minutes 0..1439. */
    static int schedule(boolean turnOn, int minutes) {
        int m = Math.max(0, Math.min(1439, minutes));
        int func = turnOn ? 0x8 : 0x9;
        return withChecksum((((0x88 << 16) | (func << 12) | m) << 4));
    }

    /**
     * Raw on/off pattern in microseconds for ConsumerIrManager (carrier 38 kHz).
     * lg2 = alternative header timing used by some newer LG remotes.
     */
    static int[] pattern(int frame, boolean lg2, int repeats) {
        int hdrMark = lg2 ? 3200 : 8500;
        int hdrSpace = lg2 ? 9900 : 4250;
        int bitMark = lg2 ? 480 : 560;
        int one = 1600;
        int zero = 560;
        int gap = 40000;
        int n = Math.max(1, repeats);
        int perFrame = 2 + 28 * 2 + 1;
        int[] p = new int[perFrame * n + (n - 1)];
        int k = 0;
        for (int r = 0; r < n; r++) {
            if (r > 0) p[k++] = gap;
            p[k++] = hdrMark;
            p[k++] = hdrSpace;
            for (int b = 27; b >= 0; b--) {
                p[k++] = bitMark;
                p[k++] = ((frame >> b) & 1) == 1 ? one : zero;
            }
            p[k++] = bitMark;
        }
        return p;
    }
}
