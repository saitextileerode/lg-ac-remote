package com.example.lgacremote;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Simple drawing of a wall unit. Shows cool airflow when the AC is on. */
public class AcView extends View {

    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint slot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint flow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();
    private final float density;
    private final float sp;
    private boolean on = false;

    public AcView(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        sp = getResources().getDisplayMetrics().scaledDensity;
        slot.setColor(0xFF2A3550);
        label.setTextAlign(Paint.Align.CENTER);
        flow.setStyle(Paint.Style.STROKE);
        flow.setStrokeCap(Paint.Cap.ROUND);
        flow.setStrokeWidth(3 * density);
    }

    public void setOn(boolean on) {
        if (this.on != on) {
            this.on = on;
            invalidate();
        }
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        setMeasuredDimension(MeasureSpec.getSize(widthSpec), (int) (104 * density));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float bw = Math.min(w - 24 * density, 320 * density);
        float bx = (w - bw) / 2f;
        float by = 6 * density;
        float bh = 54 * density;

        body.setShader(new LinearGradient(0, by, 0, by + bh, 0xFFFFFFFF, 0xFFC4CFE4, Shader.TileMode.CLAMP));
        rect.set(bx, by, bx + bw, by + bh);
        canvas.drawRoundRect(rect, 14 * density, 14 * density, body);

        rect.set(bx + 18 * density, by + bh - 13 * density, bx + bw - 18 * density, by + bh - 7 * density);
        canvas.drawRoundRect(rect, 3 * density, 3 * density, slot);

        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setColor(0xFF3A4766);
        label.setTextSize(15 * sp);
        canvas.drawText("LG", bx + bw / 2f, by + bh * 0.52f, label);
        label.setTypeface(Typeface.DEFAULT);
        label.setTextSize(8 * sp);
        label.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("DUAL Inverter", bx + bw - 20 * density, by + bh * 0.44f, label);
        label.setTextAlign(Paint.Align.CENTER);

        if (on) {
            float y0 = by + bh - 4 * density;
            float y1 = getHeight() - 4 * density;
            flow.setShader(new LinearGradient(0, y0, 0, y1, 0xCC3FD0FF, 0x003FD0FF, Shader.TileMode.CLAMP));
            for (int i = 0; i < 5; i++) {
                float x = bx + bw * (0.22f + 0.14f * i);
                float ex = x + (i - 2) * 26 * density;
                path.reset();
                path.moveTo(x, y0);
                path.quadTo(x, y0 + (y1 - y0) * 0.45f, ex, y1);
                canvas.drawPath(path, flow);
            }
        }
    }
}
