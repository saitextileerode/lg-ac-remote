package com.example.lgacremote;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Round temperature dial with a neon arc. */
public class DialView extends View {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float density;
    private final float sp;

    private String top = "OFF";
    private String big = "--";
    private String unit = "";
    private float frac = 0f;
    private boolean on = false;

    public DialView(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        sp = getResources().getDisplayMetrics().scaledDensity;

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setStrokeWidth(10 * density);
        track.setColor(0x331E4A7A);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setStrokeWidth(24 * density);
        glow.setColor(0x333FD0FF);

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(10 * density);
        arc.setColor(0xFF3FD0FF);

        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setState(String top, String big, String unit, float frac, boolean on) {
        this.top = top;
        this.big = big;
        this.unit = unit;
        this.frac = Math.max(0f, Math.min(1f, frac));
        this.on = on;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int s = Math.min(MeasureSpec.getSize(widthSpec), (int) (224 * density));
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float r = Math.min(cx, cy) - 18 * density;
        oval.set(cx - r, cy - r, cx + r, cy + r);

        // Track: 240 degree arc starting at lower-left
        canvas.drawArc(oval, 150, 240, false, track);

        if (on && frac > 0f) {
            float sweep = 240 * frac;
            canvas.drawArc(oval, 150, sweep, false, glow);
            canvas.drawArc(oval, 150, sweep, false, arc);
        }

        // Mode / state label at top of the dial
        text.setColor(0xFF3FD0FF);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(13 * sp);
        canvas.drawText(top, cx, cy - r * 0.42f, text);

        // Big number and unit
        text.setColor(0xFFEAF6FF);
        text.setTextSize(60 * sp);
        canvas.drawText(big, cx - 8 * density, cy + r * 0.22f, text);
        float half = text.measureText(big) / 2f;
        text.setTextSize(22 * sp);
        text.setTypeface(Typeface.DEFAULT);
        text.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(unit, cx - 8 * density + half + 4 * density, cy + r * 0.22f - 22 * density, text);
        text.setTextAlign(Paint.Align.CENTER);

        // Caption
        text.setColor(0xFF7FA6C9);
        text.setTextSize(11 * sp);
        canvas.drawText("TEMP", cx, cy + r * 0.56f, text);
    }
}
