package com.example.lgacremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    static final int NEON = 0xFF3FD0FF;
    static final int GLASS = 0xCC0E2347;
    static final int GLASS_EDGE = 0x663FD0FF;
    static final int OFF_EDGE = 0x552A4A6E;
    static final int TEXT = 0xFFEAF6FF;
    static final int MUTED = 0xFF7FA6C9;
    static final int BG_TOP = 0xFF040B1C;
    static final int BG_BOT = 0xFF0A1A38;

    static final String[] MODE_NAMES = {"Cool", "Dry", "Fan", "Auto"};
    static final int[] MODE_CODE = {0, 1, 2, 3};
    static final String[] FAN_NAMES = {"Low", "Mid", "High", "Auto"};
    static final int[][] FAN_CODES = {{0, 2, 4, 5}, {9, 2, 10, 5}};
    static final int[] ENERGY_PCT = {0, 80, 60, 40};
    static final String[] SWING_NAMES = {"Off", "Auto swing", "Highest", "High", "Upper-middle", "Middle", "Low", "Lowest"};
    static final int[] DUR_MIN = {30, 60, 120, 180, 240, 360, 480, 600, 720};
    static final String[] DUR_LABEL = {"30 நிமிஷம்", "1 மணி", "2 மணி", "3 மணி", "4 மணி", "6 மணி", "8 மணி", "10 மணி", "12 மணி"};

    private SharedPreferences prefs;
    private ConsumerIrManager ir;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    // AC state
    private boolean on;
    private int temp = 24;
    private int mode = 0;
    private int fan = 3;
    private int swingPos = 0;
    private boolean hSwing, hcool, lightOn = true, clean, purify, oldSwing;
    private int energy = 0;
    private int sleepH = 0;
    private long sleepEnd = 0;
    private int activeTimer = 0;      // 0 none, 1 off, 2 on
    private long activeTimerEnd = 0;

    // Setup
    private boolean lg2 = false;
    private int fanTable = 1;         // user-verified: "New" fan codes
    private boolean bit15 = false;    // user-verified: remote-style bit OFF
    private int repeats = 1;

    private String overlayText = null;
    private long overlayUntil = 0;

    // Views
    private DialView dial;
    private TextView tvStatus, tvModeVal, tvFanVal, tvSwingVVal, tvSwingHVal, tvLightVal, tvTimerLine, tvPowerLbl;
    private ImageView powerIcon;
    private LinearLayout powerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("lgac4", MODE_PRIVATE);
        on = prefs.getBoolean("on", false);
        temp = prefs.getInt("temp", 24);
        mode = prefs.getInt("mode", 0);
        fan = prefs.getInt("fan", 3);
        swingPos = prefs.getInt("swing", 0);
        oldSwing = prefs.getBoolean("oldSwing", false);
        lightOn = prefs.getBoolean("light", true);
        lg2 = prefs.getBoolean("lg2", false);
        fanTable = prefs.getInt("fanTable", 1);
        bit15 = prefs.getBoolean("bit15", false);
        repeats = prefs.getInt("repeats", 1);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        setContentView(buildUi());
        refresh();
        if (ir == null || !ir.hasIrEmitter()) {
            toast("இந்த phone-ல IR blaster கண்டுபிடிக்க முடியல");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
        save();
    }

    // ---------- IR ----------

    private void send(int frame) {
        send(frame, repeats);
    }

    private void send(int frame, int reps) {
        if (ir == null || !ir.hasIrEmitter()) {
            toast("IR blaster இல்ல");
            return;
        }
        try {
            ir.transmit(38000, LgFrames.pattern(frame, lg2, reps));
        } catch (Exception e) {
            toast("IR அனுப்ப முடியல");
        }
    }

    private void sendState() {
        send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15));
    }

    // ---------- Actions ----------

    private boolean needOn() {
        if (!on) {
            toast("முதல்ல Power ON பண்ணுங்க");
            return false;
        }
        return true;
    }

    private void actPower() {
        if (!on) {
            on = true;
            send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15), 3);
        } else {
            on = false;
            send(LgFrames.OFF, 3);
            sleepH = 0;
            sleepEnd = 0;
            hcool = false;
            if (activeTimer == 1) activeTimer = 0;
        }
    }

    private void actMode() {
        if (!needOn()) return;
        hcool = false;
        mode = (mode + 1) % MODE_NAMES.length;
        sendState();
    }

    private void actFan() {
        if (!needOn()) return;
        hcool = false;
        fan = (fan + 1) % FAN_NAMES.length;
        sendState();
    }

    private void actTemp(int delta) {
        if (!needOn()) return;
        hcool = false;
        temp = Math.max(16, Math.min(30, temp + delta));
        overlayText = null;
        sendState();
    }

    private void actHcool() {
        if (!needOn()) return;
        if (!hcool) {
            hcool = true;
            send(LgFrames.JET_ON);
        } else {
            hcool = false;
            sendState();
        }
    }

    private void actEnergy() {
        if (!needOn()) return;
        energy = (energy + 1) % ENERGY_PCT.length;
        send(LgFrames.ENERGY[energy]);
        if (energy > 0) {
            overlayText = ENERGY_PCT[energy] + " %";
            overlayUntil = System.currentTimeMillis() + 4000;
        } else {
            overlayText = null;
        }
    }

    private void actLight() {
        if (!needOn()) return;
        lightOn = !lightOn;
        send(LgFrames.LIGHT_TOGGLE);
    }

    private void actSwingH() {
        if (!needOn()) return;
        hSwing = !hSwing;
        send(hSwing ? LgFrames.SWING_H_ON : LgFrames.SWING_H_OFF);
    }

    private void actSwingVPicker() {
        if (!needOn()) return;
        if (oldSwing) {
            swingPos = swingPos == 0 ? 1 : 0;
            send(LgFrames.SWING_V_TOGGLE);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Vertical swing")
                .setSingleChoiceItems(SWING_NAMES, swingPos, null)
                .setPositiveButton("Set", (d, w) -> {
                    int sel = ((AlertDialog) d).getListView().getCheckedItemPosition();
                    if (sel < 0) sel = swingPos;
                    swingPos = sel;
                    send(LgFrames.SWING_V[swingPos]);
                    refresh();
                    save();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void actSleep() {
        if (!needOn()) return;
        sleepH = (sleepH + 1) % 8;
        send(LgFrames.sleep(sleepH * 60));
        sleepEnd = sleepH == 0 ? 0 : System.currentTimeMillis() + sleepH * 3600000L;
        toast(sleepH == 0 ? "Sleep timer off" : "Sleep: " + sleepH + " மணி நேரத்துல AC off ஆகும்");
    }

    private void showTimerDialog() {
        String[] kinds = {"OFF timer set பண்ணு", "ON timer set பண்ணு", "Timer cancel பண்ணு"};
        new AlertDialog.Builder(this)
                .setTitle("Timer")
                .setItems(kinds, (d, w) -> {
                    if (w == 2) {
                        send(LgFrames.TIMER_CLEAR_ALL);
                        if (sleepH != 0) send(LgFrames.SLEEP_CANCEL);
                        activeTimer = 0;
                        sleepH = 0;
                        sleepEnd = 0;
                        toast("Timer cancel ஆச்சு");
                    } else {
                        pickDuration(w == 1);
                    }
                })
                .show();
    }

    private void pickDuration(boolean turnOn) {
        new AlertDialog.Builder(this)
                .setTitle(turnOn ? "ON timer எவ்வளவு நேரம் கழிச்சு?" : "OFF timer எவ்வளவு நேரம் கழிச்சு?")
                .setItems(DUR_LABEL, (d, w) -> {
                    int min = DUR_MIN[w];
                    send(LgFrames.schedule(turnOn, min));
                    activeTimer = turnOn ? 2 : 1;
                    activeTimerEnd = System.currentTimeMillis() + min * 60000L;
                    toast((turnOn ? "ON" : "OFF") + " timer set ஆச்சு");
                })
                .show();
    }

    private void showMoreDialog() {
        String[] items = {
                "H'Cool (Jet)",
                "Energy control",
                "Auto clean: " + (clean ? "ON" : "OFF"),
                "Plasma: " + (purify ? "ON" : "OFF"),
                "Comfort Air (code இல்ல)",
                "Room temp (example)",
                "Setup"
        };
        new AlertDialog.Builder(this)
                .setTitle("More")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0: actHcool(); break;
                        case 1: actEnergy(); break;
                        case 2:
                            if (!needOn()) break;
                            clean = !clean;
                            send(clean ? LgFrames.CLEAN_ON : LgFrames.CLEAN_OFF);
                            break;
                        case 3:
                            if (!needOn()) break;
                            purify = !purify;
                            send(purify ? LgFrames.PURIFY_ON : LgFrames.PURIFY_OFF);
                            break;
                        case 4: toast("Comfort Air-க்கு IR code இன்னும் கிடைக்கல"); break;
                        case 5: overlayText = "29 °C"; overlayUntil = System.currentTimeMillis() + 3000; break;
                        case 6: showSetup(); break;
                        default: break;
                    }
                    refresh();
                    save();
                })
                .show();
    }

    private void showSetup() {
        String[] items = {
                "1) Signal type: " + (lg2 ? "LG2" : "LG1"),
                "2) Fan codes: " + (fanTable == 0 ? "Classic" : "New"),
                "3) Remote-style bit: " + (bit15 ? "ON" : "OFF"),
                "4) அனுப்பும் முறை: " + repeats + "x",
                "5) Swing: " + (oldSwing ? "Old toggle" : "Positions"),
                "Test அனுப்பு (Cool 24°C)"
        };
        new AlertDialog.Builder(this)
                .setTitle("Setup")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0: lg2 = !lg2; break;
                        case 1: fanTable = 1 - fanTable; break;
                        case 2: bit15 = !bit15; break;
                        case 3: repeats = repeats == 1 ? 2 : 1; break;
                        case 4: oldSwing = !oldSwing; break;
                        case 5:
                            send(LgFrames.state(0, 24, FAN_CODES[fanTable][3], bit15), 3);
                            toast("Test அனுப்பினேன். AC beep பண்ணுதா பாருங்க");
                            return;
                        default: return;
                    }
                    save();
                    showSetup();
                })
                .show();
    }

    // ---------- Screen ----------

    private static String fmt(int min) {
        int m = min % 60;
        return (min / 60) + ":" + (m < 10 ? "0" : "") + m;
    }

    private void refresh() {
        long now = System.currentTimeMillis();
        if (activeTimer != 0 && now >= activeTimerEnd) {
            on = activeTimer == 2;
            activeTimer = 0;
            if (!on) {
                sleepH = 0;
                sleepEnd = 0;
            }
        }
        if (sleepH != 0 && now >= sleepEnd) {
            on = false;
            sleepH = 0;
            sleepEnd = 0;
        }
        if (overlayText != null && now > overlayUntil) overlayText = null;

        // Dial
        String big;
        String unit = "°C";
        if (!on) {
            big = "--";
            unit = "";
        } else if (overlayText != null) {
            big = overlayText;
            unit = "";
        } else if (mode == 2) {
            big = "--";
            unit = "";
        } else {
            big = String.valueOf(temp);
        }
        float frac = (temp - 16) / 14f;
        dial.setState(on ? (hcool ? "H'COOL" : MODE_NAMES[mode].toUpperCase()) : "OFF", big, unit, frac, on);

        // Cards
        tvModeVal.setText(on ? MODE_NAMES[mode] : "Off");
        tvFanVal.setText(on ? FAN_NAMES[fan] : "Off");
        tvSwingVVal.setText(SWING_NAMES[swingPos]);
        tvSwingHVal.setText(hSwing ? "On" : "Off");
        tvLightVal.setText(lightOn ? "On" : "Off");

        // Status line under the dial
        StringBuilder st = new StringBuilder();
        if (on) {
            if (energy > 0) st.append("ENERGY ").append(ENERGY_PCT[energy]).append("%   ");
            if (sleepH > 0) st.append("SLEEP   ");
            if (clean) st.append("CLEAN   ");
            if (purify) st.append("PLASMA   ");
        }
        tvStatus.setText(st.toString().trim());

        // Timer line
        String t = "";
        if (activeTimer != 0) {
            int left = (int) Math.max(0, (activeTimerEnd - now + 59999) / 60000);
            t = (activeTimer == 1 ? "OFF " : "ON ") + fmt(left);
        } else if (sleepH != 0) {
            int left = (int) Math.max(0, (sleepEnd - now + 59999) / 60000);
            t = "SLEEP " + fmt(left);
        }
        tvTimerLine.setText(t);

        // Power look
        int edge = on ? NEON : OFF_EDGE;
        powerBtn.setBackground(ripple(shape(true, GLASS, edge, on ? 2 : 1)));
        powerIcon.setColorFilter(on ? NEON : MUTED);
        tvPowerLbl.setText(on ? "ON" : "OFF");
        tvPowerLbl.setTextColor(on ? NEON : MUTED);
    }

    private void save() {
        prefs.edit().putBoolean("on", on).putInt("temp", temp).putInt("mode", mode)
                .putInt("fan", fan).putInt("swing", swingPos).putBoolean("light", lightOn)
                .putBoolean("lg2", lg2).putInt("fanTable", fanTable).putBoolean("bit15", bit15)
                .putInt("repeats", repeats).putBoolean("oldSwing", oldSwing).apply();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ---------- UI building ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(boolean rounded, int fill, int edge, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        if (rounded) d.setCornerRadius(dp(18));
        d.setStroke(dp(strokeDp), edge);
        return d;
    }

    private RippleDrawable ripple(GradientDrawable content) {
        return new RippleDrawable(ColorStateList.valueOf(Color.argb(90, 63, 208, 255)), content, null);
    }

    private View.OnClickListener act(Runnable r) {
        return v -> {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            r.run();
            refresh();
            save();
        };
    }

    private ImageView icon(int res, int sizeDp) {
        ImageView iv = new ImageView(this);
        Drawable d = getDrawable(res).mutate();
        iv.setImageDrawable(d);
        iv.setColorFilter(NEON);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        iv.setPadding(0, 0, 0, dp(2));
        return iv;
    }

    private TextView caption(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Glass card: icon + title, optional value line. */
    private LinearLayout card(int iconRes, String title, TextView value, Runnable onTap, int heightDp) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4), dp(6), dp(4), dp(6));
        c.setBackground(ripple(shape(true, GLASS, GLASS_EDGE, 1)));
        c.setClickable(true);
        c.setOnClickListener(act(onTap));
        if (iconRes != 0) c.addView(icon(iconRes, 22));
        c.addView(caption(title, 10, MUTED, false));
        if (value != null) c.addView(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(heightDp), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout pill(String symbol, Runnable onTap) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER);
        c.setClickable(true);
        c.setBackground(ripple(shape(true, GLASS, GLASS_EDGE, 1)));
        c.setOnClickListener(act(onTap));
        c.addView(caption(symbol, 26, TEXT, true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(56), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView valueText() {
        return caption("", 15, TEXT, true);
    }

    private LinearLayout row(View... views) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        for (View v : views) r.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        r.setLayoutParams(lp);
        return r;
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_TOP, BG_BOT});
        sv.setBackground(bg);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(20), dp(16), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // Header: LG + model, setup gear on the right
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = caption("LG", 24, NEON, true);
        logo.setGravity(Gravity.START);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(10), 0, 0, 0);
        titles.addView(caption("AC Remote", 17, TEXT, true));
        TextView model = caption("AKB75415302", 11, MUTED, false);
        model.setGravity(Gravity.START);
        titles.addView(model);
        TextView gear = caption("⚙", 24, MUTED, false);
        gear.setPadding(dp(10), dp(4), dp(10), dp(4));
        gear.setClickable(true);
        gear.setOnClickListener(v -> showSetup());
        header.addView(logo);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(gear);
        root.addView(header);

        // Dial
        dial = new DialView(this);
        LinearLayout dialWrap = new LinearLayout(this);
        dialWrap.setGravity(Gravity.CENTER);
        dialWrap.addView(dial);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(12);
        root.addView(dialWrap, dlp);

        tvStatus = caption("", 11, NEON, true);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(4);
        root.addView(tvStatus, slp);

        // Mode / Fan cards
        tvModeVal = valueText();
        tvFanVal = valueText();
        root.addView(row(
                card(R.drawable.ic_mode, "MODE", tvModeVal, this::actMode, 88),
                card(R.drawable.ic_fan, "FAN SPEED", tvFanVal, this::actFan, 88)));

        // Temp -/+ pills
        root.addView(row(
                pill("\u2212", () -> actTemp(-1)),
                pill("+", () -> actTemp(1))));

        // Swing row
        tvSwingVVal = valueText();
        tvSwingHVal = valueText();
        root.addView(row(
                card(R.drawable.ic_swing_v, "SWING ↕", tvSwingVVal, this::actSwingVPicker, 76),
                card(R.drawable.ic_swing_h, "SWING ↔", tvSwingHVal, this::actSwingH, 76)));

        // Timer / Sleep / Light / More
        tvLightVal = valueText();
        root.addView(row(
                card(R.drawable.ic_timer, "TIMER", null, this::showTimerDialog, 72),
                card(R.drawable.ic_sleep, "SLEEP", null, this::actSleep, 72),
                card(R.drawable.ic_light, "LIGHT", tvLightVal, this::actLight, 72),
                card(0, "MORE", null, this::showMoreDialog, 72)));

        tvTimerLine = caption("", 13, NEON, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(10);
        root.addView(tvTimerLine, tlp);

        // Big power button
        powerBtn = new LinearLayout(this);
        powerBtn.setOrientation(LinearLayout.VERTICAL);
        powerBtn.setGravity(Gravity.CENTER);
        powerBtn.setClickable(true);
        powerBtn.setOnClickListener(act(this::actPower));
        powerIcon = new ImageView(this);
        powerIcon.setImageDrawable(getDrawable(R.drawable.ic_power).mutate());
        powerIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        tvPowerLbl = caption("OFF", 11, MUTED, true);
        powerBtn.addView(powerIcon);
        powerBtn.addView(tvPowerLbl);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(92), dp(92));
        LinearLayout powerWrap = new LinearLayout(this);
        powerWrap.setGravity(Gravity.CENTER);
        powerWrap.addView(powerBtn, plp);
        LinearLayout.LayoutParams pwlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pwlp.topMargin = dp(18);
        root.addView(powerWrap, pwlp);

        return sv;
    }
}
