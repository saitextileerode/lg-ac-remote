package com.example.lgacremote;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

/** Round temperature dial. Drag or tap on the ring to set 16..30 degrees. */
public class DialView extends View {

    public interface Listener {
        void onPreview(int temp);
        void onCommit(int temp);
        void onBlocked();
    }

    private static final float START = 172f;
    private static final float TOTAL = 196f;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float density;
    private final float sp;

    private Listener listener;
    private String top = "OFF";
    private String big = "--";
    private String unit = "";
    private float frac = 0f;
    private boolean on = false;
    private int modeIcon = 0;
    private final Paint ico = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.Path ipath = new android.graphics.Path();
    private boolean dragging = false;
    private int lastTemp = -1;
    private static final float TOP_PAD = 22f, BOT_PAD = 50f;
    private float rad = 100f;
    private float cx, cy;
    private int maxSizePx = -1;

    // ---- animated mode scene (ice / dry / fan / auto) in the dial centre ----
    private static final int NS = 18;
    private final Paint sc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final Path spath = new Path();
    private final Path cracks = new Path();
    private final RectF rr = new RectF();
    private final float[] sa = new float[NS], sb = new float[NS], sc2 = new float[NS];
    private Shader coolBg, dryBg, fanBg, autoBg;
    private int fanLevel = 2;
    private long burstAt = -100000L;
    private long lastFrame = 0L;
    private float tAnim = 0f, fanAngle = 0f;
    private boolean centerDown = false;
    private float downX, downY;

    public DialView(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        sp = getResources().getDisplayMetrics().scaledDensity;
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setStrokeWidth(20 * density);
        track.setColor(0x551E4AA8);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setStrokeWidth(30 * density);
        glow.setMaskFilter(new BlurMaskFilter(20 * density, BlurMaskFilter.Blur.NORMAL));

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(20 * density);

        knobFill.setStyle(Paint.Style.FILL);
        knobFill.setColor(0xFFFFFFFF);
        knobFill.setShadowLayer(16 * density, 0, 0, 0xFF00DFFF);
        knobRing.setStyle(Paint.Style.STROKE);
        knobRing.setStrokeWidth(3 * density);
        knobRing.setColor(0xFF00DFFF);

        text.setTextAlign(Paint.Align.CENTER);

        Random rnd = new Random(11);
        for (int i = 0; i < NS; i++) {
            sa[i] = rnd.nextFloat();
            sb[i] = rnd.nextFloat();
            sc2[i] = rnd.nextFloat();
        }
        sc.setStrokeCap(Paint.Cap.ROUND);
        sc.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setMaxSize(int px) {
        maxSizePx = px;
        requestLayout();
    }

    public void setFanLevel(int level) {
        fanLevel = Math.max(1, Math.min(4, level));
    }

    /** Plays the short "boost" of the current mode animation (ice pop / cracks / fast fan). */
    public void burst() {
        burstAt = SystemClock.uptimeMillis();
        invalidate();
    }

    private float burstValue() {
        long age = SystemClock.uptimeMillis() - burstAt;
        if (age < 0 || age > 2600) return 0f;
        if (age < 350) return age / 350f;
        float k = 1f - (age - 350) / 2250f;
        return k * k * (3 - 2 * k);
    }

    private int modeColor() {
        switch (modeIcon) {
            case 1: return 0xFFFFA23A;
            case 2: return 0xFF4DFFC0;
            case 3: return 0xFFB94DFF;
            default: return 0xFF00DFFF;
        }
    }

    public void setModeIcon(int m) {
        if (m != modeIcon) {
            modeIcon = m;
            burst();
        }
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setState(String top, String big, String unit, float frac, boolean on) {
        this.top = top;
        this.big = big;
        this.unit = unit;
        this.frac = Math.max(0f, Math.min(1f, frac));
        if (on && !this.on) burstAt = SystemClock.uptimeMillis();
        this.on = on;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = MeasureSpec.getSize(widthSpec);
        float maxH = maxSizePx > 0 ? maxSizePx : 340 * density;
        rad = Math.min(w / 2f - 22 * density, maxH - (TOP_PAD + BOT_PAD) * density);
        rad = Math.max(rad, 60 * density);
        setMeasuredDimension(w, (int) (rad + (TOP_PAD + BOT_PAD) * density));
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        cx = w / 2f;
        cy = TOP_PAD * density + rad;
        SweepGradient g = new SweepGradient(cx, cy,
                new int[]{0xFF00DFFF, 0xFF2F8BFF, 0xFFB94DFF, 0xFF00DFFF},
                new float[]{0f, 0.27f, 0.54f, 1f});
        Matrix m = new Matrix();
        m.setRotate(START, cx, cy);
        g.setLocalMatrix(m);
        arc.setShader(g);
        glow.setShader(g);

        float sr = radius() * 0.86f;
        coolBg = new RadialGradient(cx, cy, sr, new int[]{0x883FD0FF, 0x333FD0FF, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        dryBg = new RadialGradient(cx, cy, sr, new int[]{0x88FF9A2E, 0x33FF6A00, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        fanBg = new RadialGradient(cx, cy, sr, new int[]{0x774DFFC0, 0x2A2FBFA0, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        autoBg = new RadialGradient(cx, cy, sr, new int[]{0x77C58BFF, 0x2A8A5BFF, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);

        // cracked-earth pattern for DRY mode
        cracks.reset();
        Random rnd = new Random(5);
        for (int k = 0; k < 7; k++) {
            float x = cx + (rnd.nextFloat() * 1.3f - 0.65f) * sr;
            float y = cy + sr * 0.95f;
            cracks.moveTo(x, y);
            for (int seg = 0; seg < 5; seg++) {
                x += (rnd.nextFloat() - 0.5f) * sr * 0.32f;
                y -= sr * (0.14f + 0.12f * rnd.nextFloat());
                cracks.lineTo(x, y);
                if (seg == 1 || seg == 3) {
                    float bx = x + (rnd.nextFloat() - 0.5f) * sr * 0.5f;
                    float by = y - sr * 0.12f;
                    cracks.lineTo(bx, by);
                    cracks.moveTo(x, y);
                }
            }
        }
    }

    private float radius() {
        return rad;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0L ? 0f : Math.min(50, now - lastFrame) / 1000f;
        lastFrame = now;
        tAnim += dt;

        float r = radius();
        oval.set(cx - r, cy - r, cx + r, cy + r);
        int mc = modeColor();
        float k = Math.max(0.65f, Math.min(1.1f, r / (140 * density)));

        canvas.drawArc(oval, START, TOTAL, false, track);

        float sweep = TOTAL * frac;
        if (on) {
            if (sweep > 0.5f) {
                canvas.drawArc(oval, START, sweep, false, glow);
                canvas.drawArc(oval, START, sweep, false, arc);
            }
            double rad = Math.toRadians(START + sweep);
            float kx = cx + (float) (r * Math.cos(rad));
            float ky = cy + (float) (r * Math.sin(rad));
            canvas.drawCircle(kx, ky, (dragging ? 17 : 14) * density, knobFill);
            canvas.drawCircle(kx, ky, (dragging ? 17 : 14) * density, knobRing);
        }

        // Scale end labels
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(20 * sp * k);
        double a1 = Math.toRadians(START);
        double a2 = Math.toRadians(START + TOTAL);
        canvas.drawText("16", cx + (float) (r * Math.cos(a1)) + 4 * density, cy + (float) (r * Math.sin(a1)) + 24 * density * k, text);
        canvas.drawText("30", cx + (float) (r * Math.cos(a2)) - 4 * density, cy + (float) (r * Math.sin(a2)) + 24 * density * k, text);

        // Mode icon + label
        if (on) drawModeIcon(canvas, cx, cy - r * 0.70f, 18 * density * k, mc);
        text.setColor(mc);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(24 * sp * k);
        text.setShadowLayer(12 * density, 0, 0, mc);
        canvas.drawText(top, cx, cy - r * 0.38f, text);

        // Big number and unit
        text.setColor(0xFFFFFFFF);
        text.setTextSize(big.length() > 2 ? 46 * sp * k : 70 * sp * k);
        text.setShadowLayer(18 * density, 0, 0, mc);
        float shift = unit.isEmpty() ? 0f : 14 * density;
        canvas.drawText(big, cx - shift, cy + r * 0.10f, text);
        if (!unit.isEmpty()) {
            float half = text.measureText(big) / 2f;
            text.setTextSize(24 * sp * k);
            text.setTypeface(Typeface.DEFAULT);
            text.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(unit, cx - shift + half + 4 * density, cy + r * 0.10f - 34 * density * k, text);
            text.setTextAlign(Paint.Align.CENTER);
        }
        text.clearShadowLayer();

        text.setColor(0xFFFFFFFF);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(18 * sp * k);
        canvas.drawText("TEMP", cx, cy + r * 0.32f, text);

    }

    private void drawModeIcon(Canvas c, float x, float y, float s, int color) {
        ico.setStyle(Paint.Style.STROKE);
        ico.setStrokeCap(Paint.Cap.ROUND);
        ico.setStrokeWidth(3.2f * density);
        ico.setColor(color);
        ico.setShadowLayer(10 * density, 0, 0, color);
        switch (modeIcon) {
            case 0: // snowflake
                for (int k = 0; k < 3; k++) {
                    double a = Math.PI * k / 3 + Math.PI / 2;
                    float dx = (float) Math.cos(a) * s;
                    float dy = (float) Math.sin(a) * s;
                    c.drawLine(x - dx, y - dy, x + dx, y + dy, ico);
                    for (int sgn = -1; sgn <= 1; sgn += 2) {
                        float bx = x + dx * 0.62f * sgn;
                        float by = y + dy * 0.62f * sgn;
                        double a1 = a + 0.9;
                        double a2 = a - 0.9;
                        c.drawLine(bx, by, bx + (float) Math.cos(a1) * s * 0.3f * sgn, by + (float) Math.sin(a1) * s * 0.3f * sgn, ico);
                        c.drawLine(bx, by, bx + (float) Math.cos(a2) * s * 0.3f * sgn, by + (float) Math.sin(a2) * s * 0.3f * sgn, ico);
                    }
                }
                break;
            case 1: // water drop
                ipath.reset();
                ipath.moveTo(x, y - s);
                ipath.cubicTo(x + s * 0.2f, y - s * 0.5f, x + s * 0.8f, y, x + s * 0.8f, y + s * 0.35f);
                ipath.cubicTo(x + s * 0.8f, y + s * 0.85f, x - s * 0.8f, y + s * 0.85f, x - s * 0.8f, y + s * 0.35f);
                ipath.cubicTo(x - s * 0.8f, y, x - s * 0.2f, y - s * 0.5f, x, y - s);
                c.drawPath(ipath, ico);
                break;
            case 2: // fan blades
                for (int k = 0; k < 3; k++) {
                    c.save();
                    c.rotate(120 * k, x, y);
                    ipath.reset();
                    ipath.moveTo(x, y);
                    ipath.cubicTo(x - s * 0.7f, y - s * 0.3f, x - s * 0.5f, y - s * 1.0f, x, y - s * 0.95f);
                    ipath.cubicTo(x + s * 0.3f, y - s * 0.9f, x + s * 0.3f, y - s * 0.4f, x, y);
                    c.drawPath(ipath, ico);
                    c.restore();
                }
                break;
            default: // auto: sparkle
                ipath.reset();
                ipath.moveTo(x, y - s);
                ipath.quadTo(x, y, x + s, y);
                ipath.quadTo(x, y, x, y + s);
                ipath.quadTo(x, y, x - s, y);
                ipath.quadTo(x, y, x, y - s);
                c.drawPath(ipath, ico);
                break;
        }
        ico.clearShadowLayer();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!on) return false;
                {
                    double rad = Math.toRadians(START + TOTAL * frac);
                    float kx = cx + (float) (radius() * Math.cos(rad));
                    float ky = cy + (float) (radius() * Math.sin(rad));
                    float dx = e.getX() - kx;
                    float dy = e.getY() - ky;
                    float hit = 38 * density;
                    if (dx * dx + dy * dy > hit * hit) return false;
                }
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                dragging = true;
                lastTemp = -1;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) update(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                centerDown = false;
                if (dragging) {
                    dragging = false;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    if (listener != null && lastTemp > 0) listener.onCommit(lastTemp);
                    invalidate();
                }
                return true;
            default:
                return true;
        }
    }

    private void update(MotionEvent e) {
        float dx = e.getX() - cx;
        float dy = e.getY() - cy;
        double ang = Math.toDegrees(Math.atan2(dy, dx));
        if (ang < 0) ang += 360;
        double rel = ang - START;
        if (rel < 0) rel += 360;
        float f;
        if (rel <= TOTAL) f = (float) (rel / TOTAL);
        else f = rel < TOTAL + (360 - TOTAL) / 2 ? 1f : 0f;
        int t = 16 + Math.round(f * 14);
        if (t != lastTemp) {
            lastTemp = t;
            if (listener != null) listener.onPreview(t);
        }
    }
}
