package com.example.lgacremote;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import java.util.HashMap;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.text.InputType;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    static final int NEON = 0xFF3FD0FF;
    static final int GLASS = 0xFF0A2A86;
    static final int GLASS_EDGE = 0xFF2AA9E0;
    static final int OFF_EDGE = 0x552A4A6E;
    static final int TEXT = 0xFFEAF6FF;
    static final int MUTED = 0xFF7FA6C9;
    static final int BG_TOP = 0xFF01030C;
    static final int BG_BOT = 0xFF030E2C;

    static final String[] MODE_NAMES = {"Cool", "Dry", "Fan", "Auto"};
    static final int[] MODE_CODE = {0, 1, 2, 3};
    static final String[] FAN_NAMES = {"Low", "Mid", "High", "Auto"};
    static final int[][] FAN_CODES = {{0, 2, 4, 5}, {9, 2, 10, 5}};
    static final int[] ENERGY_PCT = {0, 80, 60, 40};
    static final String[] SWING_NAMES = {"Off", "Auto swing", "Highest", "High", "Upper-middle", "Middle", "Low", "Lowest"};
    static final int[] DUR_MIN = {30, 60, 120, 180, 240, 360, 480, 600, 720};
    static final String[] DUR_LABEL = {"30 நிமிஷம்", "1 மணி", "2 மணி", "3 மணி", "4 மணி", "6 மணி", "8 மணி", "10 மணி", "12 மணி"};

    private SharedPreferences prefs;
    private ConsumerIrManager ir;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    // AC state
    private boolean on;
    private int temp = 24;
    private int mode = 0;
    private int fan = 3;
    private int swingPos = 0;
    private boolean hSwing, hcool, lightOn = true, clean, purify, oldSwing;
    private int energy = 0;
    private int sleepH = 0;
    private long sleepEnd = 0;
    private int activeTimer = 0;      // 0 none, 1 off, 2 on
    private long activeTimerEnd = 0;

    // Setup
    private boolean lg2 = false;
    private int fanTable = 1;         // user-verified: "New" fan codes
    private boolean bit15 = false;    // user-verified: remote-style bit OFF
    private int repeats = 1;

    private String overlayText = null;
    private long overlayUntil = 0;

    // Views
    private DialView dial;
    private TextView tvStatus, tvModeVal, tvFanVal, tvLightVal, tvTimerLine, tvPowerLbl;
    private ImageView powerIcon;
    private LinearLayout powerBtn;
    private final HashMap<View, ValueAnimator> glowAnims = new HashMap<>();
    private int lastPower = -1;
    private final int[] lastChip = {-1, -1, -1, -1};
    private FanBarsView fanBars;
    private TileAnim animMode, animFan, animAir;
    private TextView tvAirVal, tvHcoolVal;
    private final TextView[] chips = new TextView[4];
    private final int[] chipLvl = new int[4];
    private int vFixed = 2;           // fixed vane position 0..5 (Highest..Lowest)
    private AirflowView avV, avH;
    private final Online online = new Online();
    private LinearLayout energyBadge;
    private TextView tvEnergyBadge;
    private final HashMap<View, int[]> fxMap = new HashMap<>();
    private Switch swV, swH;
    private TextView tvVLabel;
    private boolean syncing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("lgac4", MODE_PRIVATE);
        on = prefs.getBoolean("on", false);
        temp = prefs.getInt("temp", 24);
        mode = prefs.getInt("mode", 0);
        fan = prefs.getInt("fan", 3);
        swingPos = prefs.getInt("swing", 0);
        vFixed = prefs.getInt("vFixed", 2);
        if (swingPos >= 2) vFixed = swingPos - 2;
        oldSwing = prefs.getBoolean("oldSwing", false);
        lightOn = prefs.getBoolean("light", true);
        lg2 = prefs.getBoolean("lg2", false);
        fanTable = prefs.getInt("fanTable", 1);
        bit15 = prefs.getBoolean("bit15", false);
        repeats = prefs.getInt("repeats", 1);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        configureOnline();
        online.setListener(msg -> handler.post(() -> toast(msg)));
        getWindow().setStatusBarColor(BG_TOP);
        getWindow().setNavigationBarColor(BG_BOT);
        setContentView(buildUi());
        refresh();
        if ((ir == null || !ir.hasIrEmitter()) && !online.configured()) {
            toast("IR blaster இல்ல. Setup ⚙ → Online setup பண்ணுங்க");
        }
        if (useOnline()) syncFromAc();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
        save();
    }

    // ---------- IR ----------

    private void send(int frame) {
        send(frame, repeats);
    }

    private boolean hasIr() {
        return ir != null && ir.hasIrEmitter();
    }

    private boolean useOnline() {
        return online.configured() && (prefs.getBoolean("online", false) || !hasIr());
    }

    private void configureOnline() {
        String cid = prefs.getString("onClient", "");
        if (cid.isEmpty()) {
            cid = Online.newClientId();
            prefs.edit().putString("onClient", cid).apply();
        }
        online.configure(prefs.getString("onToken", ""), prefs.getString("onCountry", "IN"),
                cid, prefs.getString("onDevice", ""));
    }

    /** Translate an IR command into the matching LG cloud command. */
    private void onlineSend(int frame) {
        if (frame == LgFrames.OFF) {
            online.power(false);
        } else if (frame == LgFrames.LIGHT_TOGGLE) {
            online.light(lightOn);
        } else if (frame == LgFrames.ENERGY[0]) {
            online.powerSave(false);
        } else if (frame == LgFrames.ENERGY[1] || frame == LgFrames.ENERGY[2] || frame == LgFrames.ENERGY[3]) {
            online.powerSave(true);
        } else if (frame == LgFrames.SWING_V_TOGGLE) {
            online.swingUpDown(swingPos == 1);
        } else if (frame == LgFrames.SWING_V[0]) {
            online.swingUpDown(false);
        } else if (frame == LgFrames.SWING_V[1]) {
            online.swingUpDown(true);
        } else if (frame == LgFrames.SWING_H_ON) {
            online.swingLeftRight(true);
        } else if (frame == LgFrames.SWING_H_OFF) {
            online.swingLeftRight(false);
        } else if (frame == LgFrames.PURIFY_ON) {
            online.airClean(true);
        } else if (frame == LgFrames.PURIFY_OFF) {
            online.airClean(false);
        } else if (frame == LgFrames.TIMER_CLEAR_ALL || frame == LgFrames.SLEEP_CANCEL) {
            online.sleepTimer(0);
        } else {
            toast("இது Online mode-ல இல்ல (IR மட்டும்)");
        }
    }

    private void onlineState(boolean afterPowerOn) {
        if (afterPowerOn) {
            online.lastMode = online.lastTemp = online.lastFan = -1;
        }
        if (online.lastMode != mode) {
            online.mode(mode);
            online.lastMode = mode;
        }
        if (online.lastTemp != temp && mode != 2) {
            online.temp(temp);
            online.lastTemp = temp;
        }
        if (online.lastFan != fan) {
            online.fan(fan);
            online.lastFan = fan;
        }
    }

    /** Read the AC's real state from the LG cloud and copy it into the screen. */
    private void syncFromAc() {
        online.getState(r -> {
            if (!r.ok || !(r.body instanceof org.json.JSONObject)) {
                if (!r.ok) handler.post(() -> toast("Sync: LG " + r.code + " " + r.message));
                return;
            }
            org.json.JSONObject o = (org.json.JSONObject) r.body;
            handler.post(() -> {
                try {
                    org.json.JSONObject op = o.optJSONObject("operation");
                    if (op != null) on = op.optString("airConOperationMode", "").toUpperCase().contains("ON")
                            && !op.optString("airConOperationMode", "").toUpperCase().contains("OFF");
                    org.json.JSONObject jm = o.optJSONObject("airConJobMode");
                    if (jm != null) {
                        String m = jm.optString("currentJobMode", "").toUpperCase();
                        if (m.equals("COOL")) mode = 0;
                        else if (m.contains("DRY")) mode = 1;
                        else if (m.equals("FAN")) mode = 2;
                        else if (m.equals("AUTO")) mode = 3;
                    }
                    Object tin = o.opt("temperatureInUnits");
                    org.json.JSONObject tj = null;
                    if (tin instanceof org.json.JSONArray && ((org.json.JSONArray) tin).length() > 0) {
                        tj = ((org.json.JSONArray) tin).optJSONObject(0);
                    } else if (tin instanceof org.json.JSONObject) {
                        tj = (org.json.JSONObject) tin;
                    } else {
                        tj = o.optJSONObject("temperature");
                    }
                    if (tj != null) {
                        int t = (int) Math.round(tj.optDouble("targetTemperature",
                                tj.optDouble("targetTemperatureC", temp)));
                        if (t >= 16 && t <= 30) temp = t;
                    }
                    org.json.JSONObject af = o.optJSONObject("airFlow");
                    if (af != null) {
                        String w = af.optString("windStrength", "").toUpperCase();
                        if (w.equals("LOW")) fan = 0;
                        else if (w.equals("MID") || w.equals("MEDIUM")) fan = 1;
                        else if (w.equals("HIGH") || w.equals("POWER")) fan = 2;
                        else if (w.equals("AUTO") || w.equals("NATURE")) fan = 3;
                    }
                    org.json.JSONObject ps = o.optJSONObject("powerSave");
                    if (ps != null) energy = ps.optBoolean("powerSaveEnabled", false) ? Math.max(energy, 1) : 0;
                    online.lastMode = mode;
                    online.lastTemp = temp;
                    online.lastFan = fan;
                    refresh();
                    save();
                } catch (Exception ignored) {
                    // keep screen as is
                }
            });
        });
    }

    private void send(int frame, int reps) {
        if (useOnline()) {
            onlineSend(frame);
            return;
        }
        if (ir == null || !ir.hasIrEmitter()) {
            toast("IR blaster இல்ல");
            return;
        }
        try {
            ir.transmit(38000, LgFrames.pattern(frame, lg2, reps));
        } catch (Exception e) {
            toast("IR அனுப்ப முடியல");
        }
    }

    private void sendState() {
        if (useOnline()) {
            onlineState(false);
            return;
        }
        send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15));
    }

    // ---------- Actions ----------

    private boolean needOn() {
        if (!on) {
            toast("முதல்ல Power ON பண்ணுங்க");
            return false;
        }
        return true;
    }

    private void actPower() {
        if (!on) {
            on = true;
            if (useOnline()) {
                online.power(true);
                online.pause(2500);
                onlineState(true);
            } else {
                send(LgFrames.state(MODE_CODE[mode], temp, FAN_CODES[fanTable][fan], bit15), 3);
            }
        } else {
            on = false;
            send(LgFrames.OFF, 3);
            sleepH = 0;
            sleepEnd = 0;
            hcool = false;
            if (activeTimer == 1) activeTimer = 0;
        }
    }

    private void actMode() {
        if (!needOn()) return;
        hcool = false;
        mode = (mode + 1) % MODE_NAMES.length;
        sendState();
    }

    private void actFan() {
        if (!needOn()) return;
        hcool = false;
        fan = (fan + 1) % FAN_NAMES.length;
        sendState();
    }

    /** Tap on the AIRFLOW button: Off -> Swing -> Highest ... Lowest -> Off. */
    private void actAirCycle() {
        if (!needOn()) return;
        if (oldSwing) {
            swingPos = swingPos == 0 ? 1 : 0;
            send(LgFrames.SWING_V_TOGGLE);
        } else {
            swingPos = (swingPos + 1) % 8;
            if (swingPos >= 2) vFixed = swingPos - 2;
            send(LgFrames.SWING_V[swingPos]);
        }
        syncAirflow();
        refresh();
        save();
    }

    private void actTemp(int delta) {
        if (!needOn()) return;
        hcool = false;
        temp = Math.max(16, Math.min(30, temp + delta));
        overlayText = null;
        sendState();
    }

    private void actHcool() {
        if (!needOn()) return;
        if (!hcool) {
            if (useOnline()) {
                toast("H'Cool Online mode-ல இல்ல (IR மட்டும்)");
                return;
            }
            hcool = true;
            send(LgFrames.JET_ON);
        } else {
            hcool = false;
            sendState();
        }
    }

    private void actEnergy(int level) {
        if (!needOn()) return;
        energy = level;
        send(LgFrames.ENERGY[energy]);
        if (energy > 0) {
            overlayText = ENERGY_PCT[energy] + " %";
            overlayUntil = System.currentTimeMillis() + 4000;
        } else {
            overlayText = null;
        }
    }

    private void actLight() {
        if (!needOn()) return;
        lightOn = !lightOn;
        send(LgFrames.LIGHT_TOGGLE);
    }

    private String swingLabel() {
        if (swingPos == 0) return "Off";
        if (swingPos == 1) return "Swing";
        return SWING_NAMES[swingPos];
    }

    private void vSwingSwitch(boolean checked) {
        if (!needOn()) {
            syncAirflow();
            return;
        }
        if (oldSwing) {
            swingPos = checked ? 1 : 0;
            send(LgFrames.SWING_V_TOGGLE);
        } else {
            swingPos = checked ? 1 : 0;
            send(LgFrames.SWING_V[swingPos]);
        }
        syncAirflow();
        refresh();
        save();
    }

    private void vMove(int dir) {
        if (!needOn()) return;
        if (oldSwing) {
            toast("Old toggle mode-ல position இல்ல. Setup-ல Swing மாத்துங்க");
            return;
        }
        int nv = Math.max(0, Math.min(5, vFixed + dir));
        if (nv == vFixed && swingPos == 2 + vFixed) return;   // already at the end
        vFixed = nv;
        swingPos = 2 + vFixed;
        send(LgFrames.SWING_V[swingPos]);
        syncAirflow();
        refresh();
        save();
    }

    /** Jump straight to a vane position (0 = Highest .. 5 = Lowest), e.g. from a touch on a ray. */
    private void vSet(int idx) {
        if (!needOn()) {
            syncAirflow();
            return;
        }
        if (oldSwing) {
            toast("Old toggle mode-ல position இல்ல. Setup-ல Swing மாத்துங்க");
            syncAirflow();
            return;
        }
        vFixed = Math.max(0, Math.min(5, idx));
        swingPos = 2 + vFixed;
        send(LgFrames.SWING_V[swingPos]);
        syncAirflow();
        refresh();
        save();
    }

    private void syncAirflow() {
        if (avV == null) return;
        syncing = true;
        boolean vs = on && swingPos == 1;
        avV.setState(vFixed, vs);
        swV.setChecked(vs);
        tvVLabel.setText(on ? swingLabel() : "Off");
        syncing = false;
    }

    private Switch neonSwitch() {
        Switch sw = new Switch(this);
        int[][] st = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(st, new int[]{NEON, 0xFFB0BCCF}));
        sw.setTrackTintList(new ColorStateList(st, new int[]{0x883FD0FF, 0x66506A8A}));
        return sw;
    }

    private LinearLayout glassCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(shape(true, GLASS, GLASS_EDGE, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(14);
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout roundBtn(int iconRes, Runnable r) {
        LinearLayout b = new LinearLayout(this);
        b.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0x33162F55);
        g.setStroke(dp(1), GLASS_EDGE);
        setGlowBg(b, new RippleDrawable(ColorStateList.valueOf(Color.argb(90, 63, 208, 255)), g, null), 28);
        b.setClickable(true);
        // press = one step now; keep holding = keeps stepping every 0.6 s
        final View.OnTouchListener gl = glowListener();
        final Handler rh = new Handler(Looper.getMainLooper());
        final Runnable[] rep = new Runnable[1];
        rep[0] = () -> {
            r.run();
            rh.postDelayed(rep[0], 600);
        };
        b.setOnTouchListener((v, e) -> {
            gl.onTouch(v, e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                    r.run();
                    rh.removeCallbacks(rep[0]);
                    rh.postDelayed(rep[0], 500);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    rh.removeCallbacks(rep[0]);
                    break;
                default:
                    break;
            }
            return true;
        });
        b.addView(icon(iconRes, 26));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(56));
        lp.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout switchRow(String label, TextView valueView, Switch sw) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(10), 0, 0);
        TextView t = caption(label, 15, TEXT, true);
        t.setGravity(Gravity.START);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (valueView != null) {
            valueView.setPadding(0, 0, dp(12), 0);
            r.addView(valueView);
        }
        r.addView(sw);
        return r;
    }

    private void actSwingVPicker() {
        Dialog dlg = new Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_TOP, BG_BOT}));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(30), dp(18), dp(24));
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = caption("Airflow", 24, TEXT, true);
        title.setGravity(Gravity.START);
        root.addView(title);

        // UP / DOWN
        LinearLayout c1 = glassCard();
        TextView h1 = caption("UP/DOWN", 13, NEON, true);
        h1.setGravity(Gravity.START);
        c1.addView(h1);
        LinearLayout body1 = new LinearLayout(this);
        body1.setGravity(Gravity.CENTER_VERTICAL);
        avV = new AirflowView(this, true);
        avV.setOnRayListener(this::vSet);   // touch a ray to target that position
        body1.addView(avV);
        LinearLayout arrows = new LinearLayout(this);
        arrows.setOrientation(LinearLayout.VERTICAL);
        arrows.setGravity(Gravity.CENTER);
        arrows.addView(roundBtn(R.drawable.ic_up, () -> vMove(-1)));
        arrows.addView(roundBtn(R.drawable.ic_down, () -> vMove(1)));
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        body1.addView(arrows, alp);
        c1.addView(body1);
        swV = neonSwitch();
        tvVLabel = caption("", 13, MUTED, false);
        swV.setOnCheckedChangeListener((b, checked) -> {
            if (!syncing) vSwingSwitch(checked);
        });
        c1.addView(switchRow("Up/Down Swing", tvVLabel, swV));
        root.addView(c1);

        TextView close = caption("Close", 16, NEON, true);
        close.setPadding(dp(16), dp(16), dp(16), dp(16));
        setGlowBg(close, ripple(shape(true, GLASS, GLASS_EDGE, 1)), 18);
        close.setClickable(true);
        close.setOnClickListener(v -> dlg.dismiss());
        glowTouch(close);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(20);
        root.addView(close, clp);

        dlg.setContentView(sv);
        dlg.setOnDismissListener(d -> {
            avV = null;
            refresh();
            save();
        });
        syncAirflow();
        dlg.show();
    }

    private void actSleep() {
        if (!needOn()) return;
        sleepH = (sleepH + 1) % 8;
        if (useOnline()) online.sleepTimer(sleepH);
        else send(LgFrames.sleep(sleepH * 60));
        sleepEnd = sleepH == 0 ? 0 : System.currentTimeMillis() + sleepH * 3600000L;
        toast(sleepH == 0 ? "Sleep timer off" : "Sleep: " + sleepH + " மணி நேரத்துல AC off ஆகும்");
    }

    private void showTimerDialog() {
        String[] kinds = {"OFF timer set பண்ணு", "ON timer set பண்ணு", "Timer cancel பண்ணு"};
        new AlertDialog.Builder(this)
                .setTitle("Timer")
                .setItems(kinds, (d, w) -> {
                    if (w == 2) {
                        send(LgFrames.TIMER_CLEAR_ALL);
                        if (sleepH != 0) send(LgFrames.SLEEP_CANCEL);
                        activeTimer = 0;
                        sleepH = 0;
                        sleepEnd = 0;
                        toast("Timer cancel ஆச்சு");
                    } else {
                        pickDuration(w == 1);
                    }
                })
                .show();
    }

    private void pickDuration(boolean turnOn) {
        new AlertDialog.Builder(this)
                .setTitle(turnOn ? "ON timer எவ்வளவு நேரம் கழிச்சு?" : "OFF timer எவ்வளவு நேரம் கழிச்சு?")
                .setItems(DUR_LABEL, (d, w) -> {
                    int min = DUR_MIN[w];
                    if (useOnline()) online.timer(turnOn, min);
                    else send(LgFrames.schedule(turnOn, min));
                    activeTimer = turnOn ? 2 : 1;
                    activeTimerEnd = System.currentTimeMillis() + min * 60000L;
                    toast((turnOn ? "ON" : "OFF") + " timer set ஆச்சு");
                })
                .show();
    }

    private void showMoreDialog() {
        String[] items = {
                "Auto clean: " + (clean ? "ON" : "OFF"),
                "Plasma: " + (purify ? "ON" : "OFF"),
                "Comfort Air (code இல்ல)",
                "Room temp (example)",
                "Setup"
        };
        new AlertDialog.Builder(this)
                .setTitle("More")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0:
                            if (!needOn()) break;
                            clean = !clean;
                            send(clean ? LgFrames.CLEAN_ON : LgFrames.CLEAN_OFF);
                            break;
                        case 1:
                            if (!needOn()) break;
                            purify = !purify;
                            send(purify ? LgFrames.PURIFY_ON : LgFrames.PURIFY_OFF);
                            break;
                        case 2: toast("Comfort Air-க்கு IR code இன்னும் கிடைக்கல"); break;
                        case 3: overlayText = "29 °C"; overlayUntil = System.currentTimeMillis() + 3000; break;
                        case 4: showSetup(); break;
                        default: break;
                    }
                    refresh();
                    save();
                })
                .show();
    }

    private String maskToken(String t) {
        if (t == null || t.isEmpty()) return "இல்ல";
        return t.length() <= 6 ? "••••" : "••••" + t.substring(t.length() - 4);
    }

    private void promptText(String title, String hint, String initial, boolean secret, java.util.function.Consumer<String> done) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setText(initial);
        et.setSingleLine(true);
        et.setInputType(secret ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD)
                : InputType.TYPE_CLASS_TEXT);
        int pad = dp(20);
        et.setPadding(pad, pad, pad, pad);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(et)
                .setPositiveButton("Save", (d, w) -> done.accept(et.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showOnlineSetup() {
        boolean onl = prefs.getBoolean("online", false);
        String[] items = {
                "Online mode: " + (onl ? "ON (எப்பவும்)" : (hasIr() ? "OFF (IR use பண்ணும்)" : "Auto (IR இல்ல)")),
                "Token: " + maskToken(prefs.getString("onToken", "")),
                "Country: " + prefs.getString("onCountry", "IN"),
                "AC: " + (prefs.getString("onDeviceName", "").isEmpty() ? "தேர்ந்தெடுக்கல" : prefs.getString("onDeviceName", "")),
                "AC-ல இருந்து நிலைமையை படி (Sync)"
        };
        new AlertDialog.Builder(this)
                .setTitle("Online setup")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0:
                            prefs.edit().putBoolean("online", !onl).apply();
                            configureOnline();
                            showOnlineSetup();
                            break;
                        case 1:
                            promptText("LG ThinQ Token", "Token-ஐ paste பண்ணுங்க", "", true, v -> {
                                prefs.edit().putString("onToken", v).putString("onDevice", "")
                                        .putString("onDeviceName", "").apply();
                                configureOnline();
                                pickAcDevice();
                            });
                            break;
                        case 2:
                            promptText("Country code", "IN", prefs.getString("onCountry", "IN"), false, v -> {
                                prefs.edit().putString("onCountry", v.toUpperCase()).apply();
                                configureOnline();
                                showOnlineSetup();
                            });
                            break;
                        case 3:
                            pickAcDevice();
                            break;
                        case 4:
                            if (!online.configured()) {
                                toast("முதல்ல Token + AC தேர்ந்தெடுங்க");
                            } else {
                                syncFromAc();
                                toast("Sync பண்றேன்...");
                            }
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void pickAcDevice() {
        if (!online.hasToken()) {
            toast("முதல்ல Token paste பண்ணுங்க");
            return;
        }
        toast("AC தேடுறேன்...");
        online.listDevices(r -> handler.post(() -> {
            if (!r.ok) {
                new AlertDialog.Builder(this).setTitle("LG பிழை")
                        .setMessage(r.code + "\n" + r.message
                                + "\n\nToken, Country சரியா இருக்கான்னு பாருங்க.")
                        .setPositiveButton("OK", null).show();
                return;
            }
            java.util.ArrayList<String> ids = new java.util.ArrayList<>();
            java.util.ArrayList<String> names = new java.util.ArrayList<>();
            org.json.JSONArray arr = r.body instanceof org.json.JSONArray ? (org.json.JSONArray) r.body : null;
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    org.json.JSONObject dv = arr.optJSONObject(i);
                    if (dv == null) continue;
                    org.json.JSONObject info = dv.optJSONObject("deviceInfo");
                    String type = info != null ? info.optString("deviceType", "") : dv.optString("deviceType", "");
                    if (!type.toUpperCase().contains("AIR_CONDITIONER")) continue;
                    String alias = info != null ? info.optString("alias", "") : "";
                    String model = info != null ? info.optString("modelName", "") : "";
                    ids.add(dv.optString("deviceId"));
                    names.add(alias.isEmpty() ? (model.isEmpty() ? "LG AC" : model) : alias);
                }
            }
            if (ids.isEmpty()) {
                toast("AC கிடைக்கல. ThinQ app-ல AC இருக்கான்னு பாருங்க");
                return;
            }
            new AlertDialog.Builder(this).setTitle("எந்த AC?")
                    .setItems(names.toArray(new String[0]), (dd, which) -> {
                        prefs.edit().putString("onDevice", ids.get(which))
                                .putString("onDeviceName", names.get(which)).apply();
                        configureOnline();
                        toast("AC தேர்ந்தெடுத்தாச்சு: " + names.get(which));
                        syncFromAc();
                    }).show();
        }));
    }

    private void showSetup() {
        String[] items = {
                "1) Signal type: " + (lg2 ? "LG2" : "LG1"),
                "2) Fan codes: " + (fanTable == 0 ? "Classic" : "New"),
                "3) Remote-style bit: " + (bit15 ? "ON" : "OFF"),
                "4) அனுப்பும் முறை: " + repeats + "x",
                "5) Swing: " + (oldSwing ? "Old toggle" : "Positions"),
                "Test அனுப்பு (Cool 24°C)",
                "🌐 Online (இணையம்) setup"
        };
        new AlertDialog.Builder(this)
                .setTitle("Setup")
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0: lg2 = !lg2; break;
                        case 1: fanTable = 1 - fanTable; break;
                        case 2: bit15 = !bit15; break;
                        case 3: repeats = repeats == 1 ? 2 : 1; break;
                        case 4: oldSwing = !oldSwing; break;
                        case 5:
                            send(LgFrames.state(0, 24, FAN_CODES[fanTable][3], bit15), 3);
                            toast("Test அனுப்பினேன். AC beep பண்ணுதா பாருங்க");
                            return;
                        case 6: showOnlineSetup(); return;
                        default: return;
                    }
                    save();
                    showSetup();
                })
                .show();
    }

    // ---------- Screen ----------

    private static String fmt(int min) {
        int m = min % 60;
        return (min / 60) + ":" + (m < 10 ? "0" : "") + m;
    }

    private void refresh() {
        long now = System.currentTimeMillis();
        if (activeTimer != 0 && now >= activeTimerEnd) {
            on = activeTimer == 2;
            activeTimer = 0;
            if (!on) {
                sleepH = 0;
                sleepEnd = 0;
            }
        }
        if (sleepH != 0 && now >= sleepEnd) {
            on = false;
            sleepH = 0;
            sleepEnd = 0;
        }
        if (overlayText != null && now > overlayUntil) overlayText = null;

        // Dial
        String big;
        String unit = "°C";
        if (!on) {
            big = "--";
            unit = "";
        } else if (overlayText != null) {
            big = overlayText;
            unit = "";
        } else if (mode == 2) {
            big = "--";
            unit = "";
        } else {
            big = String.valueOf(temp);
        }
        float frac = (temp - 16) / 14f;
        dial.setModeIcon(hcool ? 0 : mode);
        dial.setState(on ? (hcool ? "H'COOL" : MODE_NAMES[mode].toUpperCase()) : "OFF", big, unit, frac, on);

        // Cards
        tvModeVal.setText(on ? MODE_NAMES[mode] : "Off");
        tvFanVal.setText(on ? FAN_NAMES[fan] : "Off");
        fanBars.setLevel(on ? fan + 1 : 0);
        tvAirVal.setText(on ? swingLabel() : "Off");
        if (animMode != null) {
            animMode.setActive(on);
            animFan.setActive(on);
            animAir.setActive(on);
            animMode.setState(hcool ? 0 : mode);
            animFan.setState(fan);
            animAir.setState(swingPos);
        }
        tvHcoolVal.setText(hcool ? "On" : "Off");
        tvLightVal.setText(lightOn ? "On" : "Off");
        for (int i = 0; i < 4; i++) {
            boolean sel = on && energy == chipLvl[i];
            chips[i].setTextColor(sel ? BG_TOP : TEXT);
            int key = sel ? 1 : 0;
            if (lastChip[i] != key) {
                lastChip[i] = key;
                GradientDrawable cg = new GradientDrawable();
                cg.setCornerRadius(dp(12));
                cg.setColor(sel ? 0xFF2BE3FF : 0x55102E7A);
                cg.setStroke(dp(2), sel ? 0xFFBFF6FF : 0xFF1E6FC0);
                setGlowBg(chips[i], cg, 12);
            }
        }
        if (avV != null) syncAirflow();

        // Status line under the dial
        StringBuilder st = new StringBuilder();
        if (on) {
            if (sleepH > 0) st.append("SLEEP   ");
            if (clean) st.append("CLEAN   ");
            if (purify) st.append("PLASMA   ");
        }
        tvStatus.setText(st.toString().trim());
        tvStatus.setVisibility(st.length() == 0 ? View.GONE : View.VISIBLE);
        boolean showBadge = on && energy > 0;
        energyBadge.setVisibility(showBadge ? View.VISIBLE : View.GONE);
        if (showBadge) {
            String pct = ENERGY_PCT[energy] + "%";
            SpannableString ss = new SpannableString("ENERGY " + pct);
            ss.setSpan(new ForegroundColorSpan(0xFF5CFF3A), 7, ss.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            tvEnergyBadge.setText(ss);
        }

        // Timer line
        String t = "";
        if (activeTimer != 0) {
            int left = (int) Math.max(0, (activeTimerEnd - now + 59999) / 60000);
            t = (activeTimer == 1 ? "OFF " : "ON ") + fmt(left);
        } else if (sleepH != 0) {
            int left = (int) Math.max(0, (sleepEnd - now + 59999) / 60000);
            t = "SLEEP " + fmt(left);
        }
        tvTimerLine.setText(t);

        // Power look
        int edge = on ? NEON : OFF_EDGE;
        if (lastPower != (on ? 1 : 0)) {
            lastPower = on ? 1 : 0;
            setGlowBg(powerBtn, ripple(shape(true, GLASS, edge, on ? 2 : 1)), 18);
        }
        powerIcon.setColorFilter(on ? NEON : MUTED);
        tvPowerLbl.setText(on ? "ON" : "OFF");
        tvPowerLbl.setTextColor(on ? NEON : MUTED);
    }

    private void save() {
        prefs.edit().putBoolean("on", on).putInt("temp", temp).putInt("mode", mode)
                .putInt("fan", fan).putInt("swing", swingPos).putBoolean("light", lightOn)
                .putBoolean("lg2", lg2).putInt("fanTable", fanTable).putBoolean("bit15", bit15)
                .putInt("vFixed", vFixed).putInt("repeats", repeats).putBoolean("oldSwing", oldSwing).apply();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ---------- UI building ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(boolean rounded, int fill, int edge, int strokeDp) {
        GradientDrawable d;
        if (fill == GLASS) {
            d = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0xFF0F3DB4, 0xFF041448});
        } else {
            d = new GradientDrawable();
            d.setColor(fill);
        }
        if (rounded) d.setCornerRadius(dp(18));
        d.setStroke(dp(Math.max(strokeDp, 2)), edge);
        return d;
    }

    /** Neon halo around a glass card (Android 9+). */
    private void halo(View v) {
        if (Build.VERSION.SDK_INT >= 28) {
            v.setElevation(dp(8));
            v.setOutlineSpotShadowColor(0xFF3FD0FF);
            v.setOutlineAmbientShadowColor(0xCC3FD0FF);
        }
    }

    private RippleDrawable ripple(GradientDrawable content) {
        return new RippleDrawable(ColorStateList.valueOf(Color.argb(90, 63, 208, 255)), content, null);
    }

    /** Base background plus a bright glow layer (hidden until touched). */
    private void setGlowBg(View v, Drawable base, int cornerDp) {
        setGlowBg(v, base, cornerDp, null);
    }

    private void setGlowBg(View v, Drawable base, int cornerDp, Drawable scene) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xAA3FD0FF, 0x333FD0FF});
        g.setCornerRadius(dp(cornerDp));
        g.setStroke(dp(2), 0xFFC4F4FF);
        g.setAlpha(0);
        // glossy highlight across the top, like the reference design
        GradientDrawable gloss = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x4DFFFFFF, 0x14FFFFFF, 0x00FFFFFF, 0x00FFFFFF});
        gloss.setCornerRadius(dp(Math.max(cornerDp - 3, 4)));
        Drawable[] layers = scene == null ? new Drawable[]{base, gloss, g}
                : new Drawable[]{base, scene, gloss, g};
        LayerDrawable ld = new LayerDrawable(layers);
        ld.setLayerInset(scene == null ? 1 : 2, dp(3), dp(3), dp(3), dp(3));
        v.setBackground(ld);
        v.setTag(g);
    }

    private void animGlow(View v, GradientDrawable g, int target, long ms) {
        ValueAnimator old = glowAnims.get(v);
        if (old != null) old.cancel();
        ValueAnimator a = ValueAnimator.ofInt(g.getAlpha(), target);
        a.setDuration(ms);
        a.addUpdateListener(an -> g.setAlpha((Integer) an.getAnimatedValue()));
        glowAnims.put(v, a);
        a.start();
    }

    private void glowTouch(View v) {
        v.setOnTouchListener(glowListener());
    }

    private View.OnTouchListener glowListener() {
        return (view, e) -> {
            Object t = view.getTag();
            if (!(t instanceof GradientDrawable)) return false;
            GradientDrawable g = (GradientDrawable) t;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    animGlow(view, g, 255, 110);
                    view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    animGlow(view, g, 0, 700);
                    view.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
                    break;
                default:
                    break;
            }
            return false;
        };
    }

    private View.OnClickListener act(Runnable r) {
        return v -> {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
            boolean wasOn = on;
            r.run();
            refresh();
            save();
            int[] f = fxMap.get(v);
            if (f != null && wasOn && on) {
                // f[0] = fx type, or -1 meaning "use current mode"
                int type = f[0] == -1 ? modeFx() : f[0];
                Fx.play(v, type, f[1]);
            }
        };
    }

    private int modeFx() {
        return mode == 0 ? Fx.COOL : mode == 1 ? Fx.DRY : mode == 2 ? Fx.WIND : Fx.AUTO;
    }

    private void fx(View v, int type, int cornerDp) {
        fxMap.put(v, new int[]{type, cornerDp});
    }

    private ImageView icon(int res, int sizeDp) {
        ImageView iv = new ImageView(this);
        Drawable d = getDrawable(res).mutate();
        iv.setImageDrawable(d);
        iv.setColorFilter(NEON);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        iv.setPadding(0, 0, 0, dp(2));
        return iv;
    }

    private TextView caption(String text, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Glass card: icon + title, optional value line. */
    private LinearLayout card(int iconRes, String title, TextView value, Runnable onTap, int heightDp) {
        return card(iconRes, null, title, value, onTap, heightDp);
    }

    private LinearLayout card(int iconRes, View extraTop, String title, TextView value, Runnable onTap, int heightDp) {
        return card(iconRes, extraTop, title, value, onTap, heightDp, null);
    }

    private LinearLayout card(int iconRes, View extraTop, String title, TextView value, Runnable onTap,
                              int heightDp, Drawable scene) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(4), dp(6), dp(4), dp(6));
        setGlowBg(c, ripple(shape(true, GLASS, GLASS_EDGE, 1)), 18, scene);
        halo(c);
        c.setClickable(true);
        c.setOnClickListener(act(onTap));
        glowTouch(c);
        boolean small = heightDp <= 86;   // bottom row: white labels; upper cards: neon labels
        if (iconRes != 0) c.addView(icon(iconRes, small ? 28 : 34));
        else if (extraTop != null) c.addView(extraTop);
        c.addView(caption(title, small ? 12 : 13, small ? TEXT : NEON, true));
        if (value != null) c.addView(value);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(heightDp), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        c.setLayoutParams(lp);
        return c;
    }

    private LinearLayout pill(String symbol, Runnable onTap) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER);
        c.setClickable(true);
        setGlowBg(c, ripple(shape(true, GLASS, GLASS_EDGE, 1)), 18);
        halo(c);
        c.setOnClickListener(act(onTap));
        glowTouch(c);
        c.addView(caption(symbol, 36, TEXT, true));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(62), 1f);
        lp.setMargins(dp(4), 0, dp(4), 0);
        c.setLayoutParams(lp);
        return c;
    }

    private TextView valueText() {
        return caption("", 22, TEXT, true);
    }

    private LinearLayout row(View... views) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        for (View v : views) r.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        r.setLayoutParams(lp);
        return r;
    }

    private View glowLine(boolean leftSide) {
        View v = new View(this);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                leftSide ? new int[]{0x003FD0FF, 0xFF3FD0FF} : new int[]{0xFF3FD0FF, 0x003FD0FF});
        g.setCornerRadius(dp(2));
        v.setBackground(g);
        return v;
    }

    /** Scales the whole remote down (never up) so it fits the screen height with no scrolling. */
    private void fitToScreen(View frame, View root) {
        int avail = frame.getHeight();
        int need = root.getHeight();
        if (avail <= 0 || need <= 0) return;
        float s = Math.max(0.55f, Math.min(1f, (float) avail / need));
        root.setPivotX(root.getWidth() / 2f);
        root.setPivotY(0f);
        if (Math.abs(root.getScaleX() - s) > 0.004f) {
            root.setScaleX(s);
            root.setScaleY(s);
        }
    }

    private View buildUi() {
        // No scrolling: the whole remote is scaled to fit the screen height.
        ScrollView sv = new ScrollView(this) {
            @Override
            public boolean onInterceptTouchEvent(MotionEvent ev) {
                return false;
            }

            @Override
            public boolean onTouchEvent(MotionEvent ev) {
                return false;
            }
        };
        sv.setVerticalScrollBarEnabled(false);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setFillViewport(true);
        GradientDrawable lin = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_TOP, BG_BOT});
        GradientDrawable rad = new GradientDrawable();
        rad.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        rad.setGradientCenter(0.5f, 0.18f);
        rad.setGradientRadius(dp(340));
        rad.setColors(new int[]{0xAA072A7A, 0x00010820});
        sv.setBackground(new LayerDrawable(new Drawable[]{lin, rad}));
        sv.setClipChildren(false);
        sv.setClipToPadding(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(8), dp(16), dp(10));
        root.setClipChildren(false);
        root.setClipToPadding(false);
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // Top: power button in the middle, setup gear on the right
        FrameLayout top = new FrameLayout(this);
        powerBtn = new LinearLayout(this);
        powerBtn.setOrientation(LinearLayout.VERTICAL);
        powerBtn.setGravity(Gravity.CENTER);
        powerBtn.setClickable(true);
        powerBtn.setOnClickListener(act(this::actPower));
        glowTouch(powerBtn);
        powerIcon = new ImageView(this);
        powerIcon.setImageDrawable(getDrawable(R.drawable.ic_power).mutate());
        powerIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        tvPowerLbl = caption("OFF", 11, MUTED, true);
        powerBtn.addView(powerIcon);
        powerBtn.addView(tvPowerLbl);
        top.addView(powerBtn, new FrameLayout.LayoutParams(dp(88), dp(88), Gravity.CENTER_HORIZONTAL));
        TextView gear = caption("⚙", 26, MUTED, false);
        gear.setPadding(dp(10), dp(6), dp(10), dp(6));
        gear.setClickable(true);
        gear.setOnClickListener(v -> showSetup());
        top.addView(gear, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END | Gravity.TOP));
        root.addView(top);

        // Dial (drag or tap the ring)
        dial = new DialView(this);
        dial.setMaxSize(Math.min(dp(340), (int) (getResources().getDisplayMetrics().heightPixels * 0.31f)));
        dial.setListener(new DialView.Listener() {
            @Override
            public void onPreview(int t) {
                temp = t;
                hcool = false;
                overlayText = null;
                refresh();
            }

            @Override
            public void onCommit(int t) {
                temp = t;
                sendState();
                save();
                refresh();
            }

            @Override
            public void onBlocked() {
                toast("முதல்ல Power ON பண்ணுங்க");
            }
        });
        LinearLayout dialWrap = new LinearLayout(this);
        dialWrap.setGravity(Gravity.CENTER);
        dialWrap.addView(dial);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(10);
        root.addView(dialWrap, dlp);

        LinearLayout pMinus = pill("\u2212", () -> actTemp(-1));
        LinearLayout pPlus = pill("+", () -> actTemp(1));
        fx(pMinus, Fx.PULSE, 18);
        fx(pPlus, Fx.PULSE, 18);
        LinearLayout pills = row(pMinus, pPlus);
        ((LinearLayout.LayoutParams) pills.getLayoutParams()).topMargin = -dp(34);
        root.addView(pills);

        // Energy badge: line - pill - line (shown while energy saving is active)
        energyBadge = new LinearLayout(this);
        energyBadge.setGravity(Gravity.CENTER_VERTICAL);
        energyBadge.addView(glowLine(true), new LinearLayout.LayoutParams(0, dp(3), 1f));
        LinearLayout bp = new LinearLayout(this);
        bp.setGravity(Gravity.CENTER_VERTICAL);
        bp.setPadding(dp(18), dp(8), dp(20), dp(8));
        bp.setBackground(shape(true, 0xFF05163F, NEON, 2));
        ((GradientDrawable) bp.getBackground()).setCornerRadius(dp(24));
        halo(bp);
        ImageView leaf = new ImageView(this);
        leaf.setImageDrawable(getDrawable(R.drawable.ic_leaf));
        bp.addView(leaf, new LinearLayout.LayoutParams(dp(24), dp(24)));
        tvEnergyBadge = caption("ENERGY", 18, TEXT, true);
        tvEnergyBadge.setPadding(dp(10), 0, 0, 0);
        bp.addView(tvEnergyBadge);
        energyBadge.addView(bp);
        energyBadge.addView(glowLine(false), new LinearLayout.LayoutParams(0, dp(3), 1f));
        LinearLayout.LayoutParams ebl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ebl.topMargin = dp(12);
        ebl.bottomMargin = dp(2);
        root.addView(energyBadge, ebl);

        tvStatus = caption("", 11, NEON, true);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(8);
        root.addView(tvStatus, slp);

        // Mode / Fan (fan card shows bars inside the box)
        tvModeVal = valueText();
        tvFanVal = valueText();
        fanBars = new FanBarsView(this);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(dp(50), dp(34));
        flp.bottomMargin = dp(3);
        fanBars.setLayoutParams(flp);
        // Animation lives inside the buttons themselves (always running while the AC is on)
        animMode = new TileAnim(TileAnim.MODE, getResources().getDisplayMetrics().density, dp(16));
        animFan = new TileAnim(TileAnim.FAN, getResources().getDisplayMetrics().density, dp(16));
        animAir = new TileAnim(TileAnim.AIR, getResources().getDisplayMetrics().density, dp(16));
        LinearLayout cMode = card(R.drawable.ic_mode, null, "MODE", tvModeVal, this::actMode, 108, animMode);
        LinearLayout cFan = card(0, fanBars, "FAN SPEED", tvFanVal, this::actFan, 108, animFan);
        root.addView(row(cMode, cFan));

        // Airflow / H'Cool
        tvAirVal = caption("", 14, TEXT, true);
        tvHcoolVal = valueText();
        LinearLayout cHcool = card(R.drawable.ic_hcool, "H'COOL", tvHcoolVal, this::actHcool, 96);
        fx(cHcool, Fx.WAVES, 18);
        // Tap = next airflow state right here (Off, Swing, 6 positions); long-press = full Airflow panel
        LinearLayout cAir = card(0, null, "AIRFLOW", tvAirVal, this::actAirCycle, 96, animAir);
        cAir.setOnLongClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            actSwingVPicker();
            return true;
        });
        root.addView(row(cAir, cHcool));

        // Energy saving: always visible with all options
        LinearLayout energyCard = new LinearLayout(this);
        energyCard.setOrientation(LinearLayout.VERTICAL);
        energyCard.setPadding(dp(12), dp(10), dp(12), dp(12));
        energyCard.setBackground(shape(true, GLASS, GLASS_EDGE, 1));
        halo(energyCard);
        LinearLayout eHead = new LinearLayout(this);
        eHead.setGravity(Gravity.CENTER_VERTICAL);
        ImageView eIcon = icon(R.drawable.ic_energy, 26);
        eHead.addView(eIcon);
        TextView eTitle = caption("ENERGY SAVING", 15, NEON, true);
        eTitle.setPadding(dp(8), 0, 0, 0);
        eHead.addView(eTitle);
        energyCard.addView(eHead);
        LinearLayout eRow = new LinearLayout(this);
        String[] chipLabels = {"OFF", "40%", "60%", "80%"};
        int[] chipLevel = {0, 3, 2, 1};
        for (int i = 0; i < 4; i++) {
            final int lvl = chipLevel[i];
            chipLvl[i] = lvl;
            TextView c = caption(chipLabels[i], 18, TEXT, true);
            c.setClickable(true);
            c.setOnClickListener(act(() -> actEnergy(lvl)));
            glowTouch(c);
            fx(c, Fx.PULSE, 12);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, dp(48), 1f);
            cl.setMargins(dp(3), dp(8), dp(3), 0);
            eRow.addView(c, cl);
            chips[i] = c;
        }
        energyCard.addView(eRow);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.topMargin = dp(10);
        elp.setMargins(dp(4), dp(10), dp(4), 0);
        root.addView(energyCard, elp);

        // Timer / Sleep / Light / More
        tvLightVal = valueText();
        LinearLayout cSleep = card(R.drawable.ic_sleep, "SLEEP", null, this::actSleep, 86);
        LinearLayout cLight = card(R.drawable.ic_light, "LIGHT", tvLightVal, this::actLight, 86);
        fx(cSleep, Fx.STARS, 18);
        fx(cLight, Fx.RAYS, 18);
        TextView dots = caption("•••", 22, NEON, true);
        root.addView(row(
                card(R.drawable.ic_timer, "TIMER", null, this::showTimerDialog, 86),
                cSleep,
                cLight,
                card(0, dots, "MORE", null, this::showMoreDialog, 86)));

        tvTimerLine = caption("", 13, NEON, true);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(10);
        root.addView(tvTimerLine, tlp);

        final View.OnLayoutChangeListener fit = (v, l, t, r, b, ol, ot, or, ob) -> fitToScreen(sv, root);
        sv.addOnLayoutChangeListener(fit);
        root.addOnLayoutChangeListener(fit);
        return sv;
    }
}
