package com.example.lgacremote;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Minimal client for the official LG ThinQ Connect cloud API (personal access token). */
public class Online {

    /** Shared public API key published in LG's open-source ThinQ Connect SDK (Apache-2.0). */
    private static final String API_KEY = "v6GFvkweNo7DK7yD3ylIZ9w52aKBU0eJ7wLXkSR3";
    private static final List<String> KIC = Arrays.asList(
            "AU,BD,CN,HK,ID,IN,JP,KH,KR,LA,LK,MM,MY,NP,NZ,PH,SG,TH,TW,VN".split(","));
    private static final List<String> AIC = Arrays.asList(
            ("AG,AR,AW,BB,BO,BR,BS,BZ,CA,CL,CO,CR,CU,DM,DO,EC,GD,GT,GY,HN,HT,JM,KN,LC,MX,NI,PA,PE,PR,PY,"
                    + "SR,SV,TT,US,UY,VC,VE").split(","));

    public interface Listener {
        /** Called on a background thread. */
        void onError(String message);
    }

    public static final class Result {
        public boolean ok;
        public String code = "";
        public String message = "";
        public Object body; // JSONObject / JSONArray / null
    }

    public interface Callback {
        /** Called on a background thread. */
        void done(Result r);
    }

    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private String token = "";
    private String country = "IN";
    private String clientId = "";
    private String deviceId = "";
    private Listener listener;
    private JSONObject profile;
    private boolean profileLoaded;

    // last values pushed to the AC, so only changes are sent
    public int lastMode = -1, lastTemp = -1, lastFan = -1;

    public void configure(String token, String country, String clientId, String deviceId) {
        boolean changed = !deviceId.equals(this.deviceId);
        this.token = token == null ? "" : token.trim();
        this.country = country == null || country.trim().isEmpty() ? "IN" : country.trim().toUpperCase();
        this.clientId = clientId;
        this.deviceId = deviceId == null ? "" : deviceId;
        if (changed) {
            profile = null;
            profileLoaded = false;
        }
        lastMode = lastTemp = lastFan = -1;
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public boolean configured() {
        return !token.isEmpty() && !deviceId.isEmpty();
    }

    public boolean hasToken() {
        return !token.isEmpty();
    }

    public static String newClientId() {
        return UUID.randomUUID().toString();
    }

    private String region() {
        if (KIC.contains(country)) return "kic";
        if (AIC.contains(country)) return "aic";
        return "eic";
    }

    private static String messageId() {
        UUID u = UUID.randomUUID();
        ByteBuffer b = ByteBuffer.allocate(16);
        b.putLong(u.getMostSignificantBits());
        b.putLong(u.getLeastSignificantBits());
        return Base64.encodeToString(b.array(), Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
    }

    /** Blocking HTTP call. Run only on the worker thread. */
    private Result call(String method, String endpoint, JSONObject json, boolean control) {
        Result r = new Result();
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://api-" + region() + ".lgthinq.com/" + endpoint);
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("x-country", country);
            c.setRequestProperty("x-message-id", messageId());
            c.setRequestProperty("x-client-id", clientId);
            c.setRequestProperty("x-api-key", API_KEY);
            c.setRequestProperty("x-service-phase", "OP");
            c.setRequestProperty("Content-Type", "application/json");
            if (control) c.setRequestProperty("x-conditional-control", "true");
            if (json != null) {
                c.setDoOutput(true);
                byte[] data = json.toString().getBytes("UTF-8");
                try (OutputStream os = c.getOutputStream()) {
                    os.write(data);
                }
            }
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (is != null) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
            }
            JSONObject root = null;
            try {
                if (sb.length() > 0) root = new JSONObject(sb.toString());
            } catch (Exception ignored) {
                // not JSON
            }
            if (code >= 200 && code < 300) {
                r.ok = true;
                if (root != null) r.body = root.opt("response");
            } else {
                JSONObject err = root == null ? null : root.optJSONObject("error");
                r.code = err != null ? err.optString("code", "" + code) : "" + code;
                r.message = err != null ? err.optString("message", "HTTP " + code) : "HTTP " + code;
            }
        } catch (Exception e) {
            r.code = "net";
            r.message = "இணைய பிழை: " + e.getClass().getSimpleName();
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }

    private void fail(Result r) {
        if (listener != null) listener.onError("LG " + r.code + ": " + r.message);
    }

    // ---------- public async API ----------

    public void listDevices(Callback cb) {
        ex.execute(() -> cb.done(call("GET", "devices", null, false)));
    }

    public void getState(Callback cb) {
        ex.execute(() -> cb.done(call("GET", "devices/" + deviceId + "/state", null, false)));
    }

    /** Queue: send one control payload; tries alternatives in order until one succeeds. */
    public void control(JSONObject... alternatives) {
        ex.execute(() -> controlNow(alternatives));
    }

    public void pause(long ms) {
        ex.execute(() -> {
            try {
                Thread.sleep(ms);
            } catch (InterruptedException ignored) {
                // ignore
            }
        });
    }

    public void controlNow(JSONObject... alternatives) {
        if (!configured()) return;
        Result last = null;
        for (JSONObject p : alternatives) {
            if (p == null) continue;
            Result r = call("POST", "devices/" + deviceId + "/control", p, true);
            if (r.ok) return;
            last = r;
            // only try the next alternative for "bad parameter" type errors
            if (!(r.code.equals("1000") || r.code.equals("1102") || r.code.equals("1311")
                    || r.code.equals("2207") || r.code.equals("1220"))) break;
        }
        if (last != null) fail(last);
    }

    // ---------- profile helpers ----------

    private void ensureProfile() {
        if (profileLoaded) return;
        profileLoaded = true;
        Result r = call("GET", "devices/" + deviceId + "/profile", null, false);
        if (r.ok && r.body instanceof JSONObject) {
            JSONObject o = (JSONObject) r.body;
            JSONObject p = o.optJSONObject("property");
            profile = p != null ? p : o;
        }
    }

    private final Map<String, List<String>> enumCache = new HashMap<>();

    private void collectEnums(Object node, String key, List<String> out) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONArray names = o.names();
            if (names == null) return;
            for (int i = 0; i < names.length(); i++) {
                String k = names.optString(i);
                Object v = o.opt(k);
                if (k.equals(key) && v instanceof JSONObject) {
                    JSONObject val = ((JSONObject) v).optJSONObject("value");
                    if (val != null) {
                        JSONArray w = val.optJSONArray("w");
                        if (w == null) w = val.optJSONArray("r");
                        if (w != null) {
                            for (int j = 0; j < w.length(); j++) out.add(w.optString(j));
                        }
                    }
                } else {
                    collectEnums(v, key, out);
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) collectEnums(a.opt(i), key, out);
        }
    }

    /** Pick the value the AC really accepts for this property (matches ignoring case). */
    public String pick(String key, String... candidates) {
        ensureProfile();
        List<String> allowed = enumCache.get(key);
        if (allowed == null) {
            allowed = new ArrayList<>();
            if (profile != null) collectEnums(profile, key, allowed);
            enumCache.put(key, allowed);
        }
        for (String c : candidates) {
            for (String a : allowed) {
                if (a.equalsIgnoreCase(c)) return a;
            }
        }
        return candidates[0];
    }

    public boolean profileHas(String resource) {
        ensureProfile();
        return profile != null && profile.has(resource);
    }

    // ---------- payload builders ----------

    private static JSONObject obj(String res, String k, Object v) {
        try {
            return new JSONObject().put(res, new JSONObject().put(k, v));
        } catch (Exception e) {
            return null;
        }
    }

    public void power(boolean on) {
        ex.execute(() -> {
            ensureProfile();
            String v = pick("airConOperationMode", on ? "POWER_ON" : "POWER_OFF");
            controlNow(obj("operation", "airConOperationMode", v));
        });
    }

    public void mode(int mode) {
        ex.execute(() -> {
            ensureProfile();
            String[] names = {"COOL", "AIR_DRY", "FAN", "AUTO"};
            String v = mode == 1 ? pick("currentJobMode", "AIR_DRY", "DRY")
                    : pick("currentJobMode", names[mode]);
            controlNow(obj("airConJobMode", "currentJobMode", v));
        });
    }

    public void fan(int fan) {
        ex.execute(() -> {
            ensureProfile();
            String key = profileHasWindDetail() ? "windStrengthDetail" : "windStrength";
            String v;
            switch (fan) {
                case 0: v = pick(key, "LOW"); break;
                case 1: v = pick(key, "MID", "MEDIUM"); break;
                case 2: v = pick(key, "HIGH"); break;
                default: v = pick(key, "AUTO", "NATURE"); break;
            }
            controlNow(obj("airFlow", "windStrength", v), obj("airFlow", "windStrengthDetail", v));
        });
    }

    private boolean profileHasWindDetail() {
        return false; // plain windStrength is accepted by all models; detail is tried as fallback
    }

    public void temp(int t) {
        ex.execute(() -> {
            JSONObject a = null, b = null, c = null;
            try {
                a = new JSONObject().put("temperatureInUnits",
                        new JSONObject().put("targetTemperature", t).put("unit", "C"));
                b = new JSONObject().put("temperature",
                        new JSONObject().put("targetTemperature", t).put("unit", "C"));
                c = new JSONObject().put("temperatureInUnits",
                        new JSONObject().put("coolTargetTemperature", t).put("unit", "C"));
            } catch (Exception ignored) {
                // ignore
            }
            controlNow(a, b, c);
        });
    }

    public void light(boolean on) {
        ex.execute(() -> {
            ensureProfile();
            controlNow(obj("display", "light", pick("light", on ? "ON" : "OFF")));
        });
    }

    public void powerSave(boolean on) {
        ex.execute(() -> controlNow(obj("powerSave", "powerSaveEnabled", on)));
    }

    public void swingUpDown(boolean on) {
        ex.execute(() -> controlNow(obj("windDirection", "rotateUpDown", on)));
    }

    public void swingLeftRight(boolean on) {
        ex.execute(() -> controlNow(obj("windDirection", "rotateLeftRight", on)));
    }

    public void airClean(boolean on) {
        ex.execute(() -> {
            ensureProfile();
            controlNow(obj("operation", "airCleanOperationMode",
                    pick("airCleanOperationMode", on ? "START" : "STOP")));
        });
    }

    public void sleepTimer(int hours) {
        ex.execute(() -> {
            try {
                controlNow(new JSONObject().put("sleepTimer", new JSONObject()
                        .put("relativeHourToStop", hours).put("relativeMinuteToStop", 0)));
            } catch (Exception ignored) {
                // ignore
            }
        });
    }

    public void timer(boolean turnOn, int minutes) {
        ex.execute(() -> {
            try {
                JSONObject t = new JSONObject();
                if (turnOn) {
                    t.put("relativeHourToStart", minutes / 60).put("relativeMinuteToStart", minutes % 60);
                } else {
                    t.put("relativeHourToStop", minutes / 60);
                    if (minutes % 60 != 0) t.put("relativeMinuteToStop", minutes % 60);
                }
                controlNow(new JSONObject().put("timer", t));
            } catch (Exception ignored) {
                // ignore
            }
        });
    }
}
