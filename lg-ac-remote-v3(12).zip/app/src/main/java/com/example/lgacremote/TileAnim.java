package com.example.lgacremote;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

import java.util.Random;

/**
 * Always-running animated background that lives INSIDE a button (clipped to its rounded shape).
 * MODE: ice / dry / fan / auto scene. FAN: spinning fan, speed follows the level. AIR: split-AC vane + airflow.
 */
public class TileAnim extends Drawable {
    public static final int MODE = 0, FAN = 1, AIR = 2;

    private static final int N = 14;
    private final int kind;
    private final float u;       // 1 dp in px
    private final float corner;  // corner radius in px

    private int state = 0;
    private boolean active = true;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final Path spath = new Path();
    private final Path cracks = new Path();
    private final Path rays = new Path();
    private final RectF rf = new RectF();
    private final float[] sa = new float[N], sb = new float[N], sc = new float[N];
    private final Shader[] bg = new Shader[4];
    private Shader rayShader;

    private long last = 0L;
    private float t = 0f, spin = 0f, ang = 0f, rayA = 0f;
    private int lw = -1, lh = -1;
    private final Runnable tick = this::invalidateSelf;

    public TileAnim(int kind, float density, float cornerPx) {
        this.kind = kind;
        this.u = density;
        this.corner = cornerPx;
        Random r = new Random(kind * 31 + 7);
        for (int i = 0; i < N; i++) {
            sa[i] = r.nextFloat();
            sb[i] = r.nextFloat();
            sc[i] = r.nextFloat();
        }
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    /** MODE: 0 cool 1 dry 2 fan 3 auto. FAN: 0 low 1 mid 2 high 3 auto. AIR: swingPos 0 off, 1 swing, 2..7 positions. */
    public void setState(int s) {
        if (s != state) {
            state = s;
            if (inited) play(5000);
            invalidateSelf();
        }
        inited = true;
    }

    private boolean inited = false, running = false;
    private float vis = 0f;
    private long until = 0L;

    /** Run the animation for ms milliseconds, then freeze. */
    public void play(int ms) {
        until = SystemClock.uptimeMillis() + ms;
        last = 0L;
        invalidateSelf();
    }

    public void setActive(boolean a) {
        if (a != active) {
            active = a;
            last = 0L;
            invalidateSelf();
        }
    }

    private static int al(int color, float a) {
        int v = Math.max(0, Math.min(255, (int) ((color >>> 24) * a)));
        return (v << 24) | (color & 0xFFFFFF);
    }

    private void build(int w, int h) {
        lw = w;
        lh = h;
        int[][] cols = {{0xAA3FD0FF, 0x223FD0FF}, {0xAAFF9A2E, 0x22FF6A00},
                {0xAA4DFFC0, 0x222FBFA0}, {0xAAC58BFF, 0x228A5BFF}};
        for (int i = 0; i < 4; i++) {
            bg[i] = new LinearGradient(0, 0, 0, h, cols[i][0], cols[i][1], Shader.TileMode.CLAMP);
        }
        // cracked earth (DRY)
        cracks.reset();
        Random rnd = new Random(5);
        for (int k = 0; k < 6; k++) {
            float x = w * (0.08f + 0.84f * rnd.nextFloat());
            float y = h + 2 * u;
            cracks.moveTo(x, y);
            for (int s = 0; s < 4; s++) {
                x += (rnd.nextFloat() - 0.5f) * w * 0.14f;
                y -= h * (0.10f + 0.10f * rnd.nextFloat());
                cracks.lineTo(x, y);
                if (s == 1) {
                    cracks.lineTo(x + (rnd.nextFloat() - 0.5f) * w * 0.2f, y - h * 0.08f);
                    cracks.moveTo(x, y);
                }
            }
        }
        rayShader = new LinearGradient(0, 0, 64 * u, 0, 0xFFA8F4FF, 0x0035D6FF, Shader.TileMode.CLAMP);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (!active || b.isEmpty()) {
            last = 0L;
            return;
        }
        long now = SystemClock.uptimeMillis();
        running = now < until;
        float dt = last == 0L ? 0f : Math.min(50, now - last) / 1000f;
        vis += ((running ? 1f : 0f) - vis) * Math.min(1f, dt * 5f);
        if (!running && vis < 0.03f) {
            vis = 0f;
            last = 0L;
            return;
        }
        last = now;
        t += dt;
        int w = b.width(), h = b.height();
        if (w != lw || h != lh) build(w, h);

        int save = c.save();
        c.translate(b.left, b.top);
        clip.reset();
        rf.set(2 * u, 2 * u, w - 2 * u, h - 2 * u);
        clip.addRoundRect(rf, corner, corner, Path.Direction.CW);
        c.clipPath(clip);
        c.saveLayerAlpha(0, 0, w, h, (int) (255 * Math.min(1f, vis)));
        if (kind == AIR) {
            drawAir(c, w, h, dt);
        } else if (kind == FAN) {
            drawFanTile(c, w, h, dt);
        } else {
            switch (state) {
                case 0: drawCool(c, w, h); break;
                case 1: drawDry(c, w, h); break;
                case 2: drawFanMode(c, w, h, dt); break;
                default: drawAuto(c, w, h); break;
            }
        }
        c.restoreToCount(save);
        scheduleSelf(tick, now + 16);
    }

    private void fillBg(Canvas c, int w, int h, int idx) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(bg[idx]);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
    }

    // ----------------------------------------------------------------- MODE scenes

    private void drawCool(Canvas c, int w, int h) {
        fillBg(c, w, h, 0);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < N; i++) {
            float speed = (16f + 22f * sc[i]) * u;
            float y = ((t * speed + sb[i] * (h + 12 * u)) % (h + 12 * u)) - 6 * u;
            float x = sa[i] * w + (float) Math.sin(t * 1.2f + sb[i] * 6f) * 5 * u;
            p.setColor(0xCCFFFFFF);
            c.drawCircle(x, y, (1f + 1.7f * sc[i]) * u, p);
        }
        float[][] cube = {{0.13f, 0.24f, 11f}, {0.87f, 0.30f, 9f}, {0.11f, 0.80f, 8f}, {0.88f, 0.78f, 12f}};
        for (int i = 0; i < cube.length; i++) {
            float ph = i * 1.7f;
            float s = cube[i][2] * u;
            float x = w * cube[i][0];
            float y = h * cube[i][1] + (float) Math.sin(t * 1.1f + ph) * 4 * u;
            c.save();
            c.translate(x, y);
            c.rotate(16f * (float) Math.sin(t * 0.7f + ph) + (i % 2 == 0 ? -12f : 10f));
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x66BFF3FF);
            rf.set(-s, -s, s, s);
            c.drawRoundRect(rf, s * 0.28f, s * 0.28f, p);
            p.setColor(0x44FFFFFF);
            rf.set(-s * 0.6f, -s * 0.6f, s * 0.6f, s * 0.6f);
            c.drawRoundRect(rf, s * 0.18f, s * 0.18f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.6f * u);
            p.setColor(0xDDFFFFFF);
            rf.set(-s, -s, s, s);
            c.drawRoundRect(rf, s * 0.28f, s * 0.28f, p);
            p.setStrokeWidth(2f * u);
            p.setColor(0xFFFFFFFF);
            c.drawLine(-s * 0.6f, -s * 0.3f, -s * 0.3f, -s * 0.6f, p);
            c.restore();
        }
    }

    private void drawDry(Canvas c, int w, int h) {
        fillBg(c, w, h, 1);
        float cx = w / 2f, cy = h / 2f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.6f * u);
        p.setColor(0x55FFC15A);
        for (int k = 0; k < 12; k++) {
            double an = Math.PI * 2 * k / 12 + t * 0.25;
            float r0 = h * 0.34f, r1 = h * 0.46f;
            c.drawLine(cx + (float) Math.cos(an) * r0, cy + (float) Math.sin(an) * r0,
                    cx + (float) Math.cos(an) * r1, cy + (float) Math.sin(an) * r1, p);
        }
        p.setStrokeWidth(2.2f * u);
        p.setColor(0xCCFF8A2A);
        c.drawPath(cracks, p);
        p.setStrokeWidth(4.5f * u);
        p.setColor(0x33FF8A2A);
        c.drawPath(cracks, p);
        p.setStrokeWidth(1.8f * u);
        p.setColor(0x66FFD28A);
        for (int k = 0; k < 3; k++) {
            float bx = w * (0.2f + 0.3f * k);
            spath.reset();
            for (int j = 0; j <= 9; j++) {
                float yy = h - j * h * 0.11f;
                float xx = bx + (float) Math.sin(t * 2.2f + j * 0.9f + k) * 5 * u;
                if (j == 0) spath.moveTo(xx, yy);
                else spath.lineTo(xx, yy);
            }
            c.drawPath(spath, p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 9; i++) {
            float speed = (12f + 16f * sc[i]) * u;
            float y = h - ((t * speed + sb[i] * h) % h);
            float x = sa[i] * w + (float) Math.sin(t + sb[i] * 5f) * 4 * u;
            p.setColor(0xBBFFC15A);
            c.drawCircle(x, y, (1f + 1.4f * sc[i]) * u, p);
        }
    }

    private void drawFanMode(Canvas c, int w, int h, float dt) {
        fillBg(c, w, h, 2);
        spin = (spin + dt * 240f) % 360f;
        blades(c, w / 2f, h / 2f, h * 0.46f, spin);
    }

    private void drawAuto(Canvas c, int w, int h) {
        fillBg(c, w, h, 3);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 8; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * (1.5f + sc[i] * 2f) + sa[i] * 6f);
            float x = sa[i] * w, y = sb[i] * h;
            float s = (4f + 6f * sc[i]) * u * (0.5f + tw);
            p.setColor(al(0xFFE9D4FF, 0.35f + 0.65f * tw));
            spath.reset();
            spath.moveTo(x, y - s);
            spath.quadTo(x, y, x + s, y);
            spath.quadTo(x, y, x, y + s);
            spath.quadTo(x, y, x - s, y);
            spath.quadTo(x, y, x, y - s);
            c.drawPath(spath, p);
        }
    }

    // ------------------------------------------------------------------- FAN tile

    private void drawFanTile(Canvas c, int w, int h, float dt) {
        fillBg(c, w, h, 2);
        float[] dps = {110f, 260f, 520f, 260f};
        float v = dps[Math.max(0, Math.min(3, state))];
        spin = (spin + dt * v) % 360f;
        float cx = w / 2f, cy = h / 2f, s = h * 0.5f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f * u);
        p.setColor(0x664DFFC0);
        for (int k = 0; k < 3; k++) {
            float rr = s * (1.12f - 0.12f * k);
            rf.set(cx - rr, cy - rr, cx + rr, cy + rr);
            c.drawArc(rf, -spin * 1.5f + k * 120f, 46f, false, p);
        }
        blades(c, cx, cy, s, spin);
    }

    private void blades(Canvas c, float cx, float cy, float s, float angle) {
        c.save();
        c.rotate(angle, cx, cy);
        for (int k = 0; k < 3; k++) {
            c.save();
            c.rotate(120 * k, cx, cy);
            spath.reset();
            spath.moveTo(cx, cy);
            spath.cubicTo(cx - s * 0.75f, cy - s * 0.25f, cx - s * 0.6f, cy - s * 1.0f, cx, cy - s * 0.95f);
            spath.cubicTo(cx + s * 0.35f, cy - s * 0.9f, cx + s * 0.3f, cy - s * 0.4f, cx, cy);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x444DFFC0);
            c.drawPath(spath, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f * u);
            p.setColor(0xAA4DFFC0);
            c.drawPath(spath, p);
            c.restore();
        }
        c.restore();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF4DFFC0);
        c.drawCircle(cx, cy, 4 * u, p);
    }

    // ---------------------------------------------------------------- AIRFLOW tile

    private static final float[] VANE_DEG = {10f, 26f, 42f, 58f, 72f, 86f};

    private void drawAir(Canvas c, int w, int h, float dt) {
        boolean off = state == 0, swing = state == 1;
        int pos = Math.max(0, Math.min(5, state - 2));
        float target;
        if (swing) target = 10f + 76f * (0.5f - 0.5f * (float) Math.cos(t * 2 * Math.PI / 4.6));
        else if (off) target = 172f;
        else target = VANE_DEG[pos];
        if (swing || vis < 0.12f) ang = target;
        else ang += (target - ang) * Math.min(1f, dt * 7f);

        float bx0 = 14 * u, bx1 = Math.min(w * 0.60f, 96 * u), by0 = 5 * u, by1 = 27 * u;
        float hx = bx1 - 8 * u, hy = by1 - 1 * u, fl = 21 * u;
        double rad = Math.toRadians(ang);
        float tx = hx + fl * (float) Math.cos(rad), ty = hy + fl * (float) Math.sin(rad);

        // cool air: three wavy streams leaving the flap tip, wave runs outward
        if (!off) {
            float down = Math.min(1f, Math.max(0f, (ang - 10f) / 76f));
            float len = 60 * u - 14 * u * down;
            int segs = Math.max(3, Math.round(len / (12 * u)));
            c.save();
            c.translate(tx, ty);
            c.rotate(ang);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.6f * u);
            p.setShader(rayShader);
            p.setPathEffect(new DashPathEffect(new float[]{16 * u, 9 * u}, -t * 44 * u));
            for (int j = -1; j <= 1; j++) {
                rays.reset();
                rays.moveTo(0, j * 7 * u);
                for (int k = 0; k < segs; k++) {
                    rays.rQuadTo(6 * u, ((k + j) % 2 == 0 ? -5 : 5) * u, 12 * u, 0);
                }
                p.setAlpha(j == 0 ? 255 : 200);
                c.drawPath(rays, p);
            }
            p.setPathEffect(null);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 5; i++) {
                float frac = ((t * (0.30f + 0.2f * sa[i]) + sb[i]) % 1f);
                p.setColor(al(0xFFE6FBFF, (float) Math.sin(Math.PI * frac)));
                c.drawCircle(frac * len, (sc[i] - 0.5f) * 20 * u, (1.5f + sa[i]) * u, p);
            }
            c.restore();
        }

        // split-AC body (side view)
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xF2EAF3FF);
        rf.set(bx0, by0, bx1, by1);
        c.drawRoundRect(rf, 9 * u, 9 * u, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * u);
        p.setColor(0x99FFFFFF);
        c.drawRoundRect(rf, 9 * u, 9 * u, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF9DB6E6);
        rf.set(bx0 + 8 * u, by0 + 7 * u, bx0 + 34 * u, by0 + 9 * u);
        c.drawRoundRect(rf, 1f * u, 1f * u, p);
        float led = off ? 0.25f : 0.5f + 0.5f * (float) Math.sin(t * 4);
        p.setColor(al(0xFF35D6FF, led));
        c.drawCircle(bx0 + 10 * u, by0 + 15 * u, 2.2f * u, p);

        // short flap (vane) on its hinge
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(5f * u);
        p.setColor(0xFF9DB6E6);
        c.drawLine(hx, hy, tx, ty, p);
        p.setStrokeWidth(3.4f * u);
        p.setColor(0xFFFFFFFF);
        c.drawLine(hx, hy, tx, ty, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF0A246C);
        c.drawCircle(hx, hy, 2f * u, p);

        // position scale on the right: 6 dots, current one lit (swing sweeps through them)
        float ix = w - 12 * u, iy = 14 * u, gap = 12 * u;
        float cur = swing ? (ang - 10f) / 76f * 5f : (off ? -1f : pos);
        for (int i = 0; i < 6; i++) {
            float d = Math.abs(i - cur);
            float lit = Math.max(0f, 1f - d);
            p.setColor(al(0xFF3FD0FF, 0.25f + 0.75f * lit));
            c.drawCircle(ix, iy + i * gap, (2.2f + 1.6f * lit) * u, p);
        }
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
