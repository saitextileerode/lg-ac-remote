package com.example.lgacremote;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.SystemClock;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

/** Round temperature dial. Drag or tap on the ring to set 16..30 degrees. */
public class DialView extends View {

    public interface Listener {
        void onPreview(int temp);
        void onCommit(int temp);
        void onBlocked();
    }

    private static final float START = 150f;
    private static final float TOTAL = 240f;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float density;
    private final float sp;

    private Listener listener;
    private String top = "OFF";
    private String big = "--";
    private String unit = "";
    private float frac = 0f;
    private boolean on = false;
    private int modeIcon = 0;
    private final Paint ico = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.Path ipath = new android.graphics.Path();
    private boolean dragging = false;
    private int lastTemp = -1;
    private float cx, cy;

    // ---- animated mode scene (ice / dry / fan / auto) in the dial centre ----
    private static final int NS = 18;
    private final Paint sc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final Path spath = new Path();
    private final Path cracks = new Path();
    private final RectF rr = new RectF();
    private final float[] sa = new float[NS], sb = new float[NS], sc2 = new float[NS];
    private Shader coolBg, dryBg, fanBg, autoBg;
    private int fanLevel = 2;
    private long burstAt = -100000L;
    private long lastFrame = 0L;
    private float tAnim = 0f, fanAngle = 0f;
    private boolean centerDown = false;
    private float downX, downY;

    public DialView(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        sp = getResources().getDisplayMetrics().scaledDensity;
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setStrokeWidth(20 * density);
        track.setColor(0x551E4AA8);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setStrokeWidth(30 * density);
        glow.setMaskFilter(new BlurMaskFilter(20 * density, BlurMaskFilter.Blur.NORMAL));

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(20 * density);

        knobFill.setStyle(Paint.Style.FILL);
        knobFill.setColor(0xFFFFFFFF);
        knobFill.setShadowLayer(16 * density, 0, 0, 0xFF3FD0FF);
        knobRing.setStyle(Paint.Style.STROKE);
        knobRing.setStrokeWidth(3 * density);
        knobRing.setColor(0xFF3FD0FF);

        text.setTextAlign(Paint.Align.CENTER);

        Random rnd = new Random(11);
        for (int i = 0; i < NS; i++) {
            sa[i] = rnd.nextFloat();
            sb[i] = rnd.nextFloat();
            sc2[i] = rnd.nextFloat();
        }
        sc.setStrokeCap(Paint.Cap.ROUND);
        sc.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setFanLevel(int level) {
        fanLevel = Math.max(1, Math.min(4, level));
    }

    /** Plays the short "boost" of the current mode animation (ice pop / cracks / fast fan). */
    public void burst() {
        burstAt = SystemClock.uptimeMillis();
        invalidate();
    }

    private float burstValue() {
        long age = SystemClock.uptimeMillis() - burstAt;
        if (age < 0 || age > 2600) return 0f;
        if (age < 350) return age / 350f;
        float k = 1f - (age - 350) / 2250f;
        return k * k * (3 - 2 * k);
    }

    private int modeColor() {
        switch (modeIcon) {
            case 1: return 0xFFFFA23A;
            case 2: return 0xFF4DFFC0;
            case 3: return 0xFFC58BFF;
            default: return 0xFF3FD0FF;
        }
    }

    public void setModeIcon(int m) {
        if (m != modeIcon) {
            modeIcon = m;
            burst();
        }
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setState(String top, String big, String unit, float frac, boolean on) {
        this.top = top;
        this.big = big;
        this.unit = unit;
        this.frac = Math.max(0f, Math.min(1f, frac));
        if (on && !this.on) burstAt = SystemClock.uptimeMillis();
        this.on = on;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int s = Math.min(MeasureSpec.getSize(widthSpec), (int) (340 * density));
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        cx = w / 2f;
        cy = h / 2f;
        SweepGradient g = new SweepGradient(cx, cy,
                new int[]{0xFF2BF0FF, 0xFF2F8BFF, 0xFFC070FF, 0xFF2BF0FF},
                new float[]{0f, 0.33f, 0.66f, 1f});
        Matrix m = new Matrix();
        m.setRotate(START, cx, cy);
        g.setLocalMatrix(m);
        arc.setShader(g);
        glow.setShader(g);

        float sr = radius() * 0.86f;
        coolBg = new RadialGradient(cx, cy, sr, new int[]{0x883FD0FF, 0x333FD0FF, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        dryBg = new RadialGradient(cx, cy, sr, new int[]{0x88FF9A2E, 0x33FF6A00, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        fanBg = new RadialGradient(cx, cy, sr, new int[]{0x774DFFC0, 0x2A2FBFA0, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);
        autoBg = new RadialGradient(cx, cy, sr, new int[]{0x77C58BFF, 0x2A8A5BFF, 0x00000000},
                new float[]{0f, 0.6f, 1f}, Shader.TileMode.CLAMP);

        // cracked-earth pattern for DRY mode
        cracks.reset();
        Random rnd = new Random(5);
        for (int k = 0; k < 7; k++) {
            float x = cx + (rnd.nextFloat() * 1.3f - 0.65f) * sr;
            float y = cy + sr * 0.95f;
            cracks.moveTo(x, y);
            for (int seg = 0; seg < 5; seg++) {
                x += (rnd.nextFloat() - 0.5f) * sr * 0.32f;
                y -= sr * (0.14f + 0.12f * rnd.nextFloat());
                cracks.lineTo(x, y);
                if (seg == 1 || seg == 3) {
                    float bx = x + (rnd.nextFloat() - 0.5f) * sr * 0.5f;
                    float by = y - sr * 0.12f;
                    cracks.lineTo(bx, by);
                    cracks.moveTo(x, y);
                }
            }
        }
    }

    private float radius() {
        return Math.min(cx, cy) - 30 * density;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0L ? 0f : Math.min(50, now - lastFrame) / 1000f;
        lastFrame = now;
        tAnim += dt;

        float r = radius();
        oval.set(cx - r, cy - r, cx + r, cy + r);
        int mc = modeColor();

        canvas.drawArc(oval, START, TOTAL, false, track);

        float sweep = TOTAL * frac;
        if (on) {
            if (sweep > 0.5f) {
                canvas.drawArc(oval, START, sweep, false, glow);
                canvas.drawArc(oval, START, sweep, false, arc);
            }
            double rad = Math.toRadians(START + sweep);
            float kx = cx + (float) (r * Math.cos(rad));
            float ky = cy + (float) (r * Math.sin(rad));
            canvas.drawCircle(kx, ky, (dragging ? 17 : 14) * density, knobFill);
            canvas.drawCircle(kx, ky, (dragging ? 17 : 14) * density, knobRing);
        }

        // Animated mode scene behind the numbers
        if (on) {
            float burst = burstValue();
            float sr = r * 0.86f;
            canvas.save();
            clip.reset();
            clip.addCircle(cx, cy, sr, Path.Direction.CW);
            canvas.clipPath(clip);
            switch (modeIcon) {
                case 0: drawCool(canvas, sr, burst); break;
                case 1: drawDry(canvas, sr, burst); break;
                case 2: drawFan(canvas, sr, burst, dt); break;
                default: drawAuto(canvas, sr, burst); break;
            }
            canvas.restore();
        }

        // Scale end labels
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(20 * sp);
        double a1 = Math.toRadians(START);
        double a2 = Math.toRadians(START + TOTAL);
        canvas.drawText("16", cx + (float) (r * Math.cos(a1)) + 4 * density, cy + (float) (r * Math.sin(a1)) + 36 * density, text);
        canvas.drawText("30", cx + (float) (r * Math.cos(a2)) - 4 * density, cy + (float) (r * Math.sin(a2)) + 36 * density, text);

        // Mode icon + label
        if (on) drawModeIcon(canvas, cx, cy - r * 0.80f, 22 * density, mc);
        text.setColor(mc);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(26 * sp);
        text.setShadowLayer(12 * density, 0, 0, mc);
        canvas.drawText(top, cx, cy - r * 0.40f, text);

        // Big number and unit
        text.setColor(0xFFFFFFFF);
        text.setTextSize(big.length() > 2 ? 64 * sp : 98 * sp);
        text.setShadowLayer(18 * density, 0, 0, mc);
        float shift = unit.isEmpty() ? 0f : 14 * density;
        canvas.drawText(big, cx - shift, cy + r * 0.34f, text);
        if (!unit.isEmpty()) {
            float half = text.measureText(big) / 2f;
            text.setTextSize(30 * sp);
            text.setTypeface(Typeface.DEFAULT);
            text.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(unit, cx - shift + half + 4 * density, cy + r * 0.34f - 48 * density, text);
            text.setTextAlign(Paint.Align.CENTER);
        }
        text.clearShadowLayer();

        text.setColor(0xFFFFFFFF);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(18 * sp);
        canvas.drawText("TEMP", cx, cy + r * 0.70f, text);

        if (on) postInvalidateOnAnimation();
        else lastFrame = 0L;
    }

    // ------------------------------------------------------------------ scenes

    private static int al(int color, float a) {
        int base = (color >>> 24);
        int v = Math.max(0, Math.min(255, (int) (base * a)));
        return (v << 24) | (color & 0xFFFFFF);
    }

    /** COOL: frosty glow, floating ice cubes, falling snow, expanding frost ring on touch. */
    private void drawCool(Canvas c, float sr, float b) {
        sc.setStyle(Paint.Style.FILL);
        sc.setShader(coolBg);
        sc.setAlpha((int) Math.min(255, 150 + 105 * b));
        c.drawCircle(cx, cy, sr, sc);
        sc.setShader(null);

        // snow
        sc.setStyle(Paint.Style.FILL);
        for (int i = 0; i < NS; i++) {
            float speed = (22f + 30f * sc2[i]) * density;
            float y = cy - sr + ((tAnim * speed + sb[i] * 2f * sr) % (2f * sr));
            float x = cx + (sa[i] * 2f - 1f) * sr * 0.92f + (float) Math.sin(tAnim * 1.3f + sb[i] * 6f) * 7 * density;
            float rad = (1.4f + 2.2f * sc2[i]) * density;
            sc.setColor(al(0xCCFFFFFF, 0.7f + 0.3f * b));
            c.drawCircle(x, y, rad, sc);
        }

        // ice cubes
        float[][] pos = {{-0.56f, -0.42f, 0.20f}, {0.58f, -0.36f, 0.17f}, {-0.62f, 0.34f, 0.16f},
                {0.56f, 0.46f, 0.21f}, {0.02f, 0.76f, 0.14f}};
        for (int i = 0; i < pos.length; i++) {
            float ph = i * 1.7f;
            float size = pos[i][2] * sr * (1f + 0.4f * b);
            float x = cx + pos[i][0] * sr;
            float y = cy + pos[i][1] * sr + (float) Math.sin(tAnim * 1.1f + ph) * 0.05f * sr;
            float rot = 18f * (float) Math.sin(tAnim * 0.7f + ph) + (i % 2 == 0 ? -14f : 12f);
            c.save();
            c.translate(x, y);
            c.rotate(rot);
            rr.set(-size, -size, size, size);
            sc.setStyle(Paint.Style.FILL);
            sc.setColor(al(0x77BFF3FF, 0.6f + 0.7f * b));
            c.drawRoundRect(rr, size * 0.28f, size * 0.28f, sc);
            // inner facet
            rr.set(-size * 0.62f, -size * 0.62f, size * 0.62f, size * 0.62f);
            sc.setColor(al(0x44FFFFFF, 0.6f + 0.7f * b));
            c.drawRoundRect(rr, size * 0.18f, size * 0.18f, sc);
            // edge
            sc.setStyle(Paint.Style.STROKE);
            sc.setStrokeWidth(1.8f * density);
            sc.setColor(al(0xDDFFFFFF, 0.7f + 0.3f * b));
            rr.set(-size, -size, size, size);
            c.drawRoundRect(rr, size * 0.28f, size * 0.28f, sc);
            // shine
            sc.setStrokeWidth(2.2f * density);
            sc.setColor(0xFFFFFFFF);
            c.drawLine(-size * 0.62f, -size * 0.30f, -size * 0.30f, -size * 0.62f, sc);
            c.restore();
        }

        // frost ring on touch
        if (b > 0.01f) {
            sc.setStyle(Paint.Style.STROKE);
            sc.setStrokeWidth(3 * density);
            sc.setColor(al(0xFFBFF3FF, b));
            float rad = sr * (1.02f - 0.75f * b);
            c.drawCircle(cx, cy, rad, sc);
            sc.setStrokeWidth(1.5f * density);
            for (int k = 0; k < 8; k++) {
                double an = Math.PI * k / 4 + tAnim * 0.4;
                float x1 = cx + (float) Math.cos(an) * rad;
                float y1 = cy + (float) Math.sin(an) * rad;
                c.drawLine(x1, y1, x1 + (float) Math.cos(an) * 12 * density * b, y1 + (float) Math.sin(an) * 12 * density * b, sc);
            }
        }
    }

    /** DRY: warm glow, rotating sun rays, cracked ground, rising heat shimmer and dust. */
    private void drawDry(Canvas c, float sr, float b) {
        sc.setStyle(Paint.Style.FILL);
        sc.setShader(dryBg);
        sc.setAlpha((int) Math.min(255, 150 + 105 * b));
        c.drawCircle(cx, cy, sr, sc);
        sc.setShader(null);

        // sun rays
        sc.setStyle(Paint.Style.STROKE);
        sc.setStrokeWidth(3 * density);
        sc.setColor(al(0x66FFC15A, 0.7f + 0.8f * b));
        for (int k = 0; k < 14; k++) {
            double an = Math.PI * 2 * k / 14 + tAnim * 0.25;
            float r0 = sr * (0.40f + 0.04f * (float) Math.sin(tAnim * 2 + k));
            float r1 = sr * (0.56f + 0.10f * b);
            c.drawLine(cx + (float) Math.cos(an) * r0, cy + (float) Math.sin(an) * r0,
                    cx + (float) Math.cos(an) * r1, cy + (float) Math.sin(an) * r1, sc);
        }

        // cracked earth at the bottom
        sc.setStrokeWidth(2.4f * density);
        sc.setColor(al(0xFFFF8A2A, 0.45f + 0.55f * b));
        c.drawPath(cracks, sc);
        sc.setStrokeWidth(5 * density);
        sc.setColor(al(0x33FF8A2A, 0.6f + 0.9f * b));
        c.drawPath(cracks, sc);

        // heat shimmer (wavy lines rising)
        sc.setStrokeWidth(2 * density);
        sc.setColor(al(0x55FFD28A, 0.8f + 0.6f * b));
        for (int k = 0; k < 3; k++) {
            float bx = cx + (k - 1) * sr * 0.5f;
            spath.reset();
            for (int j = 0; j <= 12; j++) {
                float yy = cy + sr * 0.8f - j * sr * 0.14f;
                float xx = bx + (float) Math.sin(tAnim * 2.2f + j * 0.9f + k) * 6 * density;
                if (j == 0) spath.moveTo(xx, yy);
                else spath.lineTo(xx, yy);
            }
            c.drawPath(spath, sc);
        }

        // dust / ember specks
        sc.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 10; i++) {
            float speed = (14f + 18f * sc2[i]) * density;
            float y = cy + sr - ((tAnim * speed + sb[i] * 2f * sr) % (2f * sr));
            float x = cx + (sa[i] * 2f - 1f) * sr * 0.9f + (float) Math.sin(tAnim + sb[i] * 5f) * 5 * density;
            sc.setColor(al(0xBBFFC15A, 0.7f + 0.3f * b));
            c.drawCircle(x, y, (1.2f + 1.6f * sc2[i]) * density, sc);
        }
    }

    /** FAN: big spinning fan. Spin speed follows the fan level and speeds up on touch. */
    private void drawFan(Canvas c, float sr, float b, float dt) {
        sc.setStyle(Paint.Style.FILL);
        sc.setShader(fanBg);
        sc.setAlpha((int) Math.min(255, 150 + 105 * b));
        c.drawCircle(cx, cy, sr, sc);
        sc.setShader(null);

        fanAngle = (fanAngle + dt * (70f + 85f * fanLevel + 420f * b)) % 360f;
        float s = sr * 0.86f;

        // wind streaks
        sc.setStyle(Paint.Style.STROKE);
        sc.setStrokeWidth(2.4f * density);
        sc.setColor(al(0x664DFFC0, 0.8f + 0.6f * b));
        for (int k = 0; k < 3; k++) {
            rr.set(cx - s * (0.95f - 0.12f * k), cy - s * (0.95f - 0.12f * k),
                    cx + s * (0.95f - 0.12f * k), cy + s * (0.95f - 0.12f * k));
            c.drawArc(rr, -fanAngle * 1.6f + k * 120f, 50f, false, sc);
        }

        c.save();
        c.rotate(fanAngle, cx, cy);
        for (int k = 0; k < 3; k++) {
            c.save();
            c.rotate(120 * k, cx, cy);
            spath.reset();
            spath.moveTo(cx, cy);
            spath.cubicTo(cx - s * 0.75f, cy - s * 0.25f, cx - s * 0.60f, cy - s * 1.0f, cx, cy - s * 0.95f);
            spath.cubicTo(cx + s * 0.35f, cy - s * 0.90f, cx + s * 0.30f, cy - s * 0.40f, cx, cy);
            sc.setStyle(Paint.Style.FILL);
            sc.setColor(al(0x554DFFC0, 0.8f + 0.8f * b));
            c.drawPath(spath, sc);
            sc.setStyle(Paint.Style.STROKE);
            sc.setStrokeWidth(2.6f * density);
            sc.setColor(al(0xEE4DFFC0, 0.8f + 0.2f * b));
            c.drawPath(spath, sc);
            c.restore();
        }
        c.restore();
        sc.setStyle(Paint.Style.FILL);
        sc.setColor(0xFF4DFFC0);
        c.drawCircle(cx, cy, 6 * density, sc);
    }

    /** AUTO: twinkling sparkles. */
    private void drawAuto(Canvas c, float sr, float b) {
        sc.setStyle(Paint.Style.FILL);
        sc.setShader(autoBg);
        sc.setAlpha((int) Math.min(255, 150 + 105 * b));
        c.drawCircle(cx, cy, sr, sc);
        sc.setShader(null);
        for (int i = 0; i < 9; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(tAnim * (1.5f + sc2[i] * 2f) + sa[i] * 6f);
            float x = cx + (sa[i] * 2f - 1f) * sr * 0.8f;
            float y = cy + (sb[i] * 2f - 1f) * sr * 0.8f;
            float s = (4f + 7f * sc2[i]) * density * (0.5f + tw) * (1f + 0.6f * b);
            sc.setColor(al(0xFFE9D4FF, 0.35f + 0.65f * tw));
            spath.reset();
            spath.moveTo(x, y - s);
            spath.quadTo(x, y, x + s, y);
            spath.quadTo(x, y, x, y + s);
            spath.quadTo(x, y, x - s, y);
            spath.quadTo(x, y, x, y - s);
            c.drawPath(spath, sc);
        }
    }

    private void drawModeIcon(Canvas c, float x, float y, float s, int color) {
        ico.setStyle(Paint.Style.STROKE);
        ico.setStrokeCap(Paint.Cap.ROUND);
        ico.setStrokeWidth(3.2f * density);
        ico.setColor(color);
        ico.setShadowLayer(10 * density, 0, 0, color);
        switch (modeIcon) {
            case 0: // snowflake
                for (int k = 0; k < 3; k++) {
                    double a = Math.PI * k / 3 + Math.PI / 2;
                    float dx = (float) Math.cos(a) * s;
                    float dy = (float) Math.sin(a) * s;
                    c.drawLine(x - dx, y - dy, x + dx, y + dy, ico);
                    for (int sgn = -1; sgn <= 1; sgn += 2) {
                        float bx = x + dx * 0.62f * sgn;
                        float by = y + dy * 0.62f * sgn;
                        double a1 = a + 0.9;
                        double a2 = a - 0.9;
                        c.drawLine(bx, by, bx + (float) Math.cos(a1) * s * 0.3f * sgn, by + (float) Math.sin(a1) * s * 0.3f * sgn, ico);
                        c.drawLine(bx, by, bx + (float) Math.cos(a2) * s * 0.3f * sgn, by + (float) Math.sin(a2) * s * 0.3f * sgn, ico);
                    }
                }
                break;
            case 1: // water drop
                ipath.reset();
                ipath.moveTo(x, y - s);
                ipath.cubicTo(x + s * 0.2f, y - s * 0.5f, x + s * 0.8f, y, x + s * 0.8f, y + s * 0.35f);
                ipath.cubicTo(x + s * 0.8f, y + s * 0.85f, x - s * 0.8f, y + s * 0.85f, x - s * 0.8f, y + s * 0.35f);
                ipath.cubicTo(x - s * 0.8f, y, x - s * 0.2f, y - s * 0.5f, x, y - s);
                c.drawPath(ipath, ico);
                break;
            case 2: // fan blades
                for (int k = 0; k < 3; k++) {
                    c.save();
                    c.rotate(120 * k, x, y);
                    ipath.reset();
                    ipath.moveTo(x, y);
                    ipath.cubicTo(x - s * 0.7f, y - s * 0.3f, x - s * 0.5f, y - s * 1.0f, x, y - s * 0.95f);
                    ipath.cubicTo(x + s * 0.3f, y - s * 0.9f, x + s * 0.3f, y - s * 0.4f, x, y);
                    c.drawPath(ipath, ico);
                    c.restore();
                }
                break;
            default: // auto: sparkle
                ipath.reset();
                ipath.moveTo(x, y - s);
                ipath.quadTo(x, y, x + s, y);
                ipath.quadTo(x, y, x, y + s);
                ipath.quadTo(x, y, x - s, y);
                ipath.quadTo(x, y, x, y - s);
                c.drawPath(ipath, ico);
                break;
        }
        ico.clearShadowLayer();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!on) return false;
                {
                    double rad = Math.toRadians(START + TOTAL * frac);
                    float kx = cx + (float) (radius() * Math.cos(rad));
                    float ky = cy + (float) (radius() * Math.sin(rad));
                    float dx = e.getX() - kx;
                    float dy = e.getY() - ky;
                    float hit = 38 * density;
                    if (dx * dx + dy * dy > hit * hit) {
                        // not the knob: a touch in the middle plays the mode animation
                        float mx = e.getX() - cx;
                        float my = e.getY() - cy;
                        float cr = radius() * 0.9f;
                        if (mx * mx + my * my <= cr * cr) {
                            centerDown = true;
                            downX = e.getX();
                            downY = e.getY();
                            burst();
                            return true;
                        }
                        return false;
                    }
                }
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                dragging = true;
                lastTemp = -1;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) update(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                centerDown = false;
                if (dragging) {
                    dragging = false;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    if (listener != null && lastTemp > 0) listener.onCommit(lastTemp);
                    invalidate();
                }
                return true;
            default:
                return true;
        }
    }

    private void update(MotionEvent e) {
        float dx = e.getX() - cx;
        float dy = e.getY() - cy;
        double ang = Math.toDegrees(Math.atan2(dy, dx));
        if (ang < 0) ang += 360;
        double rel = ang - START;
        if (rel < 0) rel += 360;
        float f;
        if (rel <= TOTAL) f = (float) (rel / TOTAL);
        else f = rel < TOTAL + (360 - TOTAL) / 2 ? 1f : 0f;
        int t = 16 + Math.round(f * 14);
        if (t != lastTemp) {
            lastTemp = t;
            if (listener != null) listener.onPreview(t);
        }
    }
}
