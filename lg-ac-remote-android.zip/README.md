# LG AC Remote (AKB75415302 layout)

Vivo போன்ல இருக்கிற IR blaster மூலமா LG AC-ஐ இயக்கும் Android app.

## APK எடுக்கிற வழி (Android Studio தேவையில்ல)

1. github.com-ல login பண்ணி புது repository உருவாக்குங்க (பெயர்: lg-ac-remote).
2. இந்த folder-ல இருக்கிற எல்லா file-களையும் (`.github` folder உட்பட) repository-ல upload பண்ணுங்க.
   `.github` folder upload ஆகலன்னா: Add file > Create new file > பெயர் பகுதில
   `.github/workflows/build.yml` ன்னு type பண்ணி, build.yml உள்ளடக்கத்தை paste பண்ணுங்க.
3. Repository-ல **Actions** tab-ஐ திறங்க. "Build APK" ஓடுறது தெரியும் (சுமார் 3-5 நிமிஷம்).
4. முடிஞ்சதும் அந்த run-ஐ தொட்டு, கீழ **Artifacts** பகுதில `LG-AC-Remote-APK` download பண்ணுங்க.
5. Zip-ஐ திறந்து `app-debug.apk`-ஐ phone-ல install பண்ணுங்க ("Unknown sources" அனுமதி கேட்கும்).

## பயன்படுத்துற முறை

- AC-ஓட sensor பக்கம் phone-ஓட IR blaster-ஐ காட்டி Power அழுத்துங்க.
- Phone-ஓட மேல் ஓரத்துல இருக்கிற சின்ன கருப்பு window தான் IR blaster.
- AC இயங்கலன்னா, கீழ இருக்கிற "IR code type" பட்டனை LG1 / LG2 ன்னு மாத்தி மறுபடி முயற்சி பண்ணுங்க.

## இந்த version-ல வேலை செய்யுறவை

Power, Mode, Temp up/down, Fan Speed, H'Cool, Swing (vertical).

மத்த பட்டன்கள் (Comfort Air, Light Off, Energy Ctrl., Swing (horizontal), Room Temp., Sleep, Func., Timer, Set/Cancel) screen-ல இருக்கும், ஆனா இப்போதைக்கு IR code இல்ல.
