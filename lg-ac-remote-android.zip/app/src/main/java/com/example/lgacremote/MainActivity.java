package com.example.lgacremote;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int BG = Color.parseColor("#D9D7D4");
    private static final int REMOTE = Color.parseColor("#F7F6F4");
    private static final int KEY = Color.parseColor("#EBE9E4");
    private static final int KEY_EDGE = Color.parseColor("#CBC7C0");
    private static final int LABEL = Color.parseColor("#6F6B64");
    private static final int POWER = Color.parseColor("#E8743B");
    private static final int LCD = Color.parseColor("#B9C4B8");
    private static final int INK = Color.parseColor("#1C2420");

    private static final String[] MODE_NAMES = {"Cool", "Dry", "Fan", "Auto", "Heat"};
    private static final int[] MODE_CODE = {0, 1, 2, 3, 4};
    private static final String[] FAN_LETTER = {"L", "M", "H", "A"};
    private static final String[] FAN_BARS = {"▂", "▂▄", "▂▄▆", "▂▄▆█"};
    private static final int[] FAN_CODE = {1, 2, 4, 5};

    private SharedPreferences prefs;
    private ConsumerIrManager ir;

    private boolean on;
    private int temp = 24;
    private int mode = 0;
    private int fan = 3;
    private boolean vswing = false;
    private boolean hcool = false;
    private boolean lg2 = false;
    private int prevTemp = 24, prevMode = 0, prevFan = 3;

    private TextView tvMode, tvTemp, tvFan, tvTags;
    private Button btnProto;
    private LinearLayout midRow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("lgac", MODE_PRIVATE);
        on = prefs.getBoolean("on", false);
        temp = prefs.getInt("temp", 24);
        mode = prefs.getInt("mode", 0);
        fan = prefs.getInt("fan", 3);
        lg2 = prefs.getBoolean("lg2", false);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        setContentView(buildUi());
        refresh();
        if (ir == null || !ir.hasIrEmitter()) {
            toast("இந்த phone-ல IR blaster கண்டுபிடிக்க முடியல");
        }
    }

    // ---------- IR ----------

    private void sendFrame(int power, int modeCode, int tempOffset, int fanCode) {
        int raw = (0x88 << 20) | (power << 18) | (modeCode << 12) | (tempOffset << 8) | (fanCode << 4);
        int sum = 0;
        for (int i = 1; i <= 4; i++) {
            sum += (raw >> (4 * i)) & 0xF;
        }
        raw |= (sum & 0xF);
        transmit(raw);
    }

    private void sendState() {
        sendFrame(0, MODE_CODE[mode], temp - 15, FAN_CODE[fan]);
    }

    private void transmit(int raw) {
        if (ir == null || !ir.hasIrEmitter()) {
            toast("IR blaster இல்ல");
            return;
        }
        int hdrMark = lg2 ? 3200 : 8500;
        int hdrSpace = lg2 ? 9900 : 4250;
        int bitMark = lg2 ? 480 : 550;
        int[] p = new int[2 + 28 * 2 + 2];
        int k = 0;
        p[k++] = hdrMark;
        p[k++] = hdrSpace;
        for (int b = 27; b >= 0; b--) {
            p[k++] = bitMark;
            p[k++] = ((raw >> b) & 1) == 1 ? 1600 : 550;
        }
        p[k++] = bitMark;
        p[k++] = 20000;
        try {
            ir.transmit(38000, p);
        } catch (Exception e) {
            toast("IR அனுப்ப முடியல");
        }
    }

    // ---------- Button actions ----------

    private boolean needOn() {
        if (!on) {
            toast("முதல்ல Power ON பண்ணுங்க");
            return false;
        }
        return true;
    }

    private void unsupported() {
        toast("இந்த பட்டனுக்கு IR code இந்த version-ல இல்ல");
    }

    private void actPower() {
        on = !on;
        if (on) {
            sendState();
        } else {
            sendFrame(3, 0, 0, 5);
        }
        refresh();
    }

    private void actMode() {
        if (!needOn()) return;
        hcool = false;
        mode = (mode + 1) % MODE_NAMES.length;
        sendState();
        refresh();
    }

    private void actTemp(int delta) {
        if (!needOn()) return;
        hcool = false;
        temp = Math.max(16, Math.min(30, temp + delta));
        sendState();
        refresh();
    }

    private void actFan() {
        if (!needOn()) return;
        fan = (fan + 1) % FAN_CODE.length;
        sendState();
        refresh();
    }

    private void actHcool() {
        if (!needOn()) return;
        if (!hcool) {
            prevTemp = temp;
            prevMode = mode;
            prevFan = fan;
            mode = 0;
            temp = 18;
            fan = 2;
            hcool = true;
        } else {
            temp = prevTemp;
            mode = prevMode;
            fan = prevFan;
            hcool = false;
        }
        sendState();
        refresh();
    }

    private void actSwingV() {
        if (!needOn()) return;
        vswing = !vswing;
        transmit(0x8810001);
        refresh();
    }

    private void actRoomTemp() {
        toast("Remote-ஆல AC-ஓட room temperature படிக்க முடியாது (IR ஒரு வழி மட்டும்)");
    }

    private void actProto() {
        lg2 = !lg2;
        refresh();
        toast("IR வகை: " + (lg2 ? "LG2" : "LG1") + ". AC-ல வேலை செய்யுதான்னு Power அழுத்தி பாருங்க");
    }

    private void refresh() {
        tvMode.setText(on ? MODE_NAMES[mode].toUpperCase() : "OFF");
        tvTemp.setText(on ? (mode == 2 ? "--" : temp + "°C") : "--");
        tvFan.setText(on ? ("FAN " + FAN_LETTER[fan] + "\n" + FAN_BARS[fan]) : "");
        tvTags.setText(on ? ((vswing ? "SWING↕ " : "") + (hcool ? "H'COOL" : "")) : "");
        midRow.setAlpha(on ? 1f : 0.3f);
        btnProto.setText("IR code type: " + (lg2 ? "LG2" : "LG1") + "  (தொட்டா மாறும்)");
        prefs.edit().putBoolean("on", on).putInt("temp", temp).putInt("mode", mode)
                .putInt("fan", fan).putBoolean("lg2", lg2).apply();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ---------- UI ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        outer.setPadding(dp(12), dp(24), dp(12), dp(24));
        sv.addView(outer, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout remote = new LinearLayout(this);
        remote.setOrientation(LinearLayout.VERTICAL);
        remote.setPadding(dp(16), dp(18), dp(16), dp(20));
        GradientDrawable rb = new GradientDrawable();
        rb.setColor(REMOTE);
        rb.setCornerRadii(new float[]{dp(14), dp(14), dp(14), dp(14), dp(26), dp(26), dp(26), dp(26)});
        remote.setBackground(rb);
        outer.addView(remote, new LinearLayout.LayoutParams(dp(304), ViewGroup.LayoutParams.WRAP_CONTENT));

        remote.addView(buildLcd());

        // Row 1
        remote.addView(row(
                key("Comfort Air", 84, 52, 26, KEY, LABEL, v -> unsupported()),
                key("⏻", 80, 52, 6, POWER, Color.WHITE, v -> actPower()),
                key("Light\nOff", 84, 52, 26, KEY, LABEL, v -> unsupported())));
        // Row 2
        remote.addView(row(
                key("Mode", 76, 76, 38, KEY, LABEL, v -> actMode()),
                key("⌃", 76, 76, 38, KEY, LABEL, v -> actTemp(1)),
                key("Fan\nSpeed", 76, 76, 38, KEY, LABEL, v -> actFan())));
        TextView tl = label("Temp.", 13, Gravity.CENTER_HORIZONTAL);
        remote.addView(tl);
        // Row 3
        remote.addView(row(
                key("Energy\nCtrl.", 76, 76, 38, KEY, LABEL, v -> unsupported()),
                key("⌄", 76, 76, 38, KEY, LABEL, v -> actTemp(-1)),
                key("H’Cool", 76, 76, 38, KEY, LABEL, v -> actHcool())));
        // Row 4
        remote.addView(row(
                key("Swing\n↕", 84, 50, 8, KEY, LABEL, v -> actSwingV()),
                key("Swing\n↔", 84, 50, 8, KEY, LABEL, v -> unsupported()),
                key("Room\nTemp.", 84, 50, 8, KEY, LABEL, v -> actRoomTemp())));
        remote.addView(label("Diagnosis(5s)", 12, Gravity.END));

        // SET UP box
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(10));
        GradientDrawable bd = new GradientDrawable();
        bd.setColor(Color.TRANSPARENT);
        bd.setStroke(dp(1), LABEL);
        box.setBackground(bd);
        box.addView(label("SET UP", 15, Gravity.START));
        box.addView(row(
                key("Sleep", 84, 52, 26, KEY, LABEL, v -> unsupported()),
                key("⌃", 84, 50, 8, KEY, LABEL, v -> unsupported()),
                key("Func.", 84, 52, 26, KEY, LABEL, v -> unsupported())));
        box.addView(row(
                key("Timer", 84, 52, 26, KEY, LABEL, v -> unsupported()),
                key("⌄", 84, 50, 8, KEY, LABEL, v -> unsupported()),
                key("Set\nCancel", 84, 52, 26, KEY, LABEL, v -> unsupported())));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(10);
        remote.addView(box, blp);

        TextView logo = new TextView(this);
        logo.setText("LG");
        logo.setTextSize(26);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setTextColor(Color.parseColor("#4B6578"));
        logo.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.topMargin = dp(14);
        remote.addView(logo, llp);

        btnProto = new Button(this);
        btnProto.setAllCaps(false);
        btnProto.setTextSize(12);
        btnProto.setTextColor(LABEL);
        btnProto.setBackgroundColor(Color.TRANSPARENT);
        btnProto.setOnClickListener(v -> actProto());
        outer.addView(btnProto, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        return sv;
    }

    private View buildLcd() {
        LinearLayout lcd = new LinearLayout(this);
        lcd.setOrientation(LinearLayout.VERTICAL);
        lcd.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable ld = new GradientDrawable();
        ld.setColor(LCD);
        ld.setCornerRadius(dp(4));
        lcd.setBackground(ld);
        lcd.setMinimumHeight(dp(170));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        tvMode = mono(16, Gravity.START);
        tvMode.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tvTags = mono(11, Gravity.END);
        top.addView(tvMode, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(tvTags, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        lcd.addView(top);

        lcd.addView(line());

        midRow = new LinearLayout(this);
        midRow.setOrientation(LinearLayout.HORIZONTAL);
        midRow.setGravity(Gravity.CENTER_VERTICAL);
        tvTemp = mono(56, Gravity.CENTER);
        tvFan = mono(12, Gravity.END);
        midRow.addView(tvTemp, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        midRow.addView(tvFan, new LinearLayout.LayoutParams(dp(56), ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(92));
        lcd.addView(midRow, mlp);

        lcd.addView(line());

        LinearLayout bot = new LinearLayout(this);
        bot.setGravity(Gravity.END);
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("a h:mm");
        clock.setFormat24Hour("a h:mm");
        clock.setTextColor(INK);
        clock.setTextSize(16);
        clock.setTypeface(Typeface.MONOSPACE);
        bot.addView(clock);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.topMargin = dp(4);
        lcd.addView(bot, blp);

        return lcd;
    }

    private View line() {
        View v = new View(this);
        v.setBackgroundColor(INK);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
        return v;
    }

    private TextView mono(int sp, int gravity) {
        TextView t = new TextView(this);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextColor(INK);
        t.setTextSize(sp);
        t.setGravity(gravity);
        return t;
    }

    private TextView label(String text, int sp, int gravity) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(LABEL);
        t.setGravity(gravity);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        t.setLayoutParams(lp);
        return t;
    }

    private Button key(String text, int wDp, int hDp, int radiusDp, int bg, int fg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(fg);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setStateListAnimator(null);
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), KEY_EDGE);
        b.setBackground(d);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(wDp), dp(hDp)));
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) v.setAlpha(0.65f);
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) v.setAlpha(1f);
            return false;
        });
        b.setOnClickListener(v -> {
            v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            l.onClick(v);
        });
        return b;
    }

    private LinearLayout row(View a, View b, View c) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        View[] vs = {a, b, c};
        for (View v : vs) {
            LinearLayout cell = new LinearLayout(this);
            cell.setGravity(Gravity.CENTER);
            cell.addView(v);
            r.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        r.setLayoutParams(lp);
        return r;
    }
}
