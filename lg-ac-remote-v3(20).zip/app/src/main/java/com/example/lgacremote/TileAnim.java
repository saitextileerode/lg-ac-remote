package com.example.lgacremote;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

import java.util.Random;

/**
 * Always-running animated background that lives INSIDE a button (clipped to its rounded shape).
 * MODE: ice / dry / fan / auto scene. FAN: spinning fan, speed follows the level. AIR: split-AC vane + airflow.
 */
public class TileAnim extends Drawable {
    public static final int MODE = 0, FAN = 1, AIR = 2;

    private static final int N = 14;
    private final int kind;
    private final float u;       // 1 dp in px
    private final float corner;  // corner radius in px

    private int state = 0;
    private boolean active = true;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final Path spath = new Path();
    private final Path cracks = new Path();
    private final Path rays = new Path();
    private final Path wedge = new Path();
    private Shader scrimG, aura, bodyG, doorG, shineG, streamG;
    private float pulse = -1f;
    private final RectF rf = new RectF();
    private final float[] sa = new float[N], sb = new float[N], sc = new float[N];
    private final Shader[] bg = new Shader[4];
    private Shader rayShader;

    private long last = 0L;
    private float t = 0f, spin = 0f, ang = 0f, rayA = 0f;
    private int lw = -1, lh = -1;
    private final Runnable tick = this::invalidateSelf;

    public TileAnim(int kind, float density, float cornerPx) {
        this.kind = kind;
        this.u = density;
        this.corner = cornerPx;
        Random r = new Random(kind * 31 + 7);
        for (int i = 0; i < N; i++) {
            sa[i] = r.nextFloat();
            sb[i] = r.nextFloat();
            sc[i] = r.nextFloat();
        }
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    /** MODE: 0 cool 1 dry 2 fan 3 auto. FAN: 0 low 1 mid 2 high 3 auto. AIR: swingPos 0 off, 1 swing, 2..7 positions. */
    public void setState(int s) {
        if (s != state) {
            state = s;
            if (inited) play(12000);
            invalidateSelf();
        }
        inited = true;
    }

    private boolean inited = false, running = false;
    private float vis = 0f;
    private long until = 0L;

    /** Run the animation for ms milliseconds, then freeze. */
    public void play(int ms) {
        until = SystemClock.uptimeMillis() + ms;
        pulse = 0f;
        last = 0L;
        invalidateSelf();
    }

    public void setActive(boolean a) {
        if (a != active) {
            active = a;
            last = 0L;
            invalidateSelf();
        }
    }

    private static int al(int color, float a) {
        int v = Math.max(0, Math.min(255, (int) ((color >>> 24) * a)));
        return (v << 24) | (color & 0xFFFFFF);
    }

    private void build(int w, int h) {
        lw = w;
        lh = h;
        int[][] cols = {{0xAA3FD0FF, 0x223FD0FF}, {0xAAFF9A2E, 0x22FF6A00},
                {0xAA4DFFC0, 0x222FBFA0}, {0xAAC58BFF, 0x228A5BFF}};
        for (int i = 0; i < 4; i++) {
            bg[i] = new LinearGradient(0, 0, 0, h, cols[i][0], cols[i][1], Shader.TileMode.CLAMP);
        }
        // cracked earth (DRY)
        cracks.reset();
        Random rnd = new Random(5);
        for (int k = 0; k < 6; k++) {
            float x = w * (0.08f + 0.84f * rnd.nextFloat());
            float y = h + 2 * u;
            cracks.moveTo(x, y);
            for (int s = 0; s < 4; s++) {
                x += (rnd.nextFloat() - 0.5f) * w * 0.14f;
                y -= h * (0.10f + 0.10f * rnd.nextFloat());
                cracks.lineTo(x, y);
                if (s == 1) {
                    cracks.lineTo(x + (rnd.nextFloat() - 0.5f) * w * 0.2f, y - h * 0.08f);
                    cracks.moveTo(x, y);
                }
            }
        }
        aura = new android.graphics.RadialGradient(125, 75, 165, 0x66288CFF, 0x00288CFF, Shader.TileMode.CLAMP);
        bodyG = new LinearGradient(0, 4, 0, 146, new int[]{0xFF0645C5, 0xFF061A4C, 0xFF0645C5}, null, Shader.TileMode.CLAMP);
        doorG = new LinearGradient(26, 0, 224, 0, new int[]{0xFF00DFFF, 0xFFE6FBFF, 0xFF00DFFF}, null, Shader.TileMode.CLAMP);
        shineG = new LinearGradient(0, 0, 50, 0, new int[]{0x00FFFFFF, 0x59BEF5FF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP);
        scrimG = new LinearGradient(0, 46, 0, 108, new int[]{0x0006164A, 0xAA06164A, 0xAA06164A, 0x0006164A}, new float[]{0f, 0.25f, 0.75f, 1f}, Shader.TileMode.CLAMP);
        streamG = new LinearGradient(0, 20, 0, 136, 0xFF78EBFF, 0x302896FF, Shader.TileMode.CLAMP);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (!active || b.isEmpty()) {
            last = 0L;
            return;
        }
        long now = SystemClock.uptimeMillis();
        running = kind == AIR || now < until;
        float dt = last == 0L ? 0f : Math.min(50, now - last) / 1000f;
        vis += ((running ? 1f : 0f) - vis) * Math.min(1f, dt * 5f);
        boolean always = true;   // scenes stay visible; MODE/FAN freeze when idle, AIRFLOW keeps flowing
        if (!always && !running && vis < 0.03f) {
            vis = 0f;
            last = 0L;
            return;
        }
        if (always && !running) dt = 0f;
        last = (always && !running) ? 0L : now;
        t += dt;
        int w = b.width(), h = b.height();
        if (w != lw || h != lh) build(w, h);

        int save = c.save();
        c.translate(b.left, b.top);
        clip.reset();
        rf.set(2 * u, 2 * u, w - 2 * u, h - 2 * u);
        clip.addRoundRect(rf, corner, corner, Path.Direction.CW);
        c.clipPath(clip);
        c.saveLayerAlpha(0, 0, w, h, always ? 255 : (int) (255 * Math.min(1f, vis)));
        if (kind == AIR) {
            drawAir(c, w, h, dt);
        } else if (kind == FAN) {
            drawFanTile(c, w, h, dt);
        } else {
            switch (state) {
                case 0: drawCool(c, w, h); break;
                case 1: drawDry(c, w, h); break;
                case 2: drawFanMode(c, w, h, dt); break;
                default: drawAuto(c, w, h); break;
            }
        }
        c.restoreToCount(save);
        if (running || (!always && vis > 0.03f)) scheduleSelf(tick, now + 16);
    }

    private void fillBg(Canvas c, int w, int h, int idx) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(bg[idx]);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
    }

    // ----------------------------------------------------------------- MODE scenes

    private void drawCool(Canvas c, int w, int h) {
        fillBg(c, w, h, 0);
        p.setStyle(Paint.Style.FILL);
        // soft falling snow dots
        for (int i = 0; i < N; i++) {
            float speed = (14f + 20f * sc[i]) * u;
            float y = ((t * speed + sb[i] * (h + 12 * u)) % (h + 12 * u)) - 6 * u;
            float x = sa[i] * w + (float) Math.sin(t * 1.2f + sb[i] * 6f) * 6 * u;
            p.setColor(0xDDFFFFFF);
            c.drawCircle(x, y, (1.2f + 2f * sc[i]) * u, p);
        }
        // big six-arm snowflakes drifting down
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 8; i++) {
            float s = (4f + 4.5f * sc[i]) * u;
            float speed = (9f + 9f * sc[(i + 3) % N]) * u;
            float y = ((t * speed + sb[i] * (h + 24 * u)) % (h + 24 * u)) - 12 * u;
            float x = sa[(i + 5) % N] * w + (float) Math.sin(t * 0.9f + i) * 9 * u;
            c.save();
            c.translate(x, y);
            c.rotate(t * (14f + 6f * i) * (i % 2 == 0 ? 1 : -1));
            p.setColor(al(0xFFFFFFFF, 0.55f + 0.45f * sc[i]));
            p.setStrokeWidth(1.5f * u);
            for (int k = 0; k < 3; k++) {
                c.drawLine(-s, 0, s, 0, p);
                c.rotate(60f);
            }
            c.restore();
        }
        p.setStyle(Paint.Style.FILL);
    }

    private void drawDry(Canvas c, int w, int h) {
        fillBg(c, w, h, 1);
        // warm heat-shimmer lines
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(1.8f * u);
        p.setColor(0x44FFD28A);
        for (int k = 0; k < 4; k++) {
            float bx = w * (0.14f + 0.24f * k);
            spath.reset();
            for (int j = 0; j <= 10; j++) {
                float yy = h - j * h * 0.10f;
                float xx = bx + (float) Math.sin(t * 2f + j * 0.8f + k) * 5 * u;
                if (j == 0) spath.moveTo(xx, yy);
                else spath.lineTo(xx, yy);
            }
            c.drawPath(spath, p);
        }
        // water drops evaporating upwards
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 10; i++) {
            float q = (t * (0.10f + 0.12f * sc[i]) + sb[i]) % 1f;
            float s = (4.5f + 5.5f * sc[i]) * u * (1f - 0.45f * q);
            float x = (0.08f + 0.84f * sa[i]) * w + (float) Math.sin(t * 1.5f + sb[i] * 6f) * 4 * u;
            float y = h * 1.05f - q * h * 1.1f;
            float a = (float) Math.sin(Math.PI * q);
            c.save();
            c.translate(x, y);
            spath.reset();
            spath.moveTo(0, -s * 1.5f);
            spath.quadTo(s * 1.15f, s * 0.2f, 0, s);
            spath.quadTo(-s * 1.15f, s * 0.2f, 0, -s * 1.5f);
            p.setColor(al(0xFFFFC866, 0.9f * a));
            c.drawPath(spath, p);
            p.setColor(al(0xFFFFFFFF, 0.7f * a));
            c.drawCircle(-s * 0.3f, s * 0.15f, s * 0.22f, p);
            c.restore();
        }
    }

    private void drawFanMode(Canvas c, int w, int h, float dt) {
        fillBg(c, w, h, 2);
        spin = (spin + dt * 240f) % 360f;
        blades(c, w / 2f, h / 2f, h * 0.46f, spin);
    }

    private void drawAuto(Canvas c, int w, int h) {
        fillBg(c, w, h, 3);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 8; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * (1.5f + sc[i] * 2f) + sa[i] * 6f);
            float x = sa[i] * w, y = sb[i] * h;
            float s = (4f + 6f * sc[i]) * u * (0.5f + tw);
            p.setColor(al(0xFFE9D4FF, 0.35f + 0.65f * tw));
            spath.reset();
            spath.moveTo(x, y - s);
            spath.quadTo(x, y, x + s, y);
            spath.quadTo(x, y, x, y + s);
            spath.quadTo(x, y, x - s, y);
            spath.quadTo(x, y, x, y - s);
            c.drawPath(spath, p);
        }
    }

    // ------------------------------------------------------------------- FAN tile

    private void drawFanTile(Canvas c, int w, int h, float dt) {
        fillBg(c, w, h, 2);
        float[] dps = {110f, 260f, 520f, 260f};
        float v = dps[Math.max(0, Math.min(3, state))];
        spin = (spin + dt * v) % 360f;
        float cx = w / 2f, cy = h / 2f, s = h * 0.5f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f * u);
        p.setColor(0x664DFFC0);
        for (int k = 0; k < 3; k++) {
            float rr = s * (1.12f - 0.12f * k);
            rf.set(cx - rr, cy - rr, cx + rr, cy + rr);
            c.drawArc(rf, -spin * 1.5f + k * 120f, 46f, false, p);
        }
        blades(c, cx, cy, s, spin);
    }

    private void blades(Canvas c, float cx, float cy, float s, float angle) {
        c.save();
        c.rotate(angle, cx, cy);
        for (int k = 0; k < 3; k++) {
            c.save();
            c.rotate(120 * k, cx, cy);
            spath.reset();
            spath.moveTo(cx, cy);
            spath.cubicTo(cx - s * 0.75f, cy - s * 0.25f, cx - s * 0.6f, cy - s * 1.0f, cx, cy - s * 0.95f);
            spath.cubicTo(cx + s * 0.35f, cy - s * 0.9f, cx + s * 0.3f, cy - s * 0.4f, cx, cy);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x444DFFC0);
            c.drawPath(spath, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f * u);
            p.setColor(0xAA4DFFC0);
            c.drawPath(spath, p);
            c.restore();
        }
        c.restore();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF4DFFC0);
        c.drawCircle(cx, cy, 4 * u, p);
    }

    // ---------------------------------------------------------------- AIRFLOW tile

    private static final float[] VANE_DEG = {12f, 28f, 44f, 60f, 74f, 88f};

    public static int airStyle = 0;   // unused, kept for compatibility

    private void glowLine(Canvas c, float x1, float y1, float x2, float y2, float wd, int col) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(al(col, 0.18f));
        p.setStrokeWidth(wd * 3.2f);
        c.drawLine(x1, y1, x2, y2, p);
        p.setColor(al(col, 0.35f));
        p.setStrokeWidth(wd * 1.9f);
        c.drawLine(x1, y1, x2, y2, p);
        p.setColor(col);
        p.setStrokeWidth(wd);
        c.drawLine(x1, y1, x2, y2, p);
    }

    private void drawAir(Canvas c, int w, int h, float dt) {
        boolean off = state == 0, swing = state == 1;
        float tg = swing ? 0.5f - 0.5f * (float) Math.cos(t * 2 * Math.PI / 4.6)
                : (off ? 1f : (state - 2) / 5f);
        if (swing || !running) ang = tg;
        else ang += (tg - ang) * Math.min(1f, dt * 7f);
        if (!running) pulse = -1f;
        if (pulse >= 0f) {
            pulse += dt;
            if (pulse > 1.1f) pulse = -1f;
        }
        // the scene is drawn in a 250 x 150 space stretched to fill the whole button
        int base = c.save();
        c.scale(w / 250f, h / 150f);
        RectF body = new RectF(5, 5, 245, 145);
        RectF vent = new RectF(14, 13, 236, 137);

        p.setStyle(Paint.Style.FILL);
        p.setShader(aura);
        c.drawRect(0, 0, 250, 150, p);
        p.setShader(null);

        // neon AC casing = the whole button
        p.setShader(bodyG);
        c.drawRoundRect(body, 16, 16, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0x2800DFFF);
        p.setStrokeWidth(8);
        c.drawRoundRect(body, 16, 16, p);
        p.setColor(0x5500DFFF);
        p.setStrokeWidth(4.5f);
        c.drawRoundRect(body, 16, 16, p);
        p.setColor(0xFF00DFFF);
        p.setStrokeWidth(2.2f);
        c.drawRoundRect(body, 16, 16, p);

        // dark vent opening
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF03103A);
        c.drawRoundRect(vent, 11, 11, p);

        int sv = c.save();
        clip.reset();
        clip.addRoundRect(vent, 11, 11, Path.Direction.CW);
        c.clipPath(clip);

        float dy = 18 + 56 * ang;   // door top: Highest = up, Lowest = down

        // neon air streams below the door (dimmed while idle)
        int slayer = -1;
        if (!off) {
            float y0 = dy + 12;
            float step = (134 - y0) / 26f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(2.8f);
            p.setShader(streamG);
            for (int j = 0; j < 8; j++) {
                float gx = 36 + j * 25.5f;
                rays.reset();
                for (int k = 0; k <= 26; k++) {
                    float yy = y0 + k * step;
                    float wob = (float) Math.sin(k * 0.62f - t * 6.5f + j * 0.9f) * (2 + k * 0.12f);
                    if (k == 0) rays.moveTo(gx + wob, yy); else rays.lineTo(gx + wob, yy);
                }
                p.setPathEffect(new DashPathEffect(new float[]{18, 9}, -(t * 46 + j * 5)));
                c.drawPath(rays, p);
            }
            p.setPathEffect(null);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 14; i++) {
                float qq = (t * (0.3f + (i % 4) * 0.1f) + i * 0.173f) % 1f;
                float px = 30 + ((i * 37) % 190) + (float) Math.sin(t * 3 + i) * 3;
                p.setColor(al(0xFFBEF5FF, (float) Math.sin(Math.PI * qq) * 0.9f));
                c.drawCircle(px, y0 + qq * (134 - y0), 1 + (i % 3) * 0.5f, p);
            }
        }
        if (slayer >= 0) c.restoreToCount(slayer);

        // moving shine across the casing
        c.save();
        c.translate((t * 70) % 330 - 50, 0);
        p.setStyle(Paint.Style.FILL);
        p.setShader(shineG);
        c.drawRect(0, 13, 50, 137, p);
        p.setShader(null);
        c.restore();

        // door: glowing neon bar, 6 stages
        rf.set(24, dy, 226, dy + 11);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x2500DFFF);
        rf.inset(-4, -4);
        c.drawRoundRect(rf, 9, 9, p);
        rf.inset(4, 4);
        p.setColor(0x4D00DFFF);
        rf.inset(-2, -2);
        c.drawRoundRect(rf, 7, 7, p);
        rf.inset(2, 2);
        p.setShader(doorG);
        c.drawRoundRect(rf, 5.5f, 5.5f, p);
        p.setShader(null);
        c.restoreToCount(sv);

        // dark scrim so the AIRFLOW label stays readable
        p.setStyle(Paint.Style.FILL);
        p.setShader(scrimG);
        c.drawRect(14, 46, 236, 108, p);
        p.setShader(null);

        // stage dots (6): current one lit, swing sweeps through them
        float cur = swing ? ang * 5f : (off ? -9f : state - 2);
        for (int i = 0; i < 6; i++) {
            float lit = Math.max(0f, 1f - Math.abs(i - cur));
            float ty = 18 + 56 * (i / 5f) + 5.5f;
            if (lit > 0.05f) {
                p.setColor(al(0xFF00DFFF, 0.3f * lit));
                c.drawCircle(226, ty, 4.5f + 2f * lit, p);
            }
            p.setColor(al(0xFF78EBFF, 0.3f + 0.7f * lit));
            c.drawCircle(226, ty, 1.8f + 1.8f * lit, p);
        }

        // tap pulse ring
        if (pulse >= 0f) {
            float r = 10 + pulse * 150;
            rf.set(125 - r * 1.5f, 75 - r * 0.6f, 125 + r * 1.5f, 75 + r * 0.6f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.4f);
            p.setColor(al(0xFF78EBFF, (1 - pulse / 1.1f) * 0.8f));
            c.drawOval(rf, p);
        }
        p.setStyle(Paint.Style.FILL);
        c.restoreToCount(base);
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
