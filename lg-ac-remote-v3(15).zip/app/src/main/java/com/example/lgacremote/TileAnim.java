package com.example.lgacremote;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

import java.util.Random;

/**
 * Always-running animated background that lives INSIDE a button (clipped to its rounded shape).
 * MODE: ice / dry / fan / auto scene. FAN: spinning fan, speed follows the level. AIR: split-AC vane + airflow.
 */
public class TileAnim extends Drawable {
    public static final int MODE = 0, FAN = 1, AIR = 2;

    private static final int N = 14;
    private final int kind;
    private final float u;       // 1 dp in px
    private final float corner;  // corner radius in px

    private int state = 0;
    private boolean active = true;

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private final Path spath = new Path();
    private final Path cracks = new Path();
    private final Path rays = new Path();
    private final Path wedge = new Path();
    private Shader aura, bodyG, doorG, shineG, streamG;
    private float pulse = -1f;
    private final RectF rf = new RectF();
    private final float[] sa = new float[N], sb = new float[N], sc = new float[N];
    private final Shader[] bg = new Shader[4];
    private Shader rayShader;

    private long last = 0L;
    private float t = 0f, spin = 0f, ang = 0f, rayA = 0f;
    private int lw = -1, lh = -1;
    private final Runnable tick = this::invalidateSelf;

    public TileAnim(int kind, float density, float cornerPx) {
        this.kind = kind;
        this.u = density;
        this.corner = cornerPx;
        Random r = new Random(kind * 31 + 7);
        for (int i = 0; i < N; i++) {
            sa[i] = r.nextFloat();
            sb[i] = r.nextFloat();
            sc[i] = r.nextFloat();
        }
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    /** MODE: 0 cool 1 dry 2 fan 3 auto. FAN: 0 low 1 mid 2 high 3 auto. AIR: swingPos 0 off, 1 swing, 2..7 positions. */
    public void setState(int s) {
        if (s != state) {
            state = s;
            if (inited) play(5000);
            invalidateSelf();
        }
        inited = true;
    }

    private boolean inited = false, running = false;
    private float vis = 0f;
    private long until = 0L;

    /** Run the animation for ms milliseconds, then freeze. */
    public void play(int ms) {
        until = SystemClock.uptimeMillis() + ms;
        pulse = 0f;
        last = 0L;
        invalidateSelf();
    }

    public void setActive(boolean a) {
        if (a != active) {
            active = a;
            last = 0L;
            invalidateSelf();
        }
    }

    private static int al(int color, float a) {
        int v = Math.max(0, Math.min(255, (int) ((color >>> 24) * a)));
        return (v << 24) | (color & 0xFFFFFF);
    }

    private void build(int w, int h) {
        lw = w;
        lh = h;
        int[][] cols = {{0xAA3FD0FF, 0x223FD0FF}, {0xAAFF9A2E, 0x22FF6A00},
                {0xAA4DFFC0, 0x222FBFA0}, {0xAAC58BFF, 0x228A5BFF}};
        for (int i = 0; i < 4; i++) {
            bg[i] = new LinearGradient(0, 0, 0, h, cols[i][0], cols[i][1], Shader.TileMode.CLAMP);
        }
        // cracked earth (DRY)
        cracks.reset();
        Random rnd = new Random(5);
        for (int k = 0; k < 6; k++) {
            float x = w * (0.08f + 0.84f * rnd.nextFloat());
            float y = h + 2 * u;
            cracks.moveTo(x, y);
            for (int s = 0; s < 4; s++) {
                x += (rnd.nextFloat() - 0.5f) * w * 0.14f;
                y -= h * (0.10f + 0.10f * rnd.nextFloat());
                cracks.lineTo(x, y);
                if (s == 1) {
                    cracks.lineTo(x + (rnd.nextFloat() - 0.5f) * w * 0.2f, y - h * 0.08f);
                    cracks.moveTo(x, y);
                }
            }
        }
        float q = w / 250f;
        aura = new android.graphics.RadialGradient(125 * q, 40 * q, 150 * q, 0x66288CFF, 0x00288CFF, Shader.TileMode.CLAMP);
        bodyG = new LinearGradient(0, 8 * q, 0, 70 * q, 0x8C3C96FF, 0xD90F32A0, Shader.TileMode.CLAMP);
        doorG = new LinearGradient(31 * q, 0, 219 * q, 0, new int[]{0xFF35D0FF, 0xFFE6FBFF, 0xFF35D0FF}, null, Shader.TileMode.CLAMP);
        shineG = new LinearGradient(0, 0, 50 * q, 0, new int[]{0x00FFFFFF, 0x59BEF5FF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP);
        streamG = new LinearGradient(0, 74 * q, 0, 150 * q, 0xFF78EBFF, 0x002896FF, Shader.TileMode.CLAMP);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (!active || b.isEmpty()) {
            last = 0L;
            return;
        }
        long now = SystemClock.uptimeMillis();
        running = now < until;
        float dt = last == 0L ? 0f : Math.min(50, now - last) / 1000f;
        vis += ((running ? 1f : 0f) - vis) * Math.min(1f, dt * 5f);
        if (!running && vis < 0.03f) {
            vis = 0f;
            last = 0L;
            return;
        }
        last = now;
        t += dt;
        int w = b.width(), h = b.height();
        if (w != lw || h != lh) build(w, h);

        int save = c.save();
        c.translate(b.left, b.top);
        clip.reset();
        rf.set(2 * u, 2 * u, w - 2 * u, h - 2 * u);
        clip.addRoundRect(rf, corner, corner, Path.Direction.CW);
        c.clipPath(clip);
        c.saveLayerAlpha(0, 0, w, h, (int) (255 * Math.min(1f, vis)));
        if (kind == AIR) {
            drawAir(c, w, h, dt);
        } else if (kind == FAN) {
            drawFanTile(c, w, h, dt);
        } else {
            switch (state) {
                case 0: drawCool(c, w, h); break;
                case 1: drawDry(c, w, h); break;
                case 2: drawFanMode(c, w, h, dt); break;
                default: drawAuto(c, w, h); break;
            }
        }
        c.restoreToCount(save);
        scheduleSelf(tick, now + 16);
    }

    private void fillBg(Canvas c, int w, int h, int idx) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(bg[idx]);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
    }

    // ----------------------------------------------------------------- MODE scenes

    private void drawCool(Canvas c, int w, int h) {
        fillBg(c, w, h, 0);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < N; i++) {
            float speed = (16f + 22f * sc[i]) * u;
            float y = ((t * speed + sb[i] * (h + 12 * u)) % (h + 12 * u)) - 6 * u;
            float x = sa[i] * w + (float) Math.sin(t * 1.2f + sb[i] * 6f) * 5 * u;
            p.setColor(0xCCFFFFFF);
            c.drawCircle(x, y, (1f + 1.7f * sc[i]) * u, p);
        }
        float[][] cube = {{0.13f, 0.24f, 11f}, {0.87f, 0.30f, 9f}, {0.11f, 0.80f, 8f}, {0.88f, 0.78f, 12f}};
        for (int i = 0; i < cube.length; i++) {
            float ph = i * 1.7f;
            float s = cube[i][2] * u;
            float x = w * cube[i][0];
            float y = h * cube[i][1] + (float) Math.sin(t * 1.1f + ph) * 4 * u;
            c.save();
            c.translate(x, y);
            c.rotate(16f * (float) Math.sin(t * 0.7f + ph) + (i % 2 == 0 ? -12f : 10f));
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x66BFF3FF);
            rf.set(-s, -s, s, s);
            c.drawRoundRect(rf, s * 0.28f, s * 0.28f, p);
            p.setColor(0x44FFFFFF);
            rf.set(-s * 0.6f, -s * 0.6f, s * 0.6f, s * 0.6f);
            c.drawRoundRect(rf, s * 0.18f, s * 0.18f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.6f * u);
            p.setColor(0xDDFFFFFF);
            rf.set(-s, -s, s, s);
            c.drawRoundRect(rf, s * 0.28f, s * 0.28f, p);
            p.setStrokeWidth(2f * u);
            p.setColor(0xFFFFFFFF);
            c.drawLine(-s * 0.6f, -s * 0.3f, -s * 0.3f, -s * 0.6f, p);
            c.restore();
        }
    }

    private void drawDry(Canvas c, int w, int h) {
        fillBg(c, w, h, 1);
        float cx = w / 2f, cy = h / 2f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.6f * u);
        p.setColor(0x55FFC15A);
        for (int k = 0; k < 12; k++) {
            double an = Math.PI * 2 * k / 12 + t * 0.25;
            float r0 = h * 0.34f, r1 = h * 0.46f;
            c.drawLine(cx + (float) Math.cos(an) * r0, cy + (float) Math.sin(an) * r0,
                    cx + (float) Math.cos(an) * r1, cy + (float) Math.sin(an) * r1, p);
        }
        p.setStrokeWidth(2.2f * u);
        p.setColor(0xCCFF8A2A);
        c.drawPath(cracks, p);
        p.setStrokeWidth(4.5f * u);
        p.setColor(0x33FF8A2A);
        c.drawPath(cracks, p);
        p.setStrokeWidth(1.8f * u);
        p.setColor(0x66FFD28A);
        for (int k = 0; k < 3; k++) {
            float bx = w * (0.2f + 0.3f * k);
            spath.reset();
            for (int j = 0; j <= 9; j++) {
                float yy = h - j * h * 0.11f;
                float xx = bx + (float) Math.sin(t * 2.2f + j * 0.9f + k) * 5 * u;
                if (j == 0) spath.moveTo(xx, yy);
                else spath.lineTo(xx, yy);
            }
            c.drawPath(spath, p);
        }
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 9; i++) {
            float speed = (12f + 16f * sc[i]) * u;
            float y = h - ((t * speed + sb[i] * h) % h);
            float x = sa[i] * w + (float) Math.sin(t + sb[i] * 5f) * 4 * u;
            p.setColor(0xBBFFC15A);
            c.drawCircle(x, y, (1f + 1.4f * sc[i]) * u, p);
        }
    }

    private void drawFanMode(Canvas c, int w, int h, float dt) {
        fillBg(c, w, h, 2);
        spin = (spin + dt * 240f) % 360f;
        blades(c, w / 2f, h / 2f, h * 0.46f, spin);
    }

    private void drawAuto(Canvas c, int w, int h) {
        fillBg(c, w, h, 3);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 8; i++) {
            float tw = 0.5f + 0.5f * (float) Math.sin(t * (1.5f + sc[i] * 2f) + sa[i] * 6f);
            float x = sa[i] * w, y = sb[i] * h;
            float s = (4f + 6f * sc[i]) * u * (0.5f + tw);
            p.setColor(al(0xFFE9D4FF, 0.35f + 0.65f * tw));
            spath.reset();
            spath.moveTo(x, y - s);
            spath.quadTo(x, y, x + s, y);
            spath.quadTo(x, y, x, y + s);
            spath.quadTo(x, y, x - s, y);
            spath.quadTo(x, y, x, y - s);
            c.drawPath(spath, p);
        }
    }

    // ------------------------------------------------------------------- FAN tile

    private void drawFanTile(Canvas c, int w, int h, float dt) {
        fillBg(c, w, h, 2);
        float[] dps = {110f, 260f, 520f, 260f};
        float v = dps[Math.max(0, Math.min(3, state))];
        spin = (spin + dt * v) % 360f;
        float cx = w / 2f, cy = h / 2f, s = h * 0.5f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f * u);
        p.setColor(0x664DFFC0);
        for (int k = 0; k < 3; k++) {
            float rr = s * (1.12f - 0.12f * k);
            rf.set(cx - rr, cy - rr, cx + rr, cy + rr);
            c.drawArc(rf, -spin * 1.5f + k * 120f, 46f, false, p);
        }
        blades(c, cx, cy, s, spin);
    }

    private void blades(Canvas c, float cx, float cy, float s, float angle) {
        c.save();
        c.rotate(angle, cx, cy);
        for (int k = 0; k < 3; k++) {
            c.save();
            c.rotate(120 * k, cx, cy);
            spath.reset();
            spath.moveTo(cx, cy);
            spath.cubicTo(cx - s * 0.75f, cy - s * 0.25f, cx - s * 0.6f, cy - s * 1.0f, cx, cy - s * 0.95f);
            spath.cubicTo(cx + s * 0.35f, cy - s * 0.9f, cx + s * 0.3f, cy - s * 0.4f, cx, cy);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x444DFFC0);
            c.drawPath(spath, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2f * u);
            p.setColor(0xAA4DFFC0);
            c.drawPath(spath, p);
            c.restore();
        }
        c.restore();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF4DFFC0);
        c.drawCircle(cx, cy, 4 * u, p);
    }

    // ---------------------------------------------------------------- AIRFLOW tile

    private static final float[] VANE_DEG = {12f, 28f, 44f, 60f, 74f, 88f};

    public static int airStyle = 0;   // unused, kept for compatibility

    private void glowLine(Canvas c, float x1, float y1, float x2, float y2, float wd, int col) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(al(col, 0.18f));
        p.setStrokeWidth(wd * 3.2f);
        c.drawLine(x1, y1, x2, y2, p);
        p.setColor(al(col, 0.35f));
        p.setStrokeWidth(wd * 1.9f);
        c.drawLine(x1, y1, x2, y2, p);
        p.setColor(col);
        p.setStrokeWidth(wd);
        c.drawLine(x1, y1, x2, y2, p);
    }

    private void drawAir(Canvas c, int w, int h, float dt) {
        boolean off = state == 0, swing = state == 1;
        float tg = swing ? 0.5f - 0.5f * (float) Math.cos(t * 2 * Math.PI / 4.6)
                : (off ? 1f : (state - 2) / 5f);
        if (swing || vis < 0.12f) ang = tg;
        else ang += (tg - ang) * Math.min(1f, dt * 7f);
        if (pulse >= 0f) {
            pulse += dt;
            if (pulse > 1.1f) pulse = -1f;
        }
        float q = w / 250f;

        // blue aura
        p.setStyle(Paint.Style.FILL);
        p.setShader(aura);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);

        // neon air streams
        if (!off) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(2.6f * q);
            p.setShader(streamG);
            for (int j = 0; j < 8; j++) {
                float gx = (36 + j * 25.5f) * q;
                rays.reset();
                for (int k = 0; k <= 26; k++) {
                    float yy = (74 + k * 2.9f) * q;
                    float wob = (float) Math.sin(k * 0.62f - t * 6.5f + j * 0.9f) * (2 + k * 0.12f) * q;
                    if (k == 0) rays.moveTo(gx + wob, yy); else rays.lineTo(gx + wob, yy);
                }
                p.setPathEffect(new DashPathEffect(new float[]{18 * q, 9 * q}, -(t * 46 + j * 5) * q));
                c.drawPath(rays, p);
            }
            p.setPathEffect(null);
            p.setShader(null);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < 14; i++) {
                float qq = (t * (0.3f + (i % 4) * 0.1f) + i * 0.173f) % 1f;
                float px = (30 + ((i * 37) % 190) + (float) Math.sin(t * 3 + i) * 3) * q;
                p.setColor(al(0xFFBEF5FF, (float) Math.sin(Math.PI * qq) * 0.9f));
                c.drawCircle(px, (74 + qq * 70) * q, (1 + (i % 3) * 0.5f) * q, p);
            }
        }

        // AC body: glass blue with neon outline
        rf.set(16 * q, 8 * q, 234 * q, 70 * q);
        p.setStyle(Paint.Style.FILL);
        p.setShader(bodyG);
        c.drawRoundRect(rf, 14 * q, 14 * q, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setColor(0x305FE3FF);
        p.setStrokeWidth(7 * q);
        c.drawRoundRect(rf, 14 * q, 14 * q, p);
        p.setColor(0x555FE3FF);
        p.setStrokeWidth(4 * q);
        c.drawRoundRect(rf, 14 * q, 14 * q, p);
        p.setColor(0xFF5FE3FF);
        p.setStrokeWidth(2 * q);
        c.drawRoundRect(rf, 14 * q, 14 * q, p);

        // moving shine
        int sv = c.save();
        clip.reset();
        clip.addRoundRect(rf, 14 * q, 14 * q, Path.Direction.CW);
        c.clipPath(clip);
        c.translate(((t * 70) % 320 - 50) * q, 0);
        p.setStyle(Paint.Style.FILL);
        p.setShader(shineG);
        c.drawRect(0, 8 * q, 50 * q, 70 * q, p);
        p.setShader(null);
        c.restoreToCount(sv);

        // dark vent opening
        rf.set(28 * q, 16 * q, 222 * q, 62 * q);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF04103A);
        c.drawRoundRect(rf, 9 * q, 9 * q, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f * q);
        p.setColor(0x8C5FE3FF);
        c.drawRoundRect(rf, 9 * q, 9 * q, p);

        // door: glowing neon bar, 6 stages
        float y = (19 + 28 * ang) * q;
        rf.set(31 * q, y, 219 * q, y + 9 * q);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x2535D0FF);
        rf.inset(-3 * q, -3 * q);
        c.drawRoundRect(rf, 7 * q, 7 * q, p);
        rf.inset(3 * q, 3 * q);
        p.setColor(0x4D35D0FF);
        rf.inset(-1.5f * q, -1.5f * q);
        c.drawRoundRect(rf, 6 * q, 6 * q, p);
        rf.inset(1.5f * q, 1.5f * q);
        p.setShader(doorG);
        c.drawRoundRect(rf, 4.5f * q, 4.5f * q, p);
        p.setShader(null);

        // stage dots (6)
        float cur = swing ? ang * 5f : (off ? -9f : state - 2);
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 6; i++) {
            float lit = Math.max(0f, 1f - Math.abs(i - cur));
            float ty = (19 + 28 * (i / 5f) + 4.5f) * q;
            if (lit > 0.05f) {
                p.setColor(al(0xFF35D0FF, 0.3f * lit));
                c.drawCircle(226 * q, ty, (4.5f + 2f * lit) * q, p);
            }
            p.setColor(al(0xFF78EBFF, 0.3f + 0.7f * lit));
            c.drawCircle(226 * q, ty, (1.8f + 1.8f * lit) * q, p);
        }

        // tap pulse ring
        if (pulse >= 0f) {
            float r = 10 + pulse * 150;
            rf.set(125 * q - r * 1.5f * q, 40 * q - r * 0.6f * q, 125 * q + r * 1.5f * q, 40 * q + r * 0.6f * q);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(2.2f * q);
            p.setColor(al(0xFF78EBFF, (1 - pulse / 1.1f) * 0.8f));
            c.drawOval(rf, p);
        }
        p.setStyle(Paint.Style.FILL);
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
