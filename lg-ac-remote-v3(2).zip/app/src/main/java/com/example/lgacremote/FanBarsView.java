package com.example.lgacremote;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Four ascending bars that show the fan level (0..4). */
public class FanBarsView extends View {

    private final Paint on = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint off = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final float density;
    private int level = 0;

    public FanBarsView(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        on.setColor(0xFF3FD0FF);
        off.setColor(0x33FFFFFF);
    }

    public void setLevel(int level) {
        this.level = level;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        setMeasuredDimension((int) (40 * density), (int) (26 * density));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float bw = 7 * density;
        float gap = 3.5f * density;
        float bottom = getHeight();
        for (int i = 0; i < 4; i++) {
            float bh = (9 + 5 * i) * density;
            float left = i * (bw + gap);
            rect.set(left, bottom - bh, left + bw, bottom);
            canvas.drawRoundRect(rect, 2 * density, 2 * density, i < level ? on : off);
        }
    }
}
