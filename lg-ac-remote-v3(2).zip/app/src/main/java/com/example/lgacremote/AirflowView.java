package com.example.lgacremote;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/**
 * Airflow illustration. Vertical: 6 rays fanning down-left, one per vane position.
 * Horizontal: 7 rays fanning down. The active ray glows; while swinging the glow sweeps.
 */
public class AirflowView extends View {

    private final boolean vertical;
    private final float density;
    private final Paint outline = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rayOn = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rayGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rayOff = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotOn = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotOff = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    private int pos = 3;
    private boolean swinging = false;

    public AirflowView(Context c, boolean vertical) {
        super(c);
        this.vertical = vertical;
        density = getResources().getDisplayMetrics().density;
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        outline.setStyle(Paint.Style.STROKE);
        outline.setStrokeCap(Paint.Cap.ROUND);
        outline.setStrokeJoin(Paint.Join.ROUND);
        outline.setStrokeWidth(5 * density);
        outline.setColor(0xFF8A94A6);

        rayOn.setStyle(Paint.Style.STROKE);
        rayOn.setStrokeCap(Paint.Cap.ROUND);
        rayOn.setStrokeWidth(6 * density);
        rayOn.setColor(0xFF5B8CFF);

        rayGlow.setStyle(Paint.Style.STROKE);
        rayGlow.setStrokeCap(Paint.Cap.ROUND);
        rayGlow.setStrokeWidth(10 * density);
        rayGlow.setColor(0xAA3FD0FF);
        rayGlow.setMaskFilter(new BlurMaskFilter(7 * density, BlurMaskFilter.Blur.NORMAL));

        rayOff.setStyle(Paint.Style.STROKE);
        rayOff.setStrokeCap(Paint.Cap.ROUND);
        rayOff.setStrokeWidth(5 * density);
        rayOff.setColor(0x555B8CFF);

        dotOn.setStyle(Paint.Style.FILL);
        dotOn.setColor(0xFF7FB0FF);
        dotOff.setStyle(Paint.Style.FILL);
        dotOff.setColor(0x445B8CFF);
    }

    /** pos: 0..5 for vertical (Highest..Lowest). swinging: sweep through all rays. */
    public void setState(int pos, boolean swinging) {
        this.pos = pos;
        this.swinging = swinging;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        setMeasuredDimension((int) (170 * density), (int) (130 * density));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        path.reset();

        float px, py, r0, r1;
        int n;
        double a0, a1;
        if (vertical) {
            path.moveTo(w * 0.04f, h * 0.06f);
            path.lineTo(w * 0.66f, h * 0.06f);
            path.quadTo(w * 0.74f, h * 0.06f, w * 0.74f, h * 0.16f);
            path.lineTo(w * 0.92f, h * 0.16f);
            path.lineTo(w * 0.92f, h * 0.94f);
            px = w * 0.80f;
            py = h * 0.22f;
            r0 = w * 0.16f;
            r1 = w * 0.62f;
            n = 6;
            a0 = 172;
            a1 = 100;
        } else {
            path.moveTo(w * 0.05f, h * 0.36f);
            path.lineTo(w * 0.36f, h * 0.08f);
            path.quadTo(w * 0.5f, h * 0.24f, w * 0.64f, h * 0.08f);
            path.lineTo(w * 0.95f, h * 0.36f);
            px = w * 0.5f;
            py = h * 0.24f;
            r0 = h * 0.26f;
            r1 = h * 0.72f;
            n = 7;
            a0 = 142;
            a1 = 38;
        }
        canvas.drawPath(path, outline);

        int active;
        if (swinging) {
            long t = (System.currentTimeMillis() / 220) % (2 * (n - 1));
            active = (int) (t < n ? t : 2 * (n - 1) - t);
        } else {
            active = vertical ? pos : n / 2;
        }

        for (int i = 0; i < n; i++) {
            double deg = a0 + (a1 - a0) * i / (n - 1);
            double rad = Math.toRadians(deg);
            float cs = (float) Math.cos(rad);
            float sn = (float) Math.sin(rad);
            float sx = px + cs * r0;
            float sy = py + sn * r0;
            float ex = px + cs * r1;
            float ey = py + sn * r1;
            boolean lit = swinging ? i == active : (vertical ? i == active : i == active);
            if (lit) {
                canvas.drawLine(sx, sy, ex, ey, rayGlow);
                canvas.drawLine(sx, sy, ex, ey, rayOn);
                canvas.drawCircle(ex + cs * 9 * density, ey + sn * 9 * density, 3.5f * density, dotOn);
            } else {
                canvas.drawLine(sx, sy, ex, ey, rayOff);
                canvas.drawCircle(ex + cs * 9 * density, ey + sn * 9 * density, 3f * density, dotOff);
            }
        }

        if (swinging) postInvalidateOnAnimation();
    }
}
