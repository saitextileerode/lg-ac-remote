package com.example.lgacremote;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Round temperature dial. Drag or tap on the ring to set 16..30 degrees. */
public class DialView extends View {

    public interface Listener {
        void onPreview(int temp);
        void onCommit(int temp);
        void onBlocked();
    }

    private static final float START = 150f;
    private static final float TOTAL = 240f;

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knobRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float density;
    private final float sp;

    private Listener listener;
    private String top = "OFF";
    private String big = "--";
    private String unit = "";
    private float frac = 0f;
    private boolean on = false;
    private boolean dragging = false;
    private int lastTemp = -1;
    private float cx, cy;

    public DialView(Context c) {
        super(c);
        density = getResources().getDisplayMetrics().density;
        sp = getResources().getDisplayMetrics().scaledDensity;
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setStrokeWidth(12 * density);
        track.setColor(0x401E4A7A);

        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        glow.setStrokeWidth(18 * density);
        glow.setMaskFilter(new BlurMaskFilter(12 * density, BlurMaskFilter.Blur.NORMAL));

        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setStrokeWidth(12 * density);

        knobFill.setStyle(Paint.Style.FILL);
        knobFill.setColor(0xFFFFFFFF);
        knobRing.setStyle(Paint.Style.STROKE);
        knobRing.setStrokeWidth(3 * density);
        knobRing.setColor(0xFF3FD0FF);

        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setListener(Listener l) {
        this.listener = l;
    }

    public void setState(String top, String big, String unit, float frac, boolean on) {
        this.top = top;
        this.big = big;
        this.unit = unit;
        this.frac = Math.max(0f, Math.min(1f, frac));
        this.on = on;
        invalidate();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int s = Math.min(MeasureSpec.getSize(widthSpec), (int) (270 * density));
        setMeasuredDimension(s, s);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        cx = w / 2f;
        cy = h / 2f;
        SweepGradient g = new SweepGradient(cx, cy,
                new int[]{0xFF3FD0FF, 0xFF4F8BFF, 0xFFB46BFF, 0xFF3FD0FF},
                new float[]{0f, 0.33f, 0.66f, 1f});
        Matrix m = new Matrix();
        m.setRotate(START, cx, cy);
        g.setLocalMatrix(m);
        arc.setShader(g);
        glow.setShader(g);
    }

    private float radius() {
        return Math.min(cx, cy) - 26 * density;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float r = radius();
        oval.set(cx - r, cy - r, cx + r, cy + r);

        canvas.drawArc(oval, START, TOTAL, false, track);

        float sweep = TOTAL * frac;
        if (on) {
            if (sweep > 0.5f) {
                canvas.drawArc(oval, START, sweep, false, glow);
                canvas.drawArc(oval, START, sweep, false, arc);
            }
            double rad = Math.toRadians(START + sweep);
            float kx = cx + (float) (r * Math.cos(rad));
            float ky = cy + (float) (r * Math.sin(rad));
            canvas.drawCircle(kx, ky, (dragging ? 13 : 10) * density, knobFill);
            canvas.drawCircle(kx, ky, (dragging ? 13 : 10) * density, knobRing);
        }

        // Scale end labels
        text.setTypeface(Typeface.DEFAULT);
        text.setColor(0xFF8FB2D6);
        text.setTextSize(11 * sp);
        double a1 = Math.toRadians(START);
        double a2 = Math.toRadians(START + TOTAL);
        canvas.drawText("16", cx + (float) (r * Math.cos(a1)), cy + (float) (r * Math.sin(a1)) + 24 * density, text);
        canvas.drawText("30", cx + (float) (r * Math.cos(a2)), cy + (float) (r * Math.sin(a2)) + 24 * density, text);

        // Mode label
        text.setColor(0xFF3FD0FF);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(14 * sp);
        canvas.drawText(top, cx, cy - r * 0.46f, text);

        // Big number and unit
        text.setColor(0xFFEAF6FF);
        text.setTextSize(66 * sp);
        float shift = unit.isEmpty() ? 0f : 10 * density;
        canvas.drawText(big, cx - shift, cy + r * 0.24f, text);
        if (!unit.isEmpty()) {
            float half = text.measureText(big) / 2f;
            text.setTextSize(22 * sp);
            text.setTypeface(Typeface.DEFAULT);
            text.setTextAlign(Paint.Align.LEFT);
            canvas.drawText(unit, cx - shift + half + 3 * density, cy + r * 0.24f - 26 * density, text);
            text.setTextAlign(Paint.Align.CENTER);
        }

        text.setColor(0xFF8FB2D6);
        text.setTypeface(Typeface.DEFAULT);
        text.setTextSize(11 * sp);
        canvas.drawText("TEMP", cx, cy + r * 0.58f, text);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!on) return false;
                {
                    double rad = Math.toRadians(START + TOTAL * frac);
                    float kx = cx + (float) (radius() * Math.cos(rad));
                    float ky = cy + (float) (radius() * Math.sin(rad));
                    float dx = e.getX() - kx;
                    float dy = e.getY() - ky;
                    float hit = 38 * density;
                    if (dx * dx + dy * dy > hit * hit) return false;
                }
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                dragging = true;
                lastTemp = -1;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) update(e);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    dragging = false;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    if (listener != null && lastTemp > 0) listener.onCommit(lastTemp);
                    invalidate();
                }
                return true;
            default:
                return true;
        }
    }

    private void update(MotionEvent e) {
        float dx = e.getX() - cx;
        float dy = e.getY() - cy;
        double ang = Math.toDegrees(Math.atan2(dy, dx));
        if (ang < 0) ang += 360;
        double rel = ang - START;
        if (rel < 0) rel += 360;
        float f;
        if (rel <= TOTAL) f = (float) (rel / TOTAL);
        else f = rel < TOTAL + (360 - TOTAL) / 2 ? 1f : 0f;
        int t = 16 + Math.round(f * 14);
        if (t != lastTemp) {
            lastTemp = t;
            if (listener != null) listener.onPreview(t);
        }
    }
}
